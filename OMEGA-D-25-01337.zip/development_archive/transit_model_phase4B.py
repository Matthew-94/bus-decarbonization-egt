# =============================================================================
# PHASE 4C
# FINAL MULTI-INITIAL-CONDITION TRAJECTORY FIGURES
#
# Creates one independent 2x2 figure for each scenario:
#
#   (a) Hydrogen RVK share, z
#   (b) Electric RVK share, w
#   (c) Diesel RVK share, 1-z-w
#   (d) Public-authority policy weight, y
#
# Seven interior initial conditions are used.
#
# State order = [z, w, y]
# =============================================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from transit_model_phase4B import (
    make_scenario,
    solve_replicator,
    policy_thresholds,
    expected_operator_payoffs,
)


# =============================================================================
# 1. INITIAL CONDITIONS
# =============================================================================

INITIAL_CONDITIONS = {

    # Diesel-heavy, low initial policy commitment
    "IC1": (0.05, 0.15, 0.20),

    # Diesel-heavy, high initial policy commitment
    "IC2": (0.05, 0.15, 0.80),

    # Electric-heavy, low initial policy commitment
    "IC3": (0.10, 0.70, 0.20),

    # Electric-heavy, high initial policy commitment
    "IC4": (0.10, 0.70, 0.80),

    # Hydrogen-heavy, low initial policy commitment
    "IC5": (0.70, 0.10, 0.20),

    # Hydrogen-heavy, high initial policy commitment
    "IC6": (0.70, 0.10, 0.80),

    # Balanced interior state
    "IC7": (0.30, 0.30, 0.50),
}


# =============================================================================
# 2. NUMERICAL SETTINGS
# =============================================================================

SCENARIOS = ["S1", "S2", "S3"]

TAU_SPAN = (0.0, 80.0)
N_POINTS = 4001

REPRESENTATIVE_IC = "IC1"


# =============================================================================
# 3. PLOT SETTINGS
# =============================================================================

# One technology color per panel.
# Initial-condition robustness is shown primarily by line style.
TECH_COLORS = {
    "H": "#333333",
    "E": "#557A95",
    "D": "#999999",
    "Y": "#8B5E5E",
}

LINE_STYLES = {
    "IC1": "-",
    "IC2": "--",
    "IC3": "-.",
    "IC4": ":",
    "IC5": (0, (5, 2)),
    "IC6": (0, (3, 1, 1, 1)),
    "IC7": (0, (1, 1)),
}

NORMAL_LINEWIDTH = 1.35
REPRESENTATIVE_LINEWIDTH = 2.5


# =============================================================================
# 4. HELPERS
# =============================================================================

def interpolated_crossing(tau, values, threshold):
    """
    First threshold crossing using linear interpolation.
    """

    tau = np.asarray(tau)
    values = np.asarray(values)

    shifted = values - threshold

    idx = np.where(
        shifted[:-1] * shifted[1:] <= 0.0
    )[0]

    if len(idx) == 0:
        return np.nan

    i = idx[0]

    t0 = tau[i]
    t1 = tau[i + 1]

    v0 = values[i]
    v1 = values[i + 1]

    if abs(v1 - v0) < 1e-14:
        return float(t0)

    fraction = (
        threshold - v0
    ) / (
        v1 - v0
    )

    return float(
        t0
        + fraction * (t1 - t0)
    )


def first_crossing_time(
    tau,
    values,
    threshold,
    direction="up",
):
    """
    First observed time at which the trajectory crosses a threshold.
    """

    tau = np.asarray(tau)
    values = np.asarray(values)

    if direction == "up":
        idx = np.where(
            values >= threshold
        )[0]

    elif direction == "down":
        idx = np.where(
            values <= threshold
        )[0]

    else:
        raise ValueError(
            "direction must be 'up' or 'down'"
        )

    if len(idx) == 0:
        return np.nan

    return float(
        tau[idx[0]]
    )


# =============================================================================
# 5. STORAGE FOR NUMERICAL RESULTS
# =============================================================================

summary_rows = []


# =============================================================================
# 6. LOOP THROUGH SCENARIOS
# =============================================================================

for scenario_name in SCENARIOS:

    p = make_scenario(
        scenario_name
    )

    thresholds = policy_thresholds(
        p
    )

    y_HE_star = thresholds["y_HE"]

    # -------------------------------------------------------------------------
    # Create one independent figure for this scenario
    # -------------------------------------------------------------------------

    fig, axes = plt.subplots(
        2,
        2,
        figsize=(11.5, 8.0),
        sharex=True,
        sharey=True,
    )

    ax_H = axes[0, 0]
    ax_E = axes[0, 1]
    ax_D = axes[1, 0]
    ax_Y = axes[1, 1]

    # -------------------------------------------------------------------------
    # Solve from every initial condition
    # -------------------------------------------------------------------------

    for ic_name, initial_state in INITIAL_CONDITIONS.items():

        sol = solve_replicator(
            p=p,
            initial_state=initial_state,
            tau_span=TAU_SPAN,
            n_points=N_POINTS,
        )

        tau = sol.t

        z = sol.y[0]
        w = sol.y[1]
        y = sol.y[2]

        D = 1.0 - z - w

        # Remove tiny integration roundoff only for reporting/plotting
        z_plot = np.clip(z, 0.0, 1.0)
        w_plot = np.clip(w, 0.0, 1.0)
        y_plot = np.clip(y, 0.0, 1.0)
        D_plot = np.clip(D, 0.0, 1.0)

        # -------------------------------------------------------------
        # Styling
        # -------------------------------------------------------------

        lw = (
            REPRESENTATIVE_LINEWIDTH
            if ic_name == REPRESENTATIVE_IC
            else NORMAL_LINEWIDTH
        )

        alpha = (
            1.0
            if ic_name == REPRESENTATIVE_IC
            else 0.70
        )

        linestyle = LINE_STYLES[
            ic_name
        ]

        # -------------------------------------------------------------
        # Hydrogen
        # -------------------------------------------------------------

        ax_H.plot(
            tau,
            z_plot,
            linestyle=linestyle,
            linewidth=lw,
            alpha=alpha,
            color=TECH_COLORS["H"],
            label=ic_name,
        )

        # -------------------------------------------------------------
        # Electric
        # -------------------------------------------------------------

        ax_E.plot(
            tau,
            w_plot,
            linestyle=linestyle,
            linewidth=lw,
            alpha=alpha,
            color=TECH_COLORS["E"],
        )

        # -------------------------------------------------------------
        # Diesel
        # -------------------------------------------------------------

        ax_D.plot(
            tau,
            D_plot,
            linestyle=linestyle,
            linewidth=lw,
            alpha=alpha,
            color=TECH_COLORS["D"],
        )

        # -------------------------------------------------------------
        # Policy
        # -------------------------------------------------------------

        ax_Y.plot(
            tau,
            y_plot,
            linestyle=linestyle,
            linewidth=lw,
            alpha=alpha,
            color=TECH_COLORS["Y"],
        )

        # -------------------------------------------------------------
        # Numerical mechanism diagnostics
        # -------------------------------------------------------------

        Pi_H = np.zeros_like(
            tau
        )

        Pi_E = np.zeros_like(
            tau
        )

        for i, yi in enumerate(y):

            op = expected_operator_payoffs(
                y=float(yi),
                p=p,
            )

            Pi_H[i] = op["Pi_H"]
            Pi_E[i] = op["Pi_E"]

        HE_gap = Pi_H - Pi_E

        if 0.0 <= y_HE_star <= 1.0:

            tau_HE_policy = interpolated_crossing(
                tau,
                y,
                y_HE_star,
            )

            tau_HE_payoff = interpolated_crossing(
                tau,
                HE_gap,
                0.0,
            )

        else:

            tau_HE_policy = np.nan
            tau_HE_payoff = np.nan

        # -------------------------------------------------------------
        # Transition milestones
        # -------------------------------------------------------------

        tau_H90 = first_crossing_time(
            tau,
            z_plot,
            0.90,
            direction="up",
        )

        tau_E90 = first_crossing_time(
            tau,
            w_plot,
            0.90,
            direction="up",
        )

        tau_D10 = first_crossing_time(
            tau,
            D_plot,
            0.10,
            direction="down",
        )

        tau_Y90 = first_crossing_time(
            tau,
            y_plot,
            0.90,
            direction="up",
        )

        idx_Emax = int(
            np.argmax(
                w_plot
            )
        )

        E_max = float(
            w_plot[idx_Emax]
        )

        tau_Emax = float(
            tau[idx_Emax]
        )

        # -------------------------------------------------------------
        # Store result
        # -------------------------------------------------------------

        summary_rows.append(
            {
                "Scenario": scenario_name,
                "IC": ic_name,

                "z0": initial_state[0],
                "w0": initial_state[1],
                "D0": (
                    1.0
                    - initial_state[0]
                    - initial_state[1]
                ),
                "y0": initial_state[2],

                "Final_H": float(
                    z_plot[-1]
                ),

                "Final_E": float(
                    w_plot[-1]
                ),

                "Final_D": float(
                    D_plot[-1]
                ),

                "Final_y": float(
                    y_plot[-1]
                ),

                "tau_H90": tau_H90,
                "tau_E90": tau_E90,
                "tau_D10": tau_D10,
                "tau_y90": tau_Y90,

                "Max_E": E_max,
                "tau_Max_E": tau_Emax,

                "y_HE_star": y_HE_star,
                "tau_y_HE": tau_HE_policy,
                "tau_payoff_HE": tau_HE_payoff,
            }
        )

    # =========================================================================
    # 7. PANEL FORMATTING
    # =========================================================================

    panel_info = [

        (
            ax_H,
            r"(a) Hydrogen service share, $z$",
        ),

        (
            ax_E,
            r"(b) Electric service share, $w$",
        ),

        (
            ax_D,
            r"(c) Diesel service share, $1-z-w$",
        ),

        (
            ax_Y,
            r"(d) Active-policy weight, $y$",
        ),
    ]

    for ax, title in panel_info:

        ax.set_title(
            title,
            fontsize=12,
            fontweight="bold",
        )

        ax.set_xlim(
            TAU_SPAN
        )

        ax.set_ylim(
            -0.02,
            1.02,
        )

        ax.tick_params(
            axis="both",
            labelsize=10,
            direction="in",
        )

        ax.grid(
            False
        )

        for spine in ax.spines.values():
            spine.set_linewidth(
                1.0
            )

    # -------------------------------------------------------------------------
    # S3 policy threshold
    # -------------------------------------------------------------------------

    if (
        scenario_name == "S3"
        and 0.0 <= y_HE_star <= 1.0
    ):

        ax_Y.axhline(
            y=y_HE_star,
            color="black",
            linewidth=1.25,
            linestyle="-.",
        )

        ax_Y.text(
            52.0,
            y_HE_star + 0.035,
            (
                r"$y_{HE}^{*}"
                f"={y_HE_star:.2f}"
            ),
            fontsize=10,
        )

    # -------------------------------------------------------------------------
    # Axis labels
    # -------------------------------------------------------------------------

    ax_D.set_xlabel(
        r"Normalized evolutionary time, $\tau$",
        fontsize=11,
    )

    ax_Y.set_xlabel(
        r"Normalized evolutionary time, $\tau$",
        fontsize=11,
    )

    ax_H.set_ylabel(
        "Evolutionary strategy weight",
        fontsize=11,
    )

    ax_D.set_ylabel(
        "Evolutionary strategy weight",
        fontsize=11,
    )

    # -------------------------------------------------------------------------
    # Figure title
    # -------------------------------------------------------------------------

    scenario_titles = {
        "S1": (
            "Baseline transition conditions"
        ),
        "S2": (
            "Intermediate transition conditions"
        ),
        "S3": (
            "Advanced transition conditions"
        ),
    }

    fig.suptitle(
        scenario_titles[
            scenario_name
        ],
        fontsize=14,
        fontweight="bold",
        y=0.99,
    )

    # -------------------------------------------------------------------------
    # Shared initial-condition legend
    # -------------------------------------------------------------------------

    handles, labels = (
        ax_H.get_legend_handles_labels()
    )

    fig.legend(
        handles,
        labels,
        loc="lower center",
        ncol=7,
        frameon=False,
        fontsize=9,
        bbox_to_anchor=(
            0.5,
            0.005,
        ),
    )

    fig.tight_layout(
        rect=[
            0.02,
            0.06,
            1.0,
            0.96,
        ]
    )

    # -------------------------------------------------------------------------
    # Save
    # -------------------------------------------------------------------------

    pdf_name = (
        f"Fig_{scenario_name}_"
        "multistart_dynamics.pdf"
    )

    png_name = (
        f"Fig_{scenario_name}_"
        "multistart_dynamics.png"
    )

    fig.savefig(
        pdf_name,
        bbox_inches="tight",
    )

    fig.savefig(
        png_name,
        dpi=600,
        bbox_inches="tight",
    )

    plt.show()
    plt.close(fig)


# =============================================================================
# 8. SAVE NUMERICAL SUMMARY
# =============================================================================

summary = pd.DataFrame(
    summary_rows
)

summary.to_csv(
    "Phase4C_multistart_summary.csv",
    index=False,
)


# =============================================================================
# 9. PRINT FINAL-STATE TABLE
# =============================================================================

print("\n")
print("=" * 110)

print(
    "PHASE 4C — MULTI-INITIAL-CONDITION "
    "FINAL-STATE AUDIT"
)

print("=" * 110)

for scenario_name in SCENARIOS:

    print(
        f"\n{scenario_name}"
    )

    print(
        "-" * 90
    )

    subset = summary[
        summary["Scenario"]
        == scenario_name
    ]

    for _, row in subset.iterrows():

        print(
            f"{row['IC']}: "
            f"H={row['Final_H']:.6f}, "
            f"E={row['Final_E']:.6f}, "
            f"D={row['Final_D']:.6f}, "
            f"y={row['Final_y']:.6f}"
        )

    if scenario_name == "S3":

        print(
            "\nS3 H-E reversal diagnostics:"
        )

        for _, row in subset.iterrows():

            print(
                f"{row['IC']}: "
                f"tau(y=y_HE*)="
                f"{row['tau_y_HE']:.4f}, "
                f"tau(Pi_H=Pi_E)="
                f"{row['tau_payoff_HE']:.4f}, "
                f"max E="
                f"{row['Max_E']:.4f} "
                f"at tau="
                f"{row['tau_Max_E']:.4f}"
            )


print(
    "\nFiles created:"
)

print(
    "  Fig_S1_multistart_dynamics.png/pdf"
)

print(
    "  Fig_S2_multistart_dynamics.png/pdf"
)

print(
    "  Fig_S3_multistart_dynamics.png/pdf"
)

print(
    "  Phase4C_multistart_summary.csv"
)

print(
    "\nPhase 4C trajectory production completed."
)