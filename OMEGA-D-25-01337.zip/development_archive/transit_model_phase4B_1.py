# =============================================================================
# REVISED EVOLUTIONARY BUS-TRANSITION MODEL
# PHASE 4B — CERTIFIED BASELINE CORE
#
# State order used everywhere:
#     x = [z, w, y]
#
# z = hydrogen share of annual scheduled RVK
# w = electric share of annual scheduled RVK
# 1-z-w = diesel share of annual scheduled RVK
# y = public-authority active-policy weight
#
# All operator economic payoffs are expressed in CAD/RVK.
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Dict, Iterable, Tuple, List

import numpy as np
from scipy.integrate import solve_ivp


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Calibrated so baseline diesel utility = 0
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # Greenness-related implementation-cost coefficient, CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # Environmental damage price, CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    #
    # Both are normalized to one in the benchmark.
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIO CONSTRUCTION
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,

            theta=0.30,
            phi=0.30,

            R_H=900_000.0,
            R_E=675_000.0,

            C_hat_H=1.20,

            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,

            theta=0.40,
            phi=0.40,

            R_H=600_000.0,
            R_E=600_000.0,

            C_hat_H=0.80,

            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError(
        f"Unknown scenario '{name}'. "
        f"Choose 'S1', 'S2', or 'S3'."
    )


# =============================================================================
# 3. BASIC ECONOMIC FUNCTIONS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:

    return (
        r * (1.0 + r) ** L
        / ((1.0 + r) ** L - 1.0)
    )


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (
            1.0 / (2.0 * p.F_H)
            + p.l / p.A_H
        )
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (
            1.0 / (2.0 * p.F_E)
            + p.l / p.A_E
        )
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (
            1.0 / (2.0 * p.F_D)
            + p.l / p.A_D
        )
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = (
        p.alpha_0
        + p.gamma_1 * U_H
        - p.gamma_2 * p.U_O
    )

    q_E = (
        p.alpha_0
        + p.gamma_1 * U_E
        - p.gamma_2 * p.U_O
    )

    q_D = (
        p.alpha_0
        + p.gamma_1 * U_D
        - p.gamma_2 * p.U_O
    )

    if min(q_H, q_E, q_D) < 0:
        raise ValueError(
            "Negative passenger utilization produced by "
            "the linear utilization specification."
        )

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(
            p.discount_r,
            p.L_H,
        )
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(
            p.discount_r,
            p.L_E,
        )
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(
            p.discount_r,
            p.L_D,
        )
    )

    # -------------------------------------------------------------------------
    # Operator baseline-policy payoffs
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta ** 2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi ** 2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Operator active-policy payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Lifecycle emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H ** 2 / (
        2.0 * p.gamma_1 * p.beta_t
    )

    CS_E = q_E ** 2 / (
        2.0 * p.gamma_1 * p.beta_t
    )

    CS_D = q_D ** 2 / (
        2.0 * p.gamma_1 * p.beta_t
    )

    # -------------------------------------------------------------------------
    # Authority baseline welfare components
    # -------------------------------------------------------------------------

    V_H = (
        CS_H
        + pi_H_B
        - p.p_CO2 * e_H
    )

    V_E = (
        CS_E
        + pi_E_B
        - p.p_CO2 * e_E
    )

    V_D = (
        CS_D
        + pi_D_B
        - p.p_CO2 * e_D
    )

    # -------------------------------------------------------------------------
    # PA incremental payoff of active regime relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma representation used in analytical derivation
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B

    Gamma_H1 = (
        p.S_H * q_H
        + p.T_D * q_D
    )

    Gamma_E0 = pi_E_B - pi_D_B

    Gamma_E1 = (
        p.S_E * q_E
        + p.T_D * q_D
    )

    return {

        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,

        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(
    y: float,
    p: Parameters,
) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = (
        d["pi_H_B"]
        + y * p.S_H * d["q_H"]
    )

    Pi_E = (
        d["pi_E_B"]
        + y * p.S_E * d["q_E"]
    )

    Pi_D = (
        d["pi_D_B"]
        - y * p.T_D * d["q_D"]
    )

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS — DIRECT PAYOFF FORM
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # Manuscript state order:
    # state = [z, w, y]

    z, w, y = map(float, state)

    d_share = 1.0 - z - w

    op = expected_operator_payoffs(
        y=y,
        p=p,
    )

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + d_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + d_share * d["Delta_D"]
    )

    dz = (
        p.eta_TO
        * z
        * (Pi_H - Pi_bar)
    )

    dw = (
        p.eta_TO
        * w
        * (Pi_E - Pi_bar)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * policy_advantage
    )

    return np.array(
        [dz, dw, dy],
        dtype=float,
    )


# =============================================================================
# 6. REPLICATOR DYNAMICS — GAMMA/DELTA FORM
#
# This is used only as a certification check.
# It must equal replicator_rhs().
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = (
        d["Gamma_H0"]
        + y * d["Gamma_H1"]
    )

    Gamma_E = (
        d["Gamma_E0"]
        + y * d["Gamma_E1"]
    )

    P = (
        d["Delta_D"]
        + z * (
            d["Delta_H"]
            - d["Delta_D"]
        )
        + w * (
            d["Delta_E"]
            - d["Delta_D"]
        )
    )

    dz = (
        p.eta_TO
        * z
        * (
            (1.0 - z) * Gamma_H
            - w * Gamma_E
        )
    )

    dw = (
        p.eta_TO
        * w
        * (
            (1.0 - w) * Gamma_E
            - z * Gamma_H
        )
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array(
        [dz, dw, dy],
        dtype=float,
    )


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(
    state: Iterable[float],
) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError(
            "z, w, and y must lie in [0,1]."
        )

    if z + w > 1.0:
        raise ValueError(
            "Initial state violates z + w <= 1."
        )

    return np.array(
        [z, w, y],
        dtype=float,
    )


# =============================================================================
# 8. NUMERICAL SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 2001,
):

    x0 = validate_initial_state(
        initial_state
    )

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(
            tau,
            x,
            p,
        ),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(
            sol.message
        )

    return sol


# =============================================================================
# 9. PURE-EQUILIBRIUM STABILITY CONDITIONS
#
# E1 = D_B
# E2 = H_B
# E3 = E_B
# E4 = D_A
# E5 = H_A
# E6 = E_A
# =============================================================================

def pure_stability_report(
    p: Parameters,
) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {

        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 10. PAIRWISE POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(
    p: Parameters,
) -> Dict[str, float]:

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    y_HE = (
        (
            d["pi_E_B"]
            - d["pi_H_B"]
        )
        / denominator_HE
    )

    y_HD = (
        (
            d["pi_D_B"]
            - d["pi_H_B"]
        )
        / denominator_HD
    )

    y_ED = (
        (
            d["pi_D_B"]
            - d["pi_E_B"]
        )
        / denominator_ED
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 11. REPORTING HELPERS
# =============================================================================

def final_state(
    sol,
) -> Dict[str, float]:

    z = float(sol.y[0, -1])
    w = float(sol.y[1, -1])
    y = float(sol.y[2, -1])

    # Only clean tiny numerical integration errors for reporting.
    z = float(np.clip(z, 0.0, 1.0))
    w = float(np.clip(w, 0.0, 1.0))
    y = float(np.clip(y, 0.0, 1.0))

    diesel = max(
        0.0,
        1.0 - z - w,
    )

    return {
        "z_H": z,
        "w_E": w,
        "D": diesel,
        "y": y,
    }


# =============================================================================
# 12. CERTIFICATION TEST
# =============================================================================

def certify_rhs_equivalence(
    p: Parameters,
) -> float:

    # Interior test point
    test_state = np.array(
        [0.20, 0.40, 0.50],
        dtype=float,
    )

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    error = float(
        np.max(
            np.abs(
                direct - gamma
            )
        )
    )

    return error


# =============================================================================
# 13. MAIN AUDIT
# =============================================================================

if __name__ == "__main__":

    INITIAL_CONDITIONS: List[
        Tuple[float, float, float]
    ] = [

        # [z, w, y]

        (0.10, 0.10, 0.20),
        (0.20, 0.60, 0.10),
        (0.60, 0.20, 0.10),
        (0.05, 0.90, 0.05),
        (0.45, 0.45, 0.50),
    ]

    print("=" * 84)
    print("PHASE 4B — REVISED MODEL CERTIFICATION")
    print("=" * 84)

    for scenario_name in [
        "S1",
        "S2",
        "S3",
    ]:

        p = make_scenario(
            scenario_name
        )

        d = derived_quantities(
            p
        )

        thresholds = policy_thresholds(
            p
        )

        stability = pure_stability_report(
            p
        )

        rhs_error = certify_rhs_equivalence(
            p
        )

        print(
            f"\n{scenario_name}"
        )

        print("-" * 60)

        print(
            f"q_H = {d['q_H']:.4f}, "
            f"q_E = {d['q_E']:.4f}, "
            f"q_D = {d['q_D']:.4f}"
        )

        print(
            f"pi_H^B = {d['pi_H_B']:.4f}, "
            f"pi_E^B = {d['pi_E_B']:.4f}, "
            f"pi_D^B = {d['pi_D_B']:.4f}"
        )

        print(
            f"Delta_H = {d['Delta_H']:.6f}, "
            f"Delta_E = {d['Delta_E']:.6f}, "
            f"Delta_D = {d['Delta_D']:.6f}"
        )

        print(
            f"y_HE* = "
            f"{thresholds['y_HE']:.4f}"
        )

        print(
            "Direct/Gamma RHS maximum error = "
            f"{rhs_error:.3e}"
        )

        print(
            "\nLocally asymptotically "
            "stable pure rest point(s):"
        )

        stable_found = False

        for equilibrium, is_stable in stability.items():

            if is_stable:

                stable_found = True

                print(
                    f"  {equilibrium}"
                )

        if not stable_found:
            print(
                "  None"
            )

        print(
            "\nNumerical trajectories:"
        )

        for run_number, ic in enumerate(
            INITIAL_CONDITIONS,
            start=1,
        ):

            sol = solve_replicator(
                p=p,
                initial_state=ic,
            )

            fs = final_state(
                sol
            )

            print(
                f"  Run {run_number}: "
                f"z_H={fs['z_H']:.6f}, "
                f"w_E={fs['w_E']:.6f}, "
                f"D={fs['D']:.6f}, "
                f"y={fs['y']:.6f}"
            )

    print(
        "\nCertification completed."
    )