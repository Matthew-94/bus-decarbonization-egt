"""
Section 4.6 premium figures: operational non-equivalence and nonlinear infrastructure-entry costs.

This script generates three reviewer-focused analyses with the same premium visual style
used in the existing paper figures:

Analysis 1: service-equivalency sensitivity for rho_E using the baseline replicator solver.
Analysis 2: nonlinear infrastructure-entry sensitivity for F_E^inf using the nonlinear solver.
Analysis 3: combined rho_E--F_E^inf heatmap using tail-average electric strategic weight.

Internal state order used by transit_model.py is [w, y, z]:
    w = electric strategic weight
    y = public authority policy variable
    z = hydrogen strategic weight
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import matplotlib.pyplot as plt

from transit_model import (
    Parameters,
    ModelSwitches,
    compute_infrastructure_burdens,
    infrastructure_entry_burden,
    solve_replicator,
    replicator_rhs_nonlinear_infrastructure,
    solve_replicator_nonlinear_infrastructure,
)

# ============================================================
# 0) OUTPUTS AND PREMIUM PLOT SETTINGS
# ============================================================

OUTPUT_DIR = Path("section46_premium_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

# Same visual language as the paper figures shared by the user.
COLORS = ["blue", "red", "lime", "orange", "purple", "black", "cyan", "magenta", "brown", "navy"]
MARKERS = ["s", "o", "^", "D", "v", "P", "X", "*", "<", ">"]

TITLE_FONT_SIZE = 48
TICK_FONT_SIZE = 42
LEGEND_FONT_SIZE = 28  # Slightly smaller than 32 to avoid overlap in multi-curve figures.
PANEL_LABEL_SIZE = 36
DPI_SETTING = 600
LINE_WIDTH = 3.0
MARKER_SIZE = 10
SPINE_WIDTH = 3.0
TICK_PAD = 10
MARK_EVERY = 50

plt.rcParams["font.family"] = "serif"


def _cycle(values: Sequence[str], i: int) -> str:
    return values[i % len(values)]


def apply_premium_probability_formatting(
    ax: plt.Axes,
    *,
    legend: bool = False,
    legend_loc: str = "upper right",
    legend_title: str | None = None,
    legend_ncol: int = 1,
    y_label_as_probability: bool = True,
) -> None:
    """Apply the same premium 2D formatting used in the existing paper code."""
    for spine in ax.spines.values():
        spine.set_linewidth(SPINE_WIDTH)

    if y_label_as_probability:
        y_ticks = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
        ax.set_ylim([0, 1.0])
        ax.set_yticks(y_ticks)
        ax.set_yticklabels([f"{tick:g}" for tick in y_ticks])

    ax.tick_params(axis="both", labelsize=TICK_FONT_SIZE, pad=TICK_PAD, direction="in",
                   bottom=True, top=True, left=True, right=True, width=2.0, length=8)

    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("bold")

    ax.grid(False)

    if legend:
        leg = ax.legend(fontsize=LEGEND_FONT_SIZE, loc=legend_loc, frameon=True,
                        ncol=legend_ncol, title=legend_title)
        if leg is not None:
            leg.set_draggable(True)
            if legend_title is not None:
                plt.setp(leg.get_title(), fontsize=LEGEND_FONT_SIZE, fontweight="bold")


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(0.02, 0.93, label, transform=ax.transAxes, fontsize=PANEL_LABEL_SIZE,
            fontweight="bold", va="top", ha="left")


def keep_feasible_probability_path(sol) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return feasible t, w, y, z values for plotting EGT probability paths."""
    t = sol.t
    w, y, z = sol.y[0, :], sol.y[1, :], sol.y[2, :]
    valid = (w >= -1e-8) & (z >= -1e-8) & ((w + z) <= 1.0 + 1e-8) & (y >= -1e-8) & (y <= 1.0 + 1e-8)
    return t[valid], np.clip(w[valid], 0, 1), np.clip(y[valid], 0, 1), np.clip(z[valid], 0, 1)


# ============================================================
# 1) PARAMETERIZATION
# ============================================================


def make_base_extension_parameters() -> Parameters:
    """Baseline parameters for Section 4.6 extension analysis."""
    return Parameters(
        rho_H=1.0,
        rho_E=1.0,

        # Hydrogen infrastructure extension parameters.
        infra_F_H=0.0,
        infra_lambda_H=4.0,
        infra_eta_H=0.0,
        infra_zeta_H=0.0,
        infra_cap_H=0.70,
        infra_psi_H=0.50,

        # Electric infrastructure extension parameters.
        # infra_F_E and rho_E are varied in the analyses below.
        infra_F_E=0.0,
        infra_lambda_E=4.0,
        infra_eta_E=0.0,
        infra_zeta_E=500.0,
        infra_cap_E=0.70,
        infra_psi_E=0.50,
    )


# ============================================================
# 2) HELPER PLOTS
# ============================================================


def plot_infrastructure_burden_shape(base_params: Parameters) -> None:
    """Plot Omega_E(w) for representative fixed-entry burden values."""
    w_grid = np.linspace(0.0, 1.0, 300)
    F_values = [0, 250, 500, 750, 1000, 1250, 1500]

    fig, ax = plt.subplots(figsize=(12, 6))

    for i, F in enumerate(F_values):
        p = replace(base_params, infra_F_E=F)
        omega_values = [
            infrastructure_entry_burden(
                strategic_weight=w,
                fixed_entry_burden=p.infra_F_E,
                decay_rate=p.infra_lambda_E,
                marginal_burden=p.infra_eta_E,
                expansion_burden=p.infra_zeta_E,
                capacity_threshold=p.infra_cap_E,
            )
            for w in w_grid
        ]
        ax.plot(
            w_grid,
            omega_values,
            color=_cycle(COLORS, i),
            marker=_cycle(MARKERS, i),
            linewidth=LINE_WIDTH,
            markersize=MARKER_SIZE,
            markevery=35,
            label=fr"$F_E^{{inf}}={F}$",
        )

    ax.axvline(base_params.infra_cap_E, linestyle="--", linewidth=2.5, color="black")
    ax.text(base_params.infra_cap_E + 0.02, ax.get_ylim()[1] * 0.80,
            r"capacity threshold", fontsize=28, fontweight="bold")

    ax.set_xlabel(r"Electric strategic weight ($w$)", fontsize=TITLE_FONT_SIZE, fontweight="bold")
    ax.set_ylabel(r"$\Omega_E(w)$", fontsize=TITLE_FONT_SIZE, fontweight="bold")

    # Do not force y-axis to [0, 1] here because Omega is a burden, not a probability.
    apply_premium_probability_formatting(
        ax,
        legend=True,
        legend_title=r"Fixed-entry burden",
        legend_ncol=2,
        y_label_as_probability=False,
    )

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "figure_S46_omegaE_shape.png", dpi=DPI_SETTING, bbox_inches="tight")
    plt.show()
    plt.close(fig)


# ============================================================
# 3) ANALYSIS 1: rho_E SENSITIVITY
# ============================================================


def plot_rhoE_time_series_sensitivity(base_params: Parameters) -> None:
    """Plot w(t), y(t), and z(t) under representative rho_E values."""
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]  # [w, y, z]
    t_span = (0.0, 0.20)
    t_eval = np.linspace(t_span[0], t_span[1], 700)

    rho_values = [1.0, 1.1, 1.2, 1.5, 1.55, 1.8, 2.0]

    fig, axes = plt.subplots(3, 1, figsize=(14, 18), sharex=True)
    var_labels = [r"Electric strategic weight ($w$)", r"Policy variable ($y$)", r"Hydrogen strategic weight ($z$)"]
    panel_labels = ["(a)", "(b)", "(c)"]

    for i, rho in enumerate(rho_values):
        p = replace(base_params, rho_E=rho)
        sol = solve_replicator(p=p, initial_state=initial_state, t_span=t_span, t_eval=t_eval, switches=switches)
        t, w, y, z = keep_feasible_probability_path(sol)
        values = [w, y, z]
        label = fr"$\rho_E={rho:.2f}$"

        for ax, data in zip(axes, values):
            ax.plot(
                t,
                data,
                color=_cycle(COLORS, i),
                marker=_cycle(MARKERS, i),
                linewidth=LINE_WIDTH,
                markersize=MARKER_SIZE,
                markevery=MARK_EVERY,
                label=label,
            )

    for ax, ylabel, panel in zip(axes, var_labels, panel_labels):
        ax.set_ylabel(ylabel, fontsize=TITLE_FONT_SIZE, fontweight="bold")
        add_panel_label(ax, panel)
        apply_premium_probability_formatting(ax)

    axes[-1].set_xlabel("t", fontsize=TITLE_FONT_SIZE, fontweight="bold")
    apply_premium_probability_formatting(
        axes[0],
        legend=True,
        legend_title=r"Service-equivalency factor",
        legend_ncol=2,
    )

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "figure_S46a_rhoE_timeseries_w_y_z.png", dpi=DPI_SETTING, bbox_inches="tight")
    plt.show()
    plt.close(fig)


# ============================================================
# 4) ANALYSIS 2: NONLINEAR INFRASTRUCTURE-ENTRY SENSITIVITY
# ============================================================


def plot_infra_FE_time_series_sensitivity(base_params: Parameters) -> None:
    """Plot w(t), y(t), and z(t) under representative electric fixed-entry burdens."""
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]
    t_span = (0.0, 0.20)
    t_eval = np.linspace(t_span[0], t_span[1], 700)
    F_values = [0, 250, 500, 750, 1000, 1250, 1500]

    fig, axes = plt.subplots(3, 1, figsize=(14, 18), sharex=True)
    var_labels = [r"Electric strategic weight ($w$)", r"Policy variable ($y$)", r"Hydrogen strategic weight ($z$)"]
    panel_labels = ["(a)", "(b)", "(c)"]

    for i, F in enumerate(F_values):
        p = replace(base_params, infra_F_E=F)
        t, w, y, z = fast_trajectory_nonlinear(
            p=p,
            switches=switches,
            initial_state=initial_state,
            t_end=t_span[1],
            n_steps=1200,
        )
        values = [w, y, z]
        label = fr"$F_E^{{inf}}={F}$"

        for ax, data in zip(axes, values):
            ax.plot(
                t,
                data,
                color=_cycle(COLORS, i),
                marker=_cycle(MARKERS, i),
                linewidth=LINE_WIDTH,
                markersize=MARKER_SIZE,
                markevery=MARK_EVERY,
                label=label,
            )

    for ax, ylabel, panel in zip(axes, var_labels, panel_labels):
        ax.set_ylabel(ylabel, fontsize=TITLE_FONT_SIZE, fontweight="bold")
        add_panel_label(ax, panel)
        apply_premium_probability_formatting(ax)

    axes[-1].set_xlabel("t", fontsize=TITLE_FONT_SIZE, fontweight="bold")
    apply_premium_probability_formatting(
        axes[0],
        legend=True,
        legend_title=r"Electric fixed-entry burden",
        legend_ncol=2,
    )

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "figure_S46b_infraFE_timeseries_w_y_z.png", dpi=DPI_SETTING, bbox_inches="tight")
    plt.show()
    plt.close(fig)




def project_to_simplex_state(x: np.ndarray) -> np.ndarray:
    """Project [w, y, z] to the feasible probability region for fast heatmap integration."""
    x = np.asarray(x, dtype=float)
    x = np.nan_to_num(x, nan=0.0, posinf=1.0, neginf=0.0)
    x = np.clip(x, 0.0, 1.0)
    w, y, z = x
    if w + z > 1.0:
        total = w + z
        w = w / total
        z = z / total
    return np.array([w, y, z], dtype=float)



def fast_trajectory_nonlinear(
    p: Parameters,
    switches: ModelSwitches,
    initial_state: Iterable[float],
    *,
    t_end: float = 0.20,
    n_steps: int = 1200,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Fast fixed-step RK4 trajectory for nonlinear infrastructure time-series plots."""
    h = t_end / n_steps
    x = project_to_simplex_state(np.array(list(initial_state), dtype=float))
    t_values = np.linspace(0.0, t_end, n_steps + 1)
    states = np.zeros((n_steps + 1, 3), dtype=float)

    for k in range(n_steps + 1):
        states[k, :] = x
        if k == n_steps:
            break
        t = k * h
        k1 = np.array(replicator_rhs_nonlinear_infrastructure(t, x, p, switches), dtype=float)
        k2 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k1 / 2.0), p, switches), dtype=float)
        k3 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k2 / 2.0), p, switches), dtype=float)
        k4 = np.array(replicator_rhs_nonlinear_infrastructure(t + h, project_to_simplex_state(x + h * k3), p, switches), dtype=float)
        x = project_to_simplex_state(x + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0)

    return t_values, states[:, 0], states[:, 1], states[:, 2]


def fast_tail_average_nonlinear(
    p: Parameters,
    switches: ModelSwitches,
    initial_state: Iterable[float],
    *,
    t_end: float = 0.20,
    n_steps: int = 1000,
    tail_fraction: float = 0.20,
) -> tuple[float, float, float]:
    """
    Fast fixed-step RK4 integrator used only for the dense heatmap.

    The standard solve_ivp solver is retained for the main time-series figures. For the
    heatmap, this RK4 routine avoids repeated LSODA overhead and keeps the figure script
    practical while preserving the qualitative numerical behavior.
    """
    h = t_end / n_steps
    x = project_to_simplex_state(np.array(list(initial_state), dtype=float))
    tail_start = int((1.0 - tail_fraction) * n_steps)
    tail_values = []

    for k in range(n_steps + 1):
        if k >= tail_start:
            tail_values.append(x.copy())
        if k == n_steps:
            break

        t = k * h
        k1 = np.array(replicator_rhs_nonlinear_infrastructure(t, x, p, switches), dtype=float)
        k2 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k1 / 2.0), p, switches), dtype=float)
        k3 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k2 / 2.0), p, switches), dtype=float)
        k4 = np.array(replicator_rhs_nonlinear_infrastructure(t + h, project_to_simplex_state(x + h * k3), p, switches), dtype=float)
        x = project_to_simplex_state(x + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0)

    tail = np.asarray(tail_values)
    return float(np.mean(tail[:, 0])), float(np.mean(tail[:, 1])), float(np.mean(tail[:, 2]))



# ============================================================
# 5) ANALYSIS 3: COMBINED rho_E--F_E HEATMAP
# ============================================================


def tail_average(values: np.ndarray, tail_fraction: float = 0.20) -> float:
    n_tail = max(5, int(len(values) * tail_fraction))
    return float(np.mean(values[-n_tail:]))


def plot_combined_rhoE_infraFE_heatmap(base_params: Parameters) -> None:
    """Heatmap of tail-average w under joint rho_E and F_E^inf variation."""
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]
    t_span = (0.0, 0.20)
    t_eval = np.linspace(t_span[0], t_span[1], 200)

    # Representative values keep the heatmap consistent with the two time-series analyses.
    # For a smoother exploratory heatmap, replace these lists with np.linspace grids.
    rho_values = np.array([1.0, 1.1, 1.2, 1.5, 1.55, 1.8, 2.0], dtype=float)
    F_values = np.array([0, 250, 500, 750, 1000, 1250, 1500], dtype=float)

    W_tail = np.zeros((len(F_values), len(rho_values)))
    Y_tail = np.zeros_like(W_tail)
    Z_tail = np.zeros_like(W_tail)

    for i, F in enumerate(F_values):
        for j, rho in enumerate(rho_values):
            p = replace(base_params, rho_E=float(rho), infra_F_E=float(F))
            w_bar, y_bar, z_bar = fast_tail_average_nonlinear(
                p=p,
                switches=switches,
                initial_state=initial_state,
                t_end=t_span[1],
                n_steps=800,
                tail_fraction=0.20,
            )
            W_tail[i, j] = w_bar
            Y_tail[i, j] = y_bar
            Z_tail[i, j] = z_bar

    fig, ax = plt.subplots(figsize=(12, 8))

    # Use a clear continuous heatmap. Values close to 1 mean strong electric pathway.
    im = ax.imshow(
        W_tail,
        origin="lower",
        aspect="auto",
        extent=[rho_values.min(), rho_values.max(), F_values.min(), F_values.max()],
        vmin=0,
        vmax=1,
        cmap="viridis",
    )

    # Add threshold contours when they exist in the computed range.
    contour_levels = [0.25, 0.50, 0.75]
    CS = ax.contour(rho_values, F_values, W_tail, levels=contour_levels, colors="black", linewidths=2.5)
    ax.clabel(CS, inline=True, fontsize=22, fmt="%.2f")

    ax.set_xlabel(r"Electric service-equivalency factor ($\rho_E$)", fontsize=TITLE_FONT_SIZE, fontweight="bold")
    ax.set_ylabel(r"Electric fixed-entry burden ($F_E^{inf}$)", fontsize=TITLE_FONT_SIZE, fontweight="bold")

    for spine in ax.spines.values():
        spine.set_linewidth(SPINE_WIDTH)
    ax.tick_params(axis="both", labelsize=TICK_FONT_SIZE, pad=TICK_PAD, direction="in",
                   bottom=True, top=True, left=True, right=True, width=2.0, length=8)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("bold")
    ax.grid(False)

    cbar = fig.colorbar(im, ax=ax, pad=0.03)
    cbar.set_label(r"Tail-average electric weight ($\bar{w}_{tail}$)", fontsize=34, fontweight="bold")
    cbar.ax.tick_params(labelsize=28, width=2.0, length=7)
    for tick in cbar.ax.get_yticklabels():
        tick.set_fontweight("bold")

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "figure_S46c_rhoE_infraFE_tailW_heatmap.png", dpi=DPI_SETTING, bbox_inches="tight")
    plt.show()
    plt.close(fig)

    # Save numerical matrix for traceability.
    np.savez(
        OUTPUT_DIR / "figure_S46c_heatmap_data.npz",
        rho_values=rho_values,
        F_values=F_values,
        W_tail=W_tail,
        Y_tail=Y_tail,
        Z_tail=Z_tail,
    )


# ============================================================
# 6) FINAL STATE TABLES FOR INTERPRETATION
# ============================================================


def print_final_states_for_FE(base_params: Parameters) -> None:
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]
    t_span = (0.0, 0.20)
    t_eval = np.linspace(t_span[0], t_span[1], 700)
    F_values = [0, 250, 500, 750, 1000, 1250, 1500]

    print("\nFinal states under nonlinear infrastructure-entry extension")
    print("=" * 96)
    print(f"{'F_E^inf':>10} | {'w_final':>10} | {'y_final':>10} | {'z_final':>10} | {'Omega_E':>12} | {'Omega_H':>12}")
    print("-" * 96)
    for F in F_values:
        p = replace(base_params, infra_F_E=F)
        _, w_path, y_path, z_path = fast_trajectory_nonlinear(
            p=p,
            switches=switches,
            initial_state=initial_state,
            t_end=t_span[1],
            n_steps=1200,
        )
        w, y, z = w_path[-1], y_path[-1], z_path[-1]
        burdens = compute_infrastructure_burdens(w=w, z=z, p=p)
        print(f"{F:10.2f} | {w:10.4f} | {y:10.4f} | {z:10.4f} | {burdens['Omega_E']:12.4f} | {burdens['Omega_H']:12.4f}")
    print("=" * 96)


# ============================================================
# 7) MAIN
# ============================================================


def main() -> None:
    print("Section 4.6 premium plotting scripts are separated to keep each run stable and fast.")
    print("Run these commands one by one:")
    print("  python run_section46_omega_shape.py")
    print("  python run_section46_rhoE_timeseries.py")
    print("  python run_section46_infraFE_timeseries.py")
    print("  python run_section46_combined_heatmap.py")
    print(f"Outputs will be saved in: {OUTPUT_DIR.resolve()}")

if __name__ == "__main__":
    main()
