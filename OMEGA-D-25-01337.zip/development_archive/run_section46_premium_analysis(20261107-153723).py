"""
Section 4.6 premium figures: operational non-equivalence and nonlinear infrastructure-entry costs.

This script generates three reviewer-focused analyses with the same premium visual style
used in the existing paper figures:

Analysis 1: service-equivalency sensitivity for rho_E using the baseline replicator solver.
Analysis 2: nonlinear infrastructure-entry sensitivity for F_E^inf using the nonlinear solver.
Analysis 3: combined rho_E--F_E^inf heatmap using tail-average electric strategic weight.

Internal state order used by transit_model.py is [w, y, z]:
    w = electric strategic weight
    y = public authority policy variable
    z = hydrogen strategic weight
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import matplotlib.pyplot as plt

from transit_model import (
    Parameters,
    ModelSwitches,
    compute_infrastructure_burdens,
    infrastructure_entry_burden,
    solve_replicator,
    replicator_rhs_nonlinear_infrastructure,
    solve_replicator_nonlinear_infrastructure,
)

# ============================================================
# 0) OUTPUTS AND PREMIUM PLOT SETTINGS
# ============================================================

OUTPUT_DIR = Path("section46_premium_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

# Same visual language as the paper figures shared by the user.
COLORS = ["blue", "red", "lime", "orange", "purple", "black", "cyan", "magenta", "brown", "navy"]
MARKERS = ["s", "o", "^", "D", "v", "P", "X", "*", "<", ">"]

TITLE_FONT_SIZE = 48
TICK_FONT_SIZE = 42
LEGEND_FONT_SIZE = 28  # Slightly smaller than 32 to avoid overlap in multi-curve figures.
PANEL_LABEL_SIZE = 36
DPI_SETTING = 600
LINE_WIDTH = 3.0
MARKER_SIZE = 10
SPINE_WIDTH = 3.0
TICK_PAD = 10
MARK_EVERY = 50

plt.rcParams["font.family"] = "serif"


def _cycle(values: Sequence[str], i: int) -> str:
    return values[i % len(values)]


def apply_premium_probability_formatting(
    ax: plt.Axes,
    *,
    legend: bool = False,
    legend_loc: str = "upper right",
    legend_title: str | None = None,
    legend_ncol: int = 1,
    y_label_as_probability: bool = True,
) -> None:
    """Apply the same premium 2D formatting used in the existing paper code."""
    for spine in ax.spines.values():
        spine.set_linewidth(SPINE_WIDTH)

    if y_label_as_probability:
        y_ticks = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
        ax.set_ylim([0, 1.0])
        ax.set_yticks(y_ticks)
        ax.set_yticklabels([f"{tick:g}" for tick in y_ticks])

    ax.tick_params(axis="both", labelsize=TICK_FONT_SIZE, pad=TICK_PAD, direction="in",
                   bottom=True, top=True, left=True, right=True, width=2.0, length=8)

    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("bold")

    ax.grid(False)

    if legend:
        leg = ax.legend(fontsize=LEGEND_FONT_SIZE, loc=legend_loc, frameon=True,
                        ncol=legend_ncol, title=legend_title)
        if leg is not None:
            leg.set_draggable(True)
            if legend_title is not None:
                plt.setp(leg.get_title(), fontsize=LEGEND_FONT_SIZE, fontweight="bold")


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(0.02, 0.93, label, transform=ax.transAxes, fontsize=PANEL_LABEL_SIZE,
            fontweight="bold", va="top", ha="left")


def keep_feasible_probability_path(sol) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return feasible t, w, y, z values for plotting EGT probability paths."""
    t = sol.t
    w, y, z = sol.y[0, :], sol.y[1, :], sol.y[2, :]
    valid = (w >= -1e-8) & (z >= -1e-8) & ((w + z) <= 1.0 + 1e-8) & (y >= -1e-8) & (y <= 1.0 + 1e-8)
    return t[valid], np.clip(w[valid], 0, 1), np.clip(y[valid], 0, 1), np.clip(z[valid], 0, 1)


# ============================================================
# 1) PARAMETERIZATION
# ============================================================


def make_base_extension_parameters() -> Parameters:
    """Baseline parameters for Section 4.6 extension analysis."""
    return Parameters(
        rho_H=1.0,
        rho_E=1.0,

        # Hydrogen infrastructure extension parameters.
        infra_F_H=0.0,
        infra_lambda_H=4.0,
        infra_eta_H=0.0,
        infra_zeta_H=0.0,
        infra_cap_H=0.70,
        infra_psi_H=0.50,

        # Electric infrastructure extension parameters.
        # infra_F_E and rho_E are varied in the analyses below.
        infra_F_E=0.0,
        infra_lambda_E=4.0,
        infra_eta_E=0.0,
        infra_zeta_E=500.0,
        infra_cap_E=0.70,
        infra_psi_E=0.50,
    )


# ============================================================
# 2) HELPER PLOTS
# ============================================================


def plot_infrastructure_burden_shape(base_params: Parameters) -> None:
    """Plot separate Omega_E(w) figures for representative capacity thresholds."""
    w_grid = np.linspace(0.0, 1.0, 400)
    F_values = [0, 50, 100, 150, 200]
    threshold_values = [0.25, 0.50, 0.70]

    # Optional: use the same marker/color system as the other figures
    for cap_val in threshold_values:
        fig, ax = plt.subplots(figsize=(16, 8))

        for i, F in enumerate(F_values):
            p = replace(base_params, infra_F_E=F, infra_cap_E=cap_val)

            omega_values = [
                infrastructure_entry_burden(
                    strategic_weight=w,
                    fixed_entry_burden=p.infra_F_E,
                    decay_rate=p.infra_lambda_E,
                    marginal_burden=p.infra_eta_E,
                    expansion_burden=p.infra_zeta_E,
                    capacity_threshold=p.infra_cap_E,
                )
                for w in w_grid
            ]

            ax.plot(
                w_grid,
                omega_values,
                color=_cycle(COLORS, i),
                marker=_cycle(MARKERS, i),
                linewidth=LINE_WIDTH,
                markersize=MARKER_SIZE,
                markevery=MARK_EVERY,
                label=fr"$F_E^{{inf}}={F}$",
            )

        # Add the threshold as a vertical dashed line
        ax.axvline(
            cap_val,
            linestyle="--",
            linewidth=2.5,
            color="black",
        )

        # Labels
        ax.set_xlabel(r"$w$", fontsize=TITLE_FONT_SIZE, fontweight="bold")
        ax.set_ylabel(r"$\Omega_E(w)$", fontsize=TITLE_FONT_SIZE, fontweight="bold")

        # Use title if you want
        ax.set_title(
            fr"Capacity threshold = {cap_val:.2f}",
            fontsize=TITLE_FONT_SIZE,
            fontweight="bold",
            pad=12,
        )

        # Formatting
        for spine in ax.spines.values():
            spine.set_linewidth(SPINE_WIDTH)

        ax.tick_params(
            axis="both",
            labelsize=TICK_FONT_SIZE,
            pad=TICK_PAD,
            direction="in",
            bottom=True,
            top=True,
            left=True,
            right=True,
            width=2.0,
            length=8,
        )

        for tick in ax.get_xticklabels() + ax.get_yticklabels():
            tick.set_fontweight("bold")

        ax.grid(False)

        # Legend
        leg = ax.legend(
            loc="upper right",
            frameon=True,
            ncol=2,
            prop={"size": LEGEND_FONT_SIZE, "weight": "bold"},
            title=r"Electric fixed-entry burden",
        )
        leg.set_draggable(True)
        plt.setp(leg.get_title(), fontsize=LEGEND_FONT_SIZE, fontweight="bold")

        plt.tight_layout()

        # File name based on threshold
        if np.isclose(cap_val, 0.25):
            fname = "figure_S46_omegaE_shape_cap025.png"
        elif np.isclose(cap_val, 0.50):
            fname = "figure_S46_omegaE_shape_cap050.png"
        else:
            fname = "figure_S46_omegaE_shape_cap070.png"

        plt.savefig(OUTPUT_DIR / fname, dpi=DPI_SETTING, bbox_inches="tight")
        plt.show()
        plt.close(fig)


# ============================================================
# 3) ANALYSIS 1: rho_E SENSITIVITY
# ============================================================


def plot_rhoE_time_series_sensitivity(base_params, separate_plots=True):
    """Plot rho_E sensitivity for w(t), y(t), and z(t)."""
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]  # [w, y, z]
    t_span = (0.0, 0.20)
    t_eval = np.linspace(t_span[0], t_span[1], 700)

    rho_values = [1.0, 1.1, 1.2, 1.5, 1.55, 1.8, 2.0]

    # --- premium style settings ---
    plt.rcParams["font.family"] = "serif"
    TITLE_FONT_SIZE = 26
    TICK_FONT_SIZE = 20
    LEGEND_FONT_SIZE = 15
    DPI_SETTING = 600
    LINE_WIDTH = 3
    MARKER_SIZE = 8
    MARK_EVERY = 35

    colors = ['blue', 'red', 'lime', 'orange', 'purple', 'brown', 'black']
    markers = ['s', 'o', '^', 'D', 'v', 'P', '*']

    # Solve once and store
    results = []
    for i, rho in enumerate(rho_values):
        p = replace(base_params, rho_E=rho)
        sol = solve_replicator_nonlinear_infrastructure(
            p=p,
            initial_state=initial_state,
            t_span=t_span,
            t_eval=t_eval,
            switches=switches,
        )
        w, y, z = sol.y[0, :], sol.y[1, :], sol.y[2, :]
        results.append((sol.t, w, y, z, colors[i], markers[i], rho))

    def apply_premium_formatting(ax, ylabel):
        for spine in ax.spines.values():
            spine.set_linewidth(3)

        ax.set_xlabel("t", fontsize=TITLE_FONT_SIZE, fontweight='bold')
        ax.set_ylabel(ylabel, fontsize=TITLE_FONT_SIZE, fontweight='bold')

        ax.tick_params(
            axis='both',
            labelsize=TICK_FONT_SIZE,
            direction='in',
            bottom=True, top=True, left=True, right=True,
            pad=8
        )

        for tick in ax.get_xticklabels() + ax.get_yticklabels():
            tick.set_fontweight('bold')

        ax.grid(False)

    if separate_plots:
        variables = [
            ("w", r"$w$", "figure_S46a_rhoE_w.png"),
            ("y", r"$y$", "figure_S46a_rhoE_y.png"),
            ("z", r"$z$", "figure_S46a_rhoE_z.png"),
        ]

        for var_name, ylabel, filename in variables:
            fig, ax = plt.subplots(figsize=(16, 8))

            for t, w, y, z, color, marker, rho in results:
                if var_name == "w":
                    series = w
                elif var_name == "y":
                    series = y
                else:
                    series = z

                ax.plot(
                    t, series,
                    color=color,
                    marker=marker,
                    linewidth=LINE_WIDTH,
                    markersize=MARKER_SIZE,
                    markevery=MARK_EVERY,
                    label=fr"$\rho_E={rho:.2f}$"
                )

            apply_premium_formatting(ax, ylabel)
            legend = ax.legend(
                title=r"Service-equivalency factor",
                loc='upper right',
                frameon=True,
                ncol=2,
                prop={'weight': 'bold', 'size': 22}
            )

            legend.set_title(
                r"Service-equivalency factor",
                prop={'weight': 'bold', 'size': 24}
            )

            legend.set_draggable(True)

            plt.tight_layout()
            plt.savefig(OUTPUT_DIR / filename, dpi=DPI_SETTING, bbox_inches="tight")
            plt.show()

    else:
        fig, axes = plt.subplots(3, 1, figsize=(12, 14), sharex=True,fontweight="bold")
        labels = [r"$w$", r"$y$", r"$z$"]

        for t, w, y, z, color, marker, rho in results:
            axes[0].plot(t, w, color=color, marker=marker, linewidth=LINE_WIDTH,
                         markersize=MARKER_SIZE, markevery=MARK_EVERY,
                         label=fr"$\rho_E={rho:.2f}$")
            axes[1].plot(t, y, color=color, marker=marker, linewidth=LINE_WIDTH,
                         markersize=MARKER_SIZE, markevery=MARK_EVERY)
            axes[2].plot(t, z, color=color, marker=marker, linewidth=LINE_WIDTH,
                         markersize=MARKER_SIZE, markevery=MARK_EVERY)

        for ax, ylabel in zip(axes, labels):
            apply_premium_formatting(ax, ylabel)

        legend = axes[0].legend(
            fontsize=LEGEND_FONT_SIZE,
            title=r"Service-equivalency factor",
            title_fontsize=LEGEND_FONT_SIZE,
            loc='upper right',
            frameon=True,
            ncol=2
        )
        legend.set_draggable(True)

        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "figure_S46a_rhoE_timeseries_w_y_z.png",
                    dpi=DPI_SETTING, bbox_inches="tight")
        plt.show()

# ============================================================
# 4) ANALYSIS 2: NONLINEAR INFRASTRUCTURE-ENTRY SENSITIVITY
# ============================================================


def plot_infra_FE_time_series_sensitivity(base_params: Parameters) -> None:
    """Plot separate w(t), y(t), and z(t) figures under representative electric fixed-entry burdens."""
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]
    t_span = (0.0, 0.20)
    F_values = [0, 250, 500, 750, 1000, 1250, 1500]

    # Store all trajectories first
    results = []
    for i, F in enumerate(F_values):
        p = replace(base_params, infra_F_E=F)
        t, w, y, z = fast_trajectory_nonlinear(
            p=p,
            switches=switches,
            initial_state=initial_state,
            t_end=t_span[1],
            n_steps=1200,
        )

        results.append({
            "F": F,
            "t": t,
            "w": w,
            "y": y,
            "z": z,
            "color": _cycle(COLORS, i),
            "marker": _cycle(MARKERS, i),
            "label": fr"$F_E^{{inf}}={F}$",
        })

    # Separate figures for w, y, and z
    plot_specs = [
        ("w", r"$w$", "figure_S46b_infraFE_w.png"),
        ("y", r"$y$", "figure_S46b_infraFE_y.png"),
        ("z", r"$z$", "figure_S46b_infraFE_z.png"),
    ]

    for var_name, y_label, filename in plot_specs:
        fig, ax = plt.subplots(figsize=(16, 8))

        for item in results:
            ax.plot(
                item["t"],
                item[var_name],
                color=item["color"],
                marker=item["marker"],
                linewidth=LINE_WIDTH,
                markersize=MARKER_SIZE,
                markevery=MARK_EVERY,
                label=item["label"],
            )

        ax.set_xlabel("t", fontsize=TITLE_FONT_SIZE, fontweight="bold")
        ax.set_ylabel(y_label, fontsize=TITLE_FONT_SIZE, fontweight="bold")

        apply_premium_probability_formatting(
            ax,
            legend=True,
            legend_title=r"Electric fixed-entry burden",
            legend_ncol=2,
        )

        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / filename, dpi=DPI_SETTING, bbox_inches="tight")
        plt.show()
        plt.close(fig)




def project_to_simplex_state(x: np.ndarray) -> np.ndarray:
    """Project [w, y, z] to the feasible probability region for fast heatmap integration."""
    x = np.asarray(x, dtype=float)
    x = np.nan_to_num(x, nan=0.0, posinf=1.0, neginf=0.0)
    x = np.clip(x, 0.0, 1.0)
    w, y, z = x
    if w + z > 1.0:
        total = w + z
        w = w / total
        z = z / total
    return np.array([w, y, z], dtype=float)



def fast_trajectory_nonlinear(
    p: Parameters,
    switches: ModelSwitches,
    initial_state: Iterable[float],
    *,
    t_end: float = 0.20,
    n_steps: int = 1200,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Fast fixed-step RK4 trajectory for nonlinear infrastructure time-series plots."""
    h = t_end / n_steps
    x = project_to_simplex_state(np.array(list(initial_state), dtype=float))
    t_values = np.linspace(0.0, t_end, n_steps + 1)
    states = np.zeros((n_steps + 1, 3), dtype=float)

    for k in range(n_steps + 1):
        states[k, :] = x
        if k == n_steps:
            break
        t = k * h
        k1 = np.array(replicator_rhs_nonlinear_infrastructure(t, x, p, switches), dtype=float)
        k2 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k1 / 2.0), p, switches), dtype=float)
        k3 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k2 / 2.0), p, switches), dtype=float)
        k4 = np.array(replicator_rhs_nonlinear_infrastructure(t + h, project_to_simplex_state(x + h * k3), p, switches), dtype=float)
        x = project_to_simplex_state(x + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0)

    return t_values, states[:, 0], states[:, 1], states[:, 2]


def fast_tail_average_nonlinear(
    p: Parameters,
    switches: ModelSwitches,
    initial_state: Iterable[float],
    *,
    t_end: float = 0.20,
    n_steps: int = 1000,
    tail_fraction: float = 0.20,
) -> tuple[float, float, float]:
    """
    Fast fixed-step RK4 integrator used only for the dense heatmap.

    The standard solve_ivp solver is retained for the main time-series figures. For the
    heatmap, this RK4 routine avoids repeated LSODA overhead and keeps the figure script
    practical while preserving the qualitative numerical behavior.
    """
    h = t_end / n_steps
    x = project_to_simplex_state(np.array(list(initial_state), dtype=float))
    tail_start = int((1.0 - tail_fraction) * n_steps)
    tail_values = []

    for k in range(n_steps + 1):
        if k >= tail_start:
            tail_values.append(x.copy())
        if k == n_steps:
            break

        t = k * h
        k1 = np.array(replicator_rhs_nonlinear_infrastructure(t, x, p, switches), dtype=float)
        k2 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k1 / 2.0), p, switches), dtype=float)
        k3 = np.array(replicator_rhs_nonlinear_infrastructure(t + h / 2.0, project_to_simplex_state(x + h * k2 / 2.0), p, switches), dtype=float)
        k4 = np.array(replicator_rhs_nonlinear_infrastructure(t + h, project_to_simplex_state(x + h * k3), p, switches), dtype=float)
        x = project_to_simplex_state(x + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0)

    tail = np.asarray(tail_values)
    return float(np.mean(tail[:, 0])), float(np.mean(tail[:, 1])), float(np.mean(tail[:, 2]))



# ============================================================
# 5) ANALYSIS 3: COMBINED rho_E--F_E HEATMAP
# ============================================================


def tail_average(values: np.ndarray, tail_fraction: float = 0.20) -> float:
    n_tail = max(5, int(len(values) * tail_fraction))
    return float(np.mean(values[-n_tail:]))


def plot_combined_rhoE_infraFE_frontier(base_params: Parameters) -> None:
    """
    Clean viability frontier for joint rho_E and F_E^inf sensitivity.
    For each rho_E, the plot shows the maximum F_E^inf that still supports
    high electric viability, defined by tail-average w >= threshold.
    """
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]
    t_span = (0.0, 0.20)

    rho_values = np.linspace(1.0, 2.0, 31)
    F_values = np.linspace(0, 1500, 61)

    viability_threshold = 0.60
    frontier_F = []

    for rho in rho_values:
        viable_F_values = []

        for F in F_values:
            p = replace(base_params, rho_E=float(rho), infra_F_E=float(F))

            w_bar, y_bar, z_bar = fast_tail_average_nonlinear(
                p=p,
                switches=switches,
                initial_state=initial_state,
                t_end=t_span[1],
                n_steps=800,
                tail_fraction=0.20,
            )

            if w_bar >= viability_threshold:
                viable_F_values.append(F)

        if len(viable_F_values) > 0:
            frontier_F.append(max(viable_F_values))
        else:
            frontier_F.append(np.nan)

    fig, ax = plt.subplots(figsize=(16, 8))

    ax.plot(
        rho_values,
        frontier_F,
        color="black",
        marker="s",
        linewidth=LINE_WIDTH,
        markersize=MARKER_SIZE,
        markevery=3,
        label=fr"Electric viability frontier ($\bar{{w}}_{{tail}}\geq {viability_threshold}$)",
    )

    ax.set_xlabel(r"$\rho_E$", fontsize=TITLE_FONT_SIZE, fontweight="bold")
    ax.set_ylabel(r"Maximum $F_E^{inf}$", fontsize=TITLE_FONT_SIZE, fontweight="bold")

    for spine in ax.spines.values():
        spine.set_linewidth(SPINE_WIDTH)

    ax.tick_params(
        axis="both",
        labelsize=TICK_FONT_SIZE,
        pad=TICK_PAD,
        direction="in",
        bottom=True,
        top=True,
        left=True,
        right=True,
        width=2.0,
        length=8,
    )

    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("bold")

    ax.grid(False)

    leg = ax.legend(
        loc="upper right",
        frameon=True,
        prop={"size": LEGEND_FONT_SIZE, "weight": "bold"},
    )
    leg.set_draggable(True)

    plt.tight_layout()
    plt.savefig(
        OUTPUT_DIR / "figure_S46c_rhoE_infraFE_viability_frontier.png",
        dpi=DPI_SETTING,
        bbox_inches="tight",
    )
    plt.show()
    plt.close(fig)

    np.savez(
        OUTPUT_DIR / "figure_S46c_frontier_data.npz",
        rho_values=rho_values,
        F_values=F_values,
        frontier_F=np.array(frontier_F),
        viability_threshold=viability_threshold,
    )


# ============================================================
# 6) FINAL STATE TABLES FOR INTERPRETATION
# ============================================================


def print_final_states_for_FE(base_params: Parameters) -> None:
    switches = ModelSwitches()
    initial_state = [0.2, 0.7, 0.1]
    t_span = (0.0, 0.20)
    t_eval = np.linspace(t_span[0], t_span[1], 700)
    F_values = [0, 250, 500, 750, 1000, 1250, 1500]

    print("\nFinal states under nonlinear infrastructure-entry extension")
    print("=" * 96)
    print(f"{'F_E^inf':>10} | {'w_final':>10} | {'y_final':>10} | {'z_final':>10} | {'Omega_E':>12} | {'Omega_H':>12}")
    print("-" * 96)
    for F in F_values:
        p = replace(base_params, infra_F_E=F)
        _, w_path, y_path, z_path = fast_trajectory_nonlinear(
            p=p,
            switches=switches,
            initial_state=initial_state,
            t_end=t_span[1],
            n_steps=1200,
        )
        w, y, z = w_path[-1], y_path[-1], z_path[-1]
        burdens = compute_infrastructure_burdens(w=w, z=z, p=p)
        print(f"{F:10.2f} | {w:10.4f} | {y:10.4f} | {z:10.4f} | {burdens['Omega_E']:12.4f} | {burdens['Omega_H']:12.4f}")
    print("=" * 96)


# ============================================================
# 7) MAIN
# ============================================================


def main() -> None:
    print("Section 4.6 premium plotting scripts are separated to keep each run stable and fast.")
    print("Run these commands one by one:")
    print("  python run_section46_omega_shape.py")
    print("  python run_section46_rhoE_timeseries.py")
    print("  python run_section46_infraFE_timeseries.py")
    print("  python run_section46_combined_heatmap.py")
    print(f"Outputs will be saved in: {OUTPUT_DIR.resolve()}")

if __name__ == "__main__":
    main()
