"""Run Analysis 1: service-equivalency sensitivity for rho_E."""
from run_section46_premium_analysis import make_base_extension_parameters, plot_rhoE_time_series_sensitivity, OUTPUT_DIR

if __name__ == "__main__":
    plot_rhoE_time_series_sensitivity(
        make_base_extension_parameters(),
        separate_plots=True
    )
    print(f"Figures saved in: {OUTPUT_DIR.resolve()}")