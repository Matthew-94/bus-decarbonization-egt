# =============================================================================
# PHASE 4C-1
# PUBLICATION-QUALITY MAIN SCENARIO FIGURES
# =============================================================================

import numpy as np
import matplotlib.pyplot as plt

from transit_model_phase4B import (
    make_scenario,
    solve_replicator,
    policy_thresholds,
    expected_operator_payoffs,
)


# =============================================================================
# SETTINGS
# =============================================================================

INITIAL_STATE = (0.05, 0.15, 0.20)   # [z, w, y]

TAU_SPAN = (0.0, 80.0)
N_POINTS = 4001

SCENARIOS = ["S1", "S2", "S3"]


# Professional restrained palette
COLOR_H = "#333333"
COLOR_E = "#557A95"
COLOR_D = "#999999"
COLOR_Y = "#8B5E5E"

LINEWIDTH = 2.2


# =============================================================================
# HELPER
# =============================================================================

def interpolated_crossing(tau, values, threshold):

    tau = np.asarray(tau)
    values = np.asarray(values)

    shifted = values - threshold

    idx = np.where(
        shifted[:-1] * shifted[1:] <= 0
    )[0]

    if len(idx) == 0:
        return np.nan

    i = idx[0]

    t0 = tau[i]
    t1 = tau[i + 1]

    v0 = values[i]
    v1 = values[i + 1]

    if abs(v1 - v0) < 1e-14:
        return float(t0)

    f = (
        (threshold - v0)
        / (v1 - v0)
    )

    return float(
        t0 + f * (t1 - t0)
    )


# =============================================================================
# FIGURE 1
# THREE-SCENARIO EVOLUTIONARY TRAJECTORIES
# =============================================================================

fig, axes = plt.subplots(
    1,
    3,
    figsize=(15, 4.6),
    sharex=True,
    sharey=True,
)

for ax, scenario_name in zip(
    axes,
    SCENARIOS,
):

    p = make_scenario(
        scenario_name
    )

    sol = solve_replicator(
        p=p,
        initial_state=INITIAL_STATE,
        tau_span=TAU_SPAN,
        n_points=N_POINTS,
    )

    tau = sol.t

    z = sol.y[0]
    w = sol.y[1]
    y = sol.y[2]

    D = 1.0 - z - w

    ax.plot(
        tau,
        z,
        linewidth=LINEWIDTH,
        color=COLOR_H,
        label="Hydrogen share, $z$",
    )

    ax.plot(
        tau,
        w,
        linewidth=LINEWIDTH,
        color=COLOR_E,
        label="Electric share, $w$",
    )

    ax.plot(
        tau,
        D,
        linewidth=LINEWIDTH,
        color=COLOR_D,
        linestyle="--",
        label="Diesel share",
    )

    ax.plot(
        tau,
        y,
        linewidth=LINEWIDTH,
        color=COLOR_Y,
        linestyle=":",
        label="Policy weight, $y$",
    )

    # -------------------------------------------------------------
    # S3 H-E threshold
    # -------------------------------------------------------------

    thresholds = policy_thresholds(
        p
    )

    y_HE = thresholds["y_HE"]

    if 0.0 <= y_HE <= 1.0:

        tau_switch = interpolated_crossing(
            tau,
            y,
            y_HE,
        )

        if np.isfinite(
            tau_switch
        ):

            ax.axvline(
                tau_switch,
                color="black",
                linestyle="-.",
                linewidth=1.4,
            )

            ax.text(
                tau_switch + 1.2,
                0.48,
                r"$y=y_{HE}^{*}$",
                rotation=90,
                va="center",
                fontsize=10,
            )

    ax.set_title(
        scenario_name,
        fontsize=13,
        fontweight="bold",
    )

    ax.set_xlabel(
        r"Normalized evolutionary time, $\tau$",
        fontsize=11,
    )

    ax.set_xlim(
        TAU_SPAN
    )

    ax.set_ylim(
        -0.02,
        1.02,
    )

    ax.tick_params(
        labelsize=10
    )

axes[0].set_ylabel(
    "Evolutionary strategy weight",
    fontsize=11,
)

# One shared legend
handles, labels = axes[0].get_legend_handles_labels()

fig.legend(
    handles,
    labels,
    loc="lower center",
    ncol=4,
    frameon=False,
    bbox_to_anchor=(0.5, -0.04),
    fontsize=10,
)

plt.tight_layout(
    rect=[0, 0.08, 1, 1]
)

plt.savefig(
    "Fig_main_scenario_dynamics.pdf",
    bbox_inches="tight",
)

plt.savefig(
    "Fig_main_scenario_dynamics.png",
    dpi=600,
    bbox_inches="tight",
)

plt.show()


# =============================================================================
# FIGURE 2
# S3 POLICY-INDUCED H-E PAYOFF REVERSAL
# =============================================================================

p = make_scenario("S3")

y_grid = np.linspace(
    0.0,
    1.0,
    1001,
)

Pi_H = np.zeros_like(
    y_grid
)

Pi_E = np.zeros_like(
    y_grid
)

Pi_D = np.zeros_like(
    y_grid
)

for i, yi in enumerate(
    y_grid
):

    op = expected_operator_payoffs(
        y=float(yi),
        p=p,
    )

    Pi_H[i] = op["Pi_H"]
    Pi_E[i] = op["Pi_E"]
    Pi_D[i] = op["Pi_D"]


y_HE = policy_thresholds(
    p
)["y_HE"]


fig, ax = plt.subplots(
    figsize=(7.2, 5.0)
)

ax.plot(
    y_grid,
    Pi_H,
    color=COLOR_H,
    linewidth=2.4,
    label=r"$\Pi_H(y)$",
)

ax.plot(
    y_grid,
    Pi_E,
    color=COLOR_E,
    linewidth=2.4,
    label=r"$\Pi_E(y)$",
)

ax.plot(
    y_grid,
    Pi_D,
    color=COLOR_D,
    linewidth=2.2,
    linestyle="--",
    label=r"$\Pi_D(y)$",
)

ax.axvline(
    y_HE,
    color="black",
    linestyle="-.",
    linewidth=1.5,
)

Pi_switch = np.interp(
    y_HE,
    y_grid,
    Pi_H,
)

ax.scatter(
    [y_HE],
    [Pi_switch],
    s=45,
    color="black",
    zorder=5,
)

ax.annotate(
    (
        r"$y_{HE}^{*}=%.2f$"
        "\nH--E payoff reversal"
    ) % y_HE,
    xy=(
        y_HE,
        Pi_switch,
    ),
    xytext=(
        0.43,
        Pi_switch + 0.35,
    ),
    arrowprops=dict(
        arrowstyle="->",
        linewidth=1.0,
    ),
    fontsize=10,
)

ax.text(
    0.17,
    2.48,
    "Electric-favorable\nselection pressure",
    ha="center",
    fontsize=10,
)

ax.text(
    0.85,
    2.48,
    "Hydrogen-favorable\nselection pressure",
    ha="center",
    fontsize=10,
)

ax.set_xlabel(
    r"Active-policy weight, $y$",
    fontsize=11,
)

ax.set_ylabel(
    "Expected operator payoff (CAD/RVK)",
    fontsize=11,
)

ax.set_xlim(
    0.0,
    1.0,
)

ax.legend(
    frameon=False,
    fontsize=10,
)

ax.tick_params(
    labelsize=10
)

plt.tight_layout()

plt.savefig(
    "Fig_S3_policy_payoff_reversal.pdf",
    bbox_inches="tight",
)

plt.savefig(
    "Fig_S3_policy_payoff_reversal.png",
    dpi=600,
    bbox_inches="tight",
)

plt.show()