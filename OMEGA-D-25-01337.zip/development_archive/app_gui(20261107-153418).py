from __future__ import annotations

import ast
import csv
import io
import os
import queue
import sys
import threading
import time
import traceback
from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from dataclasses import fields, asdict
from pathlib import Path
from typing import Optional # Added to fix older Python version crashes
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
import numpy as np

# Import core model components
from transit_model import (
    Parameters,
    ModelSwitches,
    solve_multiple_initial_conditions,
    classify_with_multiple_initial_conditions,
    classify_3d_sensitivity,
    plot_clean_regional_map,
    plot_3d_regional_map,
    plot_3d_voxel_region_map,
    print_ess_combinations_report,
    classify_basin_of_attraction,
    plot_basin_of_attraction
)

# ============================================================
# DICTIONARIES FOR UI LABELS
# ============================================================

PARAM_DEFS = {
    'f_H': ('f_H', 'Hydrogen bus frequency'),
    'f_E': ('f_E', 'Electric bus frequency'),
    'f_D': ('f_D', 'Diesel bus frequency'),
    'distance_km': ('L', 'Route distance (km)'),
    'fare_t': ('t', 'Transit fare'),
    'theta': ('θ', 'Greenness parameter (H) active'),
    'theta_prime': ("θ'", 'Greenness parameter (H) inactive'),
    'phi': ('φ', 'Greenness parameter (E) active'),
    'phi_prime': ("φ'", 'Greenness parameter (E) inactive'),
    'vartheta': ('ϑ', 'Consumer preference param'),
    'vartheta_prime': ("ϑ'", 'Consumer preference param (inactive)'),
    'mu': ('μ', 'Behavioral sensitivity param'),
    'mu_prime': ("μ'", 'Behavioral sensitivity param (inactive)'),
    'delta': ('δ', 'Decay/discount factor'),
    'delta_prime': ("δ'", 'Decay/discount factor (inactive)'),
    'gamma': ('γ', 'Scale parameter'),
    'gamma_prime': ("γ'", 'Scale parameter (inactive)'),
    'S_H': ('S_H', 'Hydrogen Subsidy'),
    'S_E': ('S_E', 'Electric Subsidy'),
    'tax_T': ('T', 'Diesel Tax'),
    'R_H': ('R_H', 'Hydrogen Initial Cost'),
    'R_E': ('R_E', 'Electric Initial Cost'),
    'R_D': ('R_D', 'Diesel Initial Cost'),
    'rho_H': ('ρ_H', 'Hydrogen service-equivalency factor'),
    'rho_E': ('ρ_E', 'Electric service-equivalency factor'),
    'infra_F_H': ('F_H^inf', 'Hydrogen fixed infrastructure-entry burden'),
    'infra_F_E': ('F_E^inf', 'Electric fixed infrastructure-entry burden'),
    'infra_lambda_H': ('λ_H^inf', 'Hydrogen infrastructure burden decay rate'),
    'infra_lambda_E': ('λ_E^inf', 'Electric infrastructure burden decay rate'),
    'infra_eta_H': ('η_H^inf', 'Hydrogen marginal infrastructure burden'),
    'infra_eta_E': ('η_E^inf', 'Electric marginal infrastructure burden'),
    'infra_zeta_H': ('ζ_H^inf', 'Hydrogen capacity-expansion burden'),
    'infra_zeta_E': ('ζ_E^inf', 'Electric capacity-expansion burden'),
    'infra_cap_H': ('cap_H^inf', 'Hydrogen initial infrastructure capacity threshold'),
    'infra_cap_E': ('cap_E^inf', 'Electric initial infrastructure capacity threshold'),
    'infra_psi_H': ('ψ_H', 'PA share of hydrogen infrastructure burden under policy'),
    'infra_psi_E': ('ψ_E', 'PA share of electric infrastructure burden under policy'),
    'c_p': ('c_p', 'Environmental cost multiplier'),
    'xi_H': ('ξ_H', 'Hydrogen emissions factor'),
    'xi_E': ('ξ_E', 'Electric emissions factor'),
    'xi_D': ('ξ_D', 'Diesel emissions factor'),
    'q_H': ('q_H', 'Hydrogen demand'),
    'q_E': ('q_E', 'Electric demand'),
    'q_D': ('q_D', 'Diesel demand'),
    'C_H': ('C_H', 'Hydrogen operating cost (active)'),
    'C_E': ('C_E', 'Electric operating cost (active)'),
    'C_D': ('C_D', 'Diesel operating cost (active)'),
    'chi_H': ('χ_H', 'Hydrogen operating cost (inactive)'),
    'chi_E': ('χ_E', 'Electric operating cost (inactive)'),
    'chi_D': ('χ_D', 'Diesel operating cost (inactive)'),
    'CS': ('CS', 'Consumer Surplus base value'),
}

SWITCH_DEFS = {
    'use_h_subsidy': 'Apply Hydrogen Subsidy',
    'use_e_subsidy': 'Apply Electric Subsidy',
    'use_d_tax': 'Apply Diesel Tax',
    'use_h_greenness_penalty': 'Apply Hydrogen Greenness Penalty',
    'use_e_greenness_penalty': 'Apply Electric Greenness Penalty'
}

SCALAR_PARAM_NAMES = list(PARAM_DEFS.keys())
SWITCH_NAMES = list(SWITCH_DEFS.keys())
IMAGE_EXTS = {'.png', '.jpg', '.jpeg'}

# ============================================================
# UTILITY CLASSES
# ============================================================

def safe_float(value, default=0.0):
    try: return float(value)
    except Exception: return default

class QueueWriter:
    def __init__(self, gui, is_error: bool = False):
        self.gui = gui
        self.is_error = is_error

    def write(self, data):
        if not data: return 0
        text = str(data)
        if self.is_error and text.strip(): self.gui.log_queue.put('[stderr] ' + text)
        else: self.gui.log_queue.put(text)
        return len(text)

    def flush(self): return None

class ScrollableFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.vbar = ttk.Scrollbar(self, orient='vertical', command=self.canvas.yview)
        self.hbar = ttk.Scrollbar(self, orient='horizontal', command=self.canvas.xview)
        self.inner = ttk.Frame(self.canvas)
        self.inner.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.create_window((0, 0), window=self.inner, anchor='nw')
        self.canvas.configure(yscrollcommand=self.vbar.set, xscrollcommand=self.hbar.set)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        self.vbar.grid(row=0, column=1, sticky='ns')
        self.hbar.grid(row=1, column=0, sticky='ew')
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        

class ZoomableImageWindow(tk.Toplevel):
    def __init__(self, master, path: Path):
        super().__init__(master)
        self.title(path.name)
        self.geometry('1280x920')
        self.path = Path(path)
        self.original = Image.open(self.path)
        self.zoom = 1.0
        self.min_zoom = 0.1
        self.max_zoom = 8.0
        self._photo = None

        top = ttk.Frame(self, padding=8)
        top.pack(fill='x')
        ttk.Button(top, text='Fit', command=self.fit_to_window).pack(side='left')
        ttk.Button(top, text='100%', command=self.reset_zoom).pack(side='left', padx=(6, 0))
        ttk.Button(top, text='Zoom In', command=lambda: self.change_zoom(1.2)).pack(side='left', padx=(12, 0))
        ttk.Button(top, text='Zoom Out', command=lambda: self.change_zoom(1/1.2)).pack(side='left', padx=(6, 0))
        self.zoom_label = ttk.Label(top, text='100%')
        self.zoom_label.pack(side='left', padx=(12, 0))

        self.canvas = tk.Canvas(self, bg='#1f1f1f', highlightthickness=0)
        self.hbar = ttk.Scrollbar(self, orient='horizontal', command=self.canvas.xview)
        self.vbar = ttk.Scrollbar(self, orient='vertical', command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.hbar.set, yscrollcommand=self.vbar.set)
        self.canvas.pack(fill='both', expand=True, side='left')
        self.vbar.pack(fill='y', side='right')
        self.hbar.pack(fill='x', side='bottom')

        self.canvas.bind('<Configure>', lambda e: self._render())
        self.canvas.bind('<MouseWheel>', self._on_mousewheel)
        self.after(120, self.fit_to_window)

    def _on_mousewheel(self, event):
        factor = 1.1 if event.delta > 0 else 1 / 1.1
        self.change_zoom(factor, (event.x, event.y))

    def fit_to_window(self):
        cw, ch = max(self.canvas.winfo_width(), 1), max(self.canvas.winfo_height(), 1)
        iw, ih = self.original.size
        self.zoom = max(self.min_zoom, min(cw / iw, ch / ih, self.max_zoom))
        self._render()

    def reset_zoom(self):
        self.zoom = 1.0
        self._render()

    def change_zoom(self, factor, center=None):
        self.zoom = max(self.min_zoom, min(self.zoom * factor, self.max_zoom))
        self._render(center=center)

    def _render(self, center=None):
        new_size = (max(1, int(self.original.size[0] * self.zoom)), max(1, int(self.original.size[1] * self.zoom)))
        self._photo = ImageTk.PhotoImage(self.original.resize(new_size, Image.Resampling.LANCZOS))
        self.canvas.delete('all')
        self.canvas.create_image(0, 0, image=self._photo, anchor='nw')
        self.canvas.configure(scrollregion=(0, 0, new_size[0], new_size[1]))
        self.zoom_label.configure(text=f'{self.zoom * 100:.0f}%')


# ============================================================
# MAIN GUI CLASS
# ============================================================

class TransitGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Transit Agency & Public Authority Model - Parameter Interface')
        self.geometry('1650x980')
        self.minsize(1360, 820)

        self.scalar_vars: dict[str, tk.StringVar] = {}
        self.switch_vars: dict[str, tk.BooleanVar] = {}
        self.text_widgets: dict[str, tk.Text] = {}
        
        self.use_defaults_var = tk.BooleanVar(value=True)
        self.scenario_name_var = tk.StringVar(value="Scenario_1")
        self.status_var = tk.StringVar(value='Ready.')
        
        self.current_output_dir: Optional[Path] = None
        self.figure_cache: dict[tuple[str, int], tk.PhotoImage] = {}
        self.figure_paths: list[Path] = []
        self.log_queue: queue.Queue[str] = queue.Queue()

        # Basin of Attraction Variables
        self.basin_z0_var = tk.StringVar(value='0.2')
        self.basin_res_var = tk.StringVar(value='30')
        self.basin_w_min_var = tk.StringVar(value='0.01')
        self.basin_w_max_var = tk.StringVar(value='0.99')
        self.basin_y_min_var = tk.StringVar(value='0.01')
        self.basin_y_max_var = tk.StringVar(value='0.99')

        # 2D Sens Variables
        self.selected_target_var = tk.StringVar(value='No X-Axis selected')
        self.sens_range_from_var = tk.StringVar()
        self.sens_range_to_var = tk.StringVar()
        self.sens_step_var = tk.StringVar(value='15')
        self.sens_y_target_var = tk.StringVar(value='No Y-Axis selected')
        self.sens_y_from_var = tk.StringVar()
        self.sens_y_to_var = tk.StringVar()
        self.sens_y_step_var = tk.StringVar(value='10')

        # 3D Sens Variables
        self.sens3_x_target = tk.StringVar(value='No X selected')
        self.sens3_x_from, self.sens3_x_to, self.sens3_x_step = tk.StringVar(), tk.StringVar(), tk.StringVar(value='5')
        self.sens3_y_target = tk.StringVar(value='No Y selected')
        self.sens3_y_from, self.sens3_y_to, self.sens3_y_step = tk.StringVar(), tk.StringVar(), tk.StringVar(value='5')
        self.sens3_z_target = tk.StringVar(value='No Z selected')
        self.sens3_z_from, self.sens3_z_to, self.sens3_z_step = tk.StringVar(), tk.StringVar(), tk.StringVar(value='5')

        self._build_ui()
        self.after(100, self._flush_log_queue)
        self.load_defaults()

    def _build_ui(self):
        outer = ttk.Frame(self, padding=10)
        outer.pack(fill='both', expand=True)
        outer.rowconfigure(1, weight=1)
        outer.columnconfigure(0, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky='ew', pady=(0, 8))
        top.columnconfigure(12, weight=1)

        ttk.Button(top, text='Load Defaults', command=self.load_defaults).grid(row=0, column=1, padx=4)
        ttk.Label(top, text="Scenario Name:").grid(row=0, column=2, padx=(20, 2))
        ttk.Entry(top, textvariable=self.scenario_name_var, width=20).grid(row=0, column=3, padx=2)
        
        ttk.Button(top, text='Run Standard Sim', command=self.start_standard_run).grid(row=0, column=5, padx=(20, 4))
        ttk.Button(top, text='Run Time-Series Sim', command=self.start_time_series_run).grid(row=0, column=6, padx=4)
        ttk.Button(top, text='Run 2D Map', command=self.start_sensitivity_run).grid(row=0, column=7, padx=4)
        ttk.Button(top, text='Run 3D Region Map', command=self.start_3d_run).grid(row=0, column=8, padx=4)
        ttk.Button(top, text='Run 3D Plate Map', command=self.start_3d_plate_run).grid(row=0, column=9, padx=4)
        ttk.Button(top, text='Refresh Figures', command=self.refresh_figures).grid(row=0, column=10, padx=4)
        ttk.Label(top, textvariable=self.status_var).grid(row=0, column=12, sticky='e')

        self.notebook = ttk.Notebook(outer)
        self.notebook.grid(row=1, column=0, sticky='nsew')

        self.params_tab = ScrollableFrame(self.notebook)
        self.settings_tab = ttk.Frame(self.notebook, padding=10)
        self.sensitivity_tab = ttk.Frame(self.notebook, padding=10)
        self.sens_3d_tab = ttk.Frame(self.notebook, padding=10)
        self.basin_tab = ttk.Frame(self.notebook, padding=10)
        self.log_tab = ttk.Frame(self.notebook, padding=10)
        self.figures_tab = ttk.Frame(self.notebook, padding=10)

        self.notebook.add(self.params_tab, text='Scalar Parameters')
        self.notebook.add(self.settings_tab, text='Settings & IC')
        self.notebook.add(self.sensitivity_tab, text='2D Robust Analysis')
        self.notebook.add(self.sens_3d_tab, text='3D Robust Analysis')
        self.notebook.add(self.basin_tab, text='Basins of Attraction') 
        self.notebook.add(self.log_tab, text='Run Log')
        self.notebook.add(self.figures_tab, text='Figures')

        self._build_params_tab()
        self._build_settings_tab()
        self._build_sensitivity_tab()
        self._build_3d_tab()
        self._build_basin_tab()
        self._build_log_tab()
        self._build_figures_tab()

    def _build_params_tab(self):
        container = self.params_tab.inner
        container.columnconfigure(0, weight=1)
        container.columnconfigure(1, weight=1)

        left = ttk.LabelFrame(container, text='Demand & Economics', padding=8)
        right = ttk.LabelFrame(container, text='Penalties & Emissions', padding=8)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 8), pady=4)
        right.grid(row=0, column=1, sticky='nsew', padx=(8, 0), pady=4)

        split_index = len(SCALAR_PARAM_NAMES) // 2
        for panel, names in [(left, SCALAR_PARAM_NAMES[:split_index]), (right, SCALAR_PARAM_NAMES[split_index:])]:
            for i, name in enumerate(names, start=1):
                symbol, definition = PARAM_DEFS[name]
                ttk.Label(panel, text=symbol).grid(row=i, column=0, sticky='w', padx=4, pady=2)
                ttk.Label(panel, text=definition, wraplength=250, justify='left').grid(row=i, column=1, sticky='w', padx=4, pady=2)
                var = tk.StringVar()
                self.scalar_vars[name] = var
                ttk.Entry(panel, textvariable=var, width=15).grid(row=i, column=2, sticky='ew', padx=4, pady=2)

    def _build_settings_tab(self):
        self.settings_tab.columnconfigure(0, weight=1)
        self.settings_tab.columnconfigure(1, weight=1)

        switches_frame = ttk.LabelFrame(self.settings_tab, text='Policy Switches', padding=8)
        switches_frame.grid(row=0, column=0, sticky='nsew', padx=(0, 8), pady=8)
        for i, name in enumerate(SWITCH_NAMES):
            var = tk.BooleanVar()
            self.switch_vars[name] = var
            ttk.Checkbutton(switches_frame, text=SWITCH_DEFS[name], variable=var).grid(row=i, column=0, sticky='w', pady=4)

        ic_frame = ttk.LabelFrame(self.settings_tab, text='Simulation Settings', padding=8)
        ic_frame.grid(row=0, column=1, sticky='nsew', padx=(8, 0), pady=8)
        
        ttk.Label(ic_frame, text='Initial Conditions List ([w, y, z])').grid(row=0, column=0, sticky='w')
        ic_txt = tk.Text(ic_frame, height=8, width=40)
        ic_txt.grid(row=1, column=0, sticky='ew', pady=4)
        self.text_widgets['initial_conditions'] = ic_txt

        ttk.Label(ic_frame, text='Simulation t_span end (e.g. 50.0)').grid(row=2, column=0, sticky='w', pady=(8,0))
        self.t_span_var = tk.StringVar(value='0.2')
        ttk.Entry(ic_frame, textvariable=self.t_span_var).grid(row=3, column=0, sticky='w', pady=4)

    def _build_sensitivity_tab(self):
        self.sensitivity_tab.columnconfigure(0, weight=1)
        self.sensitivity_tab.columnconfigure(1, weight=1)
        self.sensitivity_tab.rowconfigure(1, weight=1)

        controls = ttk.Frame(self.sensitivity_tab)
        controls.grid(row=0, column=0, columnspan=2, sticky='ew', pady=(0, 10))
        
        def build_ctrl(parent, title, tgt_var, from_var, to_var, step_var):
            f = ttk.LabelFrame(parent, text=title, padding=10)
            ttk.Label(f, textvariable=tgt_var, font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, columnspan=2, sticky='w', pady=4)
            ttk.Label(f, text='From:').grid(row=1, column=0, sticky='w'); ttk.Entry(f, textvariable=from_var).grid(row=1, column=1, sticky='ew')
            ttk.Label(f, text='To:').grid(row=2, column=0, sticky='w'); ttk.Entry(f, textvariable=to_var).grid(row=2, column=1, sticky='ew')
            ttk.Label(f, text='Steps (N):').grid(row=3, column=0, sticky='w'); ttk.Entry(f, textvariable=step_var).grid(row=3, column=1, sticky='ew')
            return f

        left_ctrl = build_ctrl(controls, 'X-Axis Parameter', self.selected_target_var, self.sens_range_from_var, self.sens_range_to_var, self.sens_step_var)
        left_ctrl.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        right_ctrl = build_ctrl(controls, 'Y-Axis Parameter', self.sens_y_target_var, self.sens_y_from_var, self.sens_y_to_var, self.sens_y_step_var)
        right_ctrl.grid(row=0, column=1, sticky='nsew', padx=(8, 0))

        trees = ttk.Frame(self.sensitivity_tab)
        trees.grid(row=1, column=0, columnspan=2, sticky='nsew')
        trees.columnconfigure(0, weight=1); trees.columnconfigure(1, weight=1); trees.rowconfigure(0, weight=1)

        def build_tree(parent, title, bind_cmd):
            frame = ttk.LabelFrame(parent, text=title, padding=8)
            tree = ttk.Treeview(frame, columns=('name', 'sym', 'def'), show='headings')
            for col, text, w in [('name', 'Code Name', 100), ('sym', 'Sym', 50), ('def', 'Definition', 200)]:
                tree.heading(col, text=text); tree.column(col, width=w)
            tree.pack(fill='both', expand=True); tree.bind('<<TreeviewSelect>>', bind_cmd)
            for name in SCALAR_PARAM_NAMES: tree.insert('', 'end', values=(name, PARAM_DEFS[name][0], PARAM_DEFS[name][1]))
            return frame, tree

        x_frame, self.target_tree_x = build_tree(trees, 'Select X-Axis', self.on_target_x_selected)
        x_frame.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        y_frame, self.target_tree_y = build_tree(trees, 'Select Y-Axis', self.on_target_y_selected)
        y_frame.grid(row=0, column=1, sticky='nsew', padx=(8, 0))

    def _build_3d_tab(self):
        self.sens_3d_tab.columnconfigure(0, weight=1); self.sens_3d_tab.columnconfigure(1, weight=1); self.sens_3d_tab.columnconfigure(2, weight=1)
        self.sens_3d_tab.rowconfigure(1, weight=1)

        controls = ttk.Frame(self.sens_3d_tab)
        controls.grid(row=0, column=0, columnspan=3, sticky='ew', pady=(0, 10))
        
        def build_ctrl(parent, title, tgt_var, from_var, to_var, step_var):
            f = ttk.LabelFrame(parent, text=title, padding=10)
            ttk.Label(f, textvariable=tgt_var, font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, columnspan=2, sticky='w', pady=4)
            ttk.Label(f, text='From:').grid(row=1, column=0, sticky='w'); ttk.Entry(f, textvariable=from_var).grid(row=1, column=1, sticky='ew')
            ttk.Label(f, text='To:').grid(row=2, column=0, sticky='w'); ttk.Entry(f, textvariable=to_var).grid(row=2, column=1, sticky='ew')
            ttk.Label(f, text='Steps (N):').grid(row=3, column=0, sticky='w'); ttk.Entry(f, textvariable=step_var).grid(row=3, column=1, sticky='ew')
            return f

        build_ctrl(controls, 'X-Axis', self.sens3_x_target, self.sens3_x_from, self.sens3_x_to, self.sens3_x_step).grid(row=0, column=0, sticky='nsew', padx=(0, 5))
        build_ctrl(controls, 'Y-Axis', self.sens3_y_target, self.sens3_y_from, self.sens3_y_to, self.sens3_y_step).grid(row=0, column=1, sticky='nsew', padx=(5, 5))
        build_ctrl(controls, 'Z-Axis', self.sens3_z_target, self.sens3_z_from, self.sens3_z_to, self.sens3_z_step).grid(row=0, column=2, sticky='nsew', padx=(5, 0))

        trees = ttk.Frame(self.sens_3d_tab)
        trees.grid(row=1, column=0, columnspan=3, sticky='nsew')
        trees.columnconfigure(0, weight=1); trees.columnconfigure(1, weight=1); trees.columnconfigure(2, weight=1); trees.rowconfigure(0, weight=1)

        def build_tree(parent, title, bind_cmd):
            frame = ttk.LabelFrame(parent, text=title, padding=8)
            tree = ttk.Treeview(frame, columns=('name', 'sym'), show='headings')
            tree.heading('name', text='Name'); tree.column('name', width=100)
            tree.heading('sym', text='Sym'); tree.column('sym', width=50)
            tree.pack(fill='both', expand=True); tree.bind('<<TreeviewSelect>>', bind_cmd)
            for name in SCALAR_PARAM_NAMES: tree.insert('', 'end', values=(name, PARAM_DEFS[name][0]))
            return frame, tree

        xf, self.tree3_x = build_tree(trees, 'Select X Parameter', self.on_3d_x_sel)
        yf, self.tree3_y = build_tree(trees, 'Select Y Parameter', self.on_3d_y_sel)
        zf, self.tree3_z = build_tree(trees, 'Select Z Parameter', self.on_3d_z_sel)
        xf.grid(row=0, column=0, sticky='nsew', padx=(0, 5)); yf.grid(row=0, column=1, sticky='nsew', padx=(5, 5)); zf.grid(row=0, column=2, sticky='nsew', padx=(5, 0))

    def _build_log_tab(self):
        self.log_tab.rowconfigure(0, weight=1); self.log_tab.columnconfigure(0, weight=1)
        txt = tk.Text(self.log_tab, wrap='word', font=('Consolas', 11))
        txt.grid(row=0, column=0, sticky='nsew')
        self.text_widgets['log'] = txt

    def _build_figures_tab(self):
        self.figures_tab.rowconfigure(1, weight=1)
        self.figures_tab.columnconfigure(0, weight=1); self.figures_tab.columnconfigure(1, weight=3)

        header = ttk.Frame(self.figures_tab)
        header.grid(row=0, column=0, columnspan=2, sticky='ew', pady=(0, 8))
        self.figure_dir_var = tk.StringVar(value='Run a simulation to generate figures.')
        ttk.Label(header, textvariable=self.figure_dir_var).pack(side='left')

        left = ttk.LabelFrame(self.figures_tab, text='Saved Figures', padding=8)
        left.grid(row=1, column=0, sticky='nsew', padx=(0, 8))
        left.rowconfigure(0, weight=1); left.columnconfigure(0, weight=1)

        self.figure_list = tk.Listbox(left)
        self.figure_list.grid(row=0, column=0, sticky='nsew')
        self.figure_list.bind('<<ListboxSelect>>', self.show_selected_figure)
        self.figure_list.bind('<Double-1>', self.open_zoom_window)

        right = ttk.LabelFrame(self.figures_tab, text='Preview (Double-Click List to Zoom)', padding=8)
        right.grid(row=1, column=1, sticky='nsew')
        right.rowconfigure(0, weight=1); right.columnconfigure(0, weight=1)

        self.figure_preview_label = ttk.Label(right, text='', anchor='center')
        self.figure_preview_label.grid(row=0, column=0, sticky='nsew')

    def on_target_x_selected(self, _e=None): self._fill_sens(self.target_tree_x, self.selected_target_var, self.sens_range_from_var, self.sens_range_to_var, 20)
    def on_target_y_selected(self, _e=None): self._fill_sens(self.target_tree_y, self.sens_y_target_var, self.sens_y_from_var, self.sens_y_to_var, 20)
    
    def on_3d_x_sel(self, _e=None): self._fill_sens(self.tree3_x, self.sens3_x_target, self.sens3_x_from, self.sens3_x_to, 5)
    def on_3d_y_sel(self, _e=None): self._fill_sens(self.tree3_y, self.sens3_y_target, self.sens3_y_from, self.sens3_y_to, 5)
    def on_3d_z_sel(self, _e=None): self._fill_sens(self.tree3_z, self.sens3_z_target, self.sens3_z_from, self.sens3_z_to, 5)

    def _fill_sens(self, tree, target_var, from_var, to_var, default_steps):
        sel = tree.selection()
        if not sel: return
        name = tree.item(sel[0], 'values')[0]
        target_var.set(f"Selected: {name}")
        val = float(self.scalar_vars[name].get())
        from_var.set(str(val))
        to_var.set(str(val * 1.5 if val != 0 else 1.0))

    def load_defaults(self):
        base_p = Parameters()
        base_s = ModelSwitches()
        for name in SCALAR_PARAM_NAMES: self.scalar_vars[name].set(str(getattr(base_p, name)))
        for name in SWITCH_NAMES: self.switch_vars[name].set(getattr(base_s, name))
        ic_defaults = "[\n  [0.2, 0.7, 0.1],\n  [0.5, 0.2, 0.2],\n  [0.5, 0.5, 0.2],\n  [0.2, 0.2, 0.6],\n  [0.0, 0.5, 0.2]\n]"
        self.text_widgets['initial_conditions'].delete('1.0', 'end')
        self.text_widgets['initial_conditions'].insert('1.0', ic_defaults)
        self.status_var.set('Defaults loaded.')

    def log(self, msg: str): self.log_queue.put(str(msg) + '\n')

    def _flush_log_queue(self):
        box = self.text_widgets['log']
        changed = False
        while True:
            try: box.insert('end', self.log_queue.get_nowait()); changed = True
            except queue.Empty: break
        if changed: box.see('end'); self.update_idletasks()
        self.after(100, self._flush_log_queue)

    def _get_params_from_ui(self) -> Parameters: return Parameters(**{n: float(self.scalar_vars[n].get()) for n in SCALAR_PARAM_NAMES})
    def _get_switches_from_ui(self) -> ModelSwitches: return ModelSwitches(**{n: self.switch_vars[n].get() for n in SWITCH_NAMES})

    def _monkey_patch_matplotlib(self, output_dir: Path):
        def hybrid_save_and_show(*args, **kwargs):
            fig = plt.gcf()
            
            # Save the high-res static image immediately
            filename = output_dir / f"plot_{int(time.time()*1000)}.png"
            fig.savefig(filename, bbox_inches='tight', dpi=300)
            self.log(f"Saved default angle to {filename.name}")
            
            # THE EVENT BLOCKER: Stops multiple plots from overwriting each other
            wait_for_close = threading.Event()

            def show_interactive_tkinter():
                viewer = tk.Toplevel(self)
                viewer.title(f"Interactive Viewer - {filename.name}")
                viewer.geometry("1100x850")
                
                # Embed the 3D Matplotlib figure
                canvas = FigureCanvasTkAgg(fig, master=viewer)
                canvas.draw()
                for ax in fig.axes:
                    if ax.get_legend() is not None:
                        ax.get_legend().set_draggable(True)
                # Add the interactive toolbar
                toolbar = NavigationToolbar2Tk(canvas, viewer)
                toolbar.update()
                
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
                
                def on_close():
                    plt.close(fig) 
                    viewer.destroy()
                    self.refresh_figures(output_dir)
                    wait_for_close.set() # Unblocks the background thread
                    
                viewer.protocol("WM_DELETE_WINDOW", on_close)

            # Safely trigger the new window on the Tkinter main thread
            self.after(0, show_interactive_tkinter)
            
            # Stop the background thread from firing off the next figure
            wait_for_close.wait() 

        plt.show = hybrid_save_and_show

    def start_standard_run(self): threading.Thread(target=self._run_standard, daemon=True).start()
    def start_sensitivity_run(self): threading.Thread(target=self._run_sensitivity, daemon=True).start()
    def start_3d_run(self): threading.Thread(target=self._run_3d_sensitivity, daemon=True).start()
    def start_basin_run(self): threading.Thread(target=self._run_basin_of_attraction, daemon=True).start()
    def start_time_series_run(self): threading.Thread(target=self._run_time_series_sim, daemon=True).start()
    def start_3d_plate_run(self): threading.Thread(target=self._run_3d_plate_sensitivity, daemon=True).start()

    def _run_basin_of_attraction(self):
        try:
            scenario_name = self.scenario_name_var.get().replace(" ", "_")
            self.after(0, lambda: self.status_var.set("Running Basins of Attraction..."))
            with redirect_stdout(QueueWriter(self)), redirect_stderr(QueueWriter(self, is_error=True)):
                params, switches = self._get_params_from_ui(), self._get_switches_from_ui()
                z0 = float(self.basin_z0_var.get())
                res = int(self.basin_res_var.get())
                w_range = (float(self.basin_w_min_var.get()), float(self.basin_w_max_var.get()))
                y_range = (float(self.basin_y_min_var.get()), float(self.basin_y_max_var.get()))
                
                t_span = (0.0, float(self.t_span_var.get()))
                t_eval = np.linspace(t_span[0], t_span[1], 500)

                out_dir = Path("transit_outputs") / f"{scenario_name}_Basin"
                out_dir.mkdir(parents=True, exist_ok=True)
                self._monkey_patch_matplotlib(out_dir)

                self.log(f"Running Basin Analysis (z0={z0}, Res={res}x{res}, w={w_range}, y={y_range})...")

                basin_res = classify_basin_of_attraction(params, w_range, y_range, z0, res, t_span, t_eval, switches)

                x_lbl = r"Initial Share of Electric ($w_0$)"
                y_lbl = r"Initial Share of Policy ($y_0$)"
                plot_basin_of_attraction(basin_res, x_lbl, y_lbl)

            def update_ui():
                self.current_output_dir = out_dir
                self.refresh_figures(out_dir)
                self.notebook.select(self.figures_tab)
                self.status_var.set("Basin Analysis Complete.")
            self.after(0, update_ui)
        except Exception as e: 
            error_text = f"ERROR: {e}\n{traceback.format_exc()}"
            self.after(0, lambda msg=error_text: self.log(msg))

    def _build_basin_tab(self):
        f = ttk.LabelFrame(self.basin_tab, text='Basins of Attraction (Initial Conditions Phase Portrait)', padding=10)
        f.pack(fill='both', expand=True, padx=10, pady=10)

        desc = ("This analysis holds all parameters constant (using the exact values from the 'Scalar Parameters' tab)\n"
                "and systematically varies the starting market shares (w0, y0) on a grid to see which equilibrium is reached.\n"
                "Adjust the Min/Max ranges below to 'zoom in' on specific clustered regions.")
        ttk.Label(f, text=desc).grid(row=0, column=0, columnspan=4, sticky='w', pady=(0,15))

        # Row 1: Fixed Z and Resolution
        ttk.Label(f, text='Fixed Initial z (Hydrogen):').grid(row=1, column=0, sticky='w', pady=4)
        ttk.Entry(f, textvariable=self.basin_z0_var, width=10).grid(row=1, column=1, sticky='w', pady=4, padx=(0, 20))

        ttk.Label(f, text='Grid Resolution (N x N):').grid(row=1, column=2, sticky='w', pady=4)
        ttk.Entry(f, textvariable=self.basin_res_var, width=10).grid(row=1, column=3, sticky='w', pady=4)

        # Row 2: Zoom Bounds
        bounds_frame = ttk.LabelFrame(f, text='Axis Zoom Bounds', padding=8)
        bounds_frame.grid(row=2, column=0, columnspan=4, sticky='ew', pady=15)
        
        ttk.Label(bounds_frame, text='X-Axis (w0) Min:').grid(row=0, column=0, sticky='w', padx=5, pady=2)
        ttk.Entry(bounds_frame, textvariable=self.basin_w_min_var, width=8).grid(row=0, column=1, sticky='w', padx=5, pady=2)
        ttk.Label(bounds_frame, text='Max:').grid(row=0, column=2, sticky='w', padx=5, pady=2)
        ttk.Entry(bounds_frame, textvariable=self.basin_w_max_var, width=8).grid(row=0, column=3, sticky='w', padx=5, pady=2)

        ttk.Label(bounds_frame, text='Y-Axis (y0) Min:').grid(row=1, column=0, sticky='w', padx=5, pady=2)
        ttk.Entry(bounds_frame, textvariable=self.basin_y_min_var, width=8).grid(row=1, column=1, sticky='w', padx=5, pady=2)
        ttk.Label(bounds_frame, text='Max:').grid(row=1, column=2, sticky='w', padx=5, pady=2)
        ttk.Entry(bounds_frame, textvariable=self.basin_y_max_var, width=8).grid(row=1, column=3, sticky='w', padx=5, pady=2)

        ttk.Button(f, text='Run Basin Analysis', command=self.start_basin_run).grid(row=3, column=0, columnspan=4, pady=20, sticky='w')

    def _run_standard(self):
        try:
            scenario_name = self.scenario_name_var.get().replace(" ", "_")
            self.after(0, lambda: self.status_var.set(f'Running standard simulation...'))
            
            with redirect_stdout(QueueWriter(self)), redirect_stderr(QueueWriter(self, is_error=True)):
                params, switches = self._get_params_from_ui(), self._get_switches_from_ui()
                initial_conditions = ast.literal_eval(self.text_widgets['initial_conditions'].get('1.0', 'end').strip())
                t_span = (0.0, float(self.t_span_var.get()))
                t_eval = np.linspace(t_span[0], t_span[1], 500)
                
                out_dir = Path("transit_outputs") / scenario_name
                out_dir.mkdir(parents=True, exist_ok=True)
                self._monkey_patch_matplotlib(out_dir)

                self.log("Solving multiple initial conditions...")
                results = solve_multiple_initial_conditions(params, initial_conditions, t_span=t_span, t_eval=t_eval, switches=switches)

                plt.rcParams['font.family'] = 'serif'

                # --- 1) Original 3D Phase Portrait (w, y, z) ---
                fig_3d = plt.figure(figsize=(10, 8))
                ax = fig_3d.add_subplot(111, projection='3d')
                for name, sol in results.items():
                    ax.plot(sol.y[0], sol.y[1], sol.y[2], linewidth=2.0, marker='^', markersize=6, markevery=50, label=name)
                
                ax.set_title("3D Phase Portrait ($w$, $y$, $z$)", fontsize=16, fontweight="bold")
                ax.set_xlabel("Electric ($w$)", fontsize=12, fontweight="bold")
                ax.set_ylabel("Policy ($y$)", fontsize=12, fontweight="bold")
                ax.set_zlabel("Hydrogen ($z$)", fontsize=12, fontweight="bold")
                ax.set_xlim(0.0, 1.0); ax.set_ylim(0.0, 1.0); ax.set_zlim(0.0, 1.0)
                leg1 = ax.legend(prop={'size': 16, 'weight': 'bold'}, loc='upper left', bbox_to_anchor=(1.05, 1), frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
                leg1.set_draggable(True)
                plt.show()

                # --- 2) 3D Plot with Time: (t, w, y) ---
                fig_twy = plt.figure(figsize=(10, 8))
                ax_twy = fig_twy.add_subplot(111, projection='3d')
                for name, sol in results.items():
                    ax_twy.plot(sol.t, sol.y[0], sol.y[1], linewidth=2.0, label=name)
                
                ax_twy.set_title("3D Time Evolution ($t$, $w$, $y$)", fontsize=16, fontweight="bold")
                ax_twy.set_xlabel("Time ($t$)", fontsize=12, fontweight="bold")
                ax_twy.set_ylabel("Electric ($w$)", fontsize=12, fontweight="bold")
                ax_twy.set_zlabel("Policy ($y$)", fontsize=12, fontweight="bold")
                ax_twy.set_xlim(t_span[0], t_span[1]); ax_twy.set_ylim(0.0, 1.0); ax_twy.set_zlim(0.0, 1.0)
                leg2 = ax_twy.legend(prop={'size': 16, 'weight': 'bold'}, loc='upper left', bbox_to_anchor=(1.05, 1), frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
                leg2.set_draggable(True)
                plt.show()

                # --- 3) 3D Plot with Time: (t, y, z) ---
                fig_tyz = plt.figure(figsize=(10, 8))
                ax_tyz = fig_tyz.add_subplot(111, projection='3d')
                for name, sol in results.items():
                    ax_tyz.plot(sol.t, sol.y[1], sol.y[2], linewidth=2.0, label=name)
                
                ax_tyz.set_title("3D Time Evolution ($t$, $y$, $z$)", fontsize=16, fontweight="bold")
                ax_tyz.set_xlabel("Time ($t$)", fontsize=12, fontweight="bold")
                ax_tyz.set_ylabel("Policy ($y$)", fontsize=12, fontweight="bold")
                ax_tyz.set_zlabel("Hydrogen ($z$)", fontsize=12, fontweight="bold")
                ax_tyz.set_xlim(t_span[0], t_span[1]); ax_tyz.set_ylim(0.0, 1.0); ax_tyz.set_zlim(0.0, 1.0)
                leg3 = ax_tyz.legend(prop={'size': 16, 'weight': 'bold'}, loc='upper left', bbox_to_anchor=(1.05, 1), frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
                leg3.set_draggable(True)
                plt.show()

                # --- 4) 3D Plot with Time: (t, w, z) ---
                fig_twz = plt.figure(figsize=(10, 8))
                ax_twz = fig_twz.add_subplot(111, projection='3d')
                for name, sol in results.items():
                    ax_twz.plot(sol.t, sol.y[0], sol.y[2], linewidth=2.0, label=name)
                
                ax_twz.set_title("3D Time Evolution ($t$, $w$, $z$)", fontsize=16, fontweight="bold")
                ax_twz.set_xlabel("Time ($t$)", fontsize=12, fontweight="bold")
                ax_twz.set_ylabel("Electric ($w$)", fontsize=12, fontweight="bold")
                ax_twz.set_zlabel("Hydrogen ($z$)", fontsize=12, fontweight="bold")
                ax_twz.set_xlim(t_span[0], t_span[1]); ax_twz.set_ylim(0.0, 1.0); ax_twz.set_zlim(0.0, 1.0)
                leg4 = ax_twz.legend(prop={'size': 16, 'weight': 'bold'}, loc='upper left', bbox_to_anchor=(1.05, 1), frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
                leg4.set_draggable(True)
                plt.show()

                # --- 5) 2D Time Series Plot ---
                fig_ts, axes = plt.subplots(3, 1, figsize=(11, 12), sharex=True)
                for name, sol in results.items():
                    axes[0].plot(sol.t, sol.y[1], linewidth=2.0, label=name)  # y(t)
                    axes[1].plot(sol.t, sol.y[0], linewidth=2.0, label=name)  # w(t)
                    axes[2].plot(sol.t, sol.y[2], linewidth=2.0, label=name)  # z(t)

                axes[0].set_ylabel("Policy share ($y$)", fontsize=13, fontweight="bold")
                axes[1].set_ylabel("Electric share ($w$)", fontsize=13, fontweight="bold")
                axes[2].set_ylabel("Hydrogen share ($z$)", fontsize=13, fontweight="bold")
                axes[2].set_xlabel("Time ($t$)", fontsize=13, fontweight="bold")
                axes[0].set_title("2D Time Evolution of Strategic Variables", fontsize=16, fontweight="bold")

                for current_ax in axes:
                    current_ax.set_xlim(t_eval[0], t_eval[-1])
                    current_ax.set_ylim(-0.05, 1.05)
                    current_ax.grid(True, linestyle="--", alpha=0.35)
                    current_ax.tick_params(axis='both', labelsize=11)

                handles, labels = axes[0].get_legend_handles_labels()
                leg5 = fig_ts.legend(handles, labels, loc="center left", bbox_to_anchor=(0.88, 0.5), title="Initial-condition runs", frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
                leg5.set_draggable(True)
                fig_ts.tight_layout(rect=[0, 0, 0.84, 1])
                plt.show()

            def update_ui():
                self.current_output_dir = out_dir
                self.refresh_figures(out_dir)
                self.notebook.select(self.figures_tab)
                self.status_var.set('Standard Run Complete.')
            self.after(0, update_ui)
        except Exception as e: 
            error_text = f"ERROR: {e}\n{traceback.format_exc()}"
            self.after(0, lambda msg=error_text: self.log(msg))

    def _run_time_series_sim(self):
        try:
            scenario_name = self.scenario_name_var.get().replace(" ", "_")
            self.after(0, lambda: self.status_var.set("Running time-series simulation..."))
            with redirect_stdout(QueueWriter(self)), redirect_stderr(QueueWriter(self, is_error=True)):
                params, switches = self._get_params_from_ui(), self._get_switches_from_ui()
                initial_conditions = ast.literal_eval(self.text_widgets['initial_conditions'].get('1.0', 'end').strip())

                t_span = (0.0, float(self.t_span_var.get()))
                t_eval = np.linspace(t_span[0], t_span[1], 500)

                out_dir = Path("transit_outputs") / f"{scenario_name}_TimeSeries"
                out_dir.mkdir(parents=True, exist_ok=True)
                self._monkey_patch_matplotlib(out_dir)

                self.log("Solving multiple initial conditions for time-series plots...")
                results = solve_multiple_initial_conditions(
                    params,
                    initial_conditions,
                    t_span=t_span,
                    t_eval=t_eval,
                    switches=switches
                )

                plt.rcParams['font.family'] = 'serif'

                fig_ts, axes = plt.subplots(3, 1, figsize=(11, 12), sharex=True)

                for name, sol in results.items():
                    axes[0].plot(sol.t, sol.y[1], linewidth=2.0, label=name)  # y(t)
                    axes[1].plot(sol.t, sol.y[0], linewidth=2.0, label=name)  # w(t)
                    axes[2].plot(sol.t, sol.y[2], linewidth=2.0, label=name)  # z(t)

                axes[0].set_ylabel("Policy share ($y$)", fontsize=13, fontweight="bold")
                axes[1].set_ylabel("Electric share ($w$)", fontsize=13, fontweight="bold")
                axes[2].set_ylabel("Hydrogen share ($z$)", fontsize=13, fontweight="bold")
                axes[2].set_xlabel("Time ($t$)", fontsize=13, fontweight="bold")

                axes[0].set_title("Time Evolution of Strategic Variables", fontsize=16, fontweight="bold")

                for ax in axes:
                    ax.set_xlim(t_eval[0], t_eval[-1])
                    ax.set_ylim(-0.05, 1.05)
                    ax.grid(True, linestyle="--", alpha=0.35)
                    ax.tick_params(axis='both', labelsize=11)

                handles, labels = axes[0].get_legend_handles_labels()
                leg = fig_ts.legend(
                    handles,
                    labels,
                    loc="center left",
                    bbox_to_anchor=(0.88, 0.5),
                    title="Initial-condition runs",
                    frameon=True, facecolor='white', framealpha=0.95, edgecolor='black'
                )
                leg.set_draggable(True)
                fig_ts.tight_layout(rect=[0, 0, 0.84, 1])
                plt.show()

            def update_ui():
                self.current_output_dir = out_dir
                self.refresh_figures(out_dir)
                self.notebook.select(self.figures_tab)
                self.status_var.set("Time-series simulation complete.")
            self.after(0, update_ui)
        except Exception as e:
            error_text = f"ERROR: {e}\n{traceback.format_exc()}"
            self.after(0, lambda msg=error_text: self.log(msg))

    def _run_sensitivity(self):
        try:
            scenario_name = self.scenario_name_var.get().replace(" ", "_")
            self.after(0, lambda: self.status_var.set("Running 2D Analysis..."))
            with redirect_stdout(QueueWriter(self)), redirect_stderr(QueueWriter(self, is_error=True)):
                params, switches = self._get_params_from_ui(), self._get_switches_from_ui()
                
                x_p = self.target_tree_x.item(self.target_tree_x.selection()[0], "values")[0]
                y_p = self.target_tree_y.item(self.target_tree_y.selection()[0], "values")[0]
                x_vals = np.linspace(float(self.sens_range_from_var.get()), float(self.sens_range_to_var.get()), int(self.sens_step_var.get()))
                y_vals = np.linspace(float(self.sens_y_from_var.get()), float(self.sens_y_to_var.get()), int(self.sens_y_step_var.get()))

                ic = ast.literal_eval(self.text_widgets["initial_conditions"].get("1.0", "end").strip())
                t_span = (0.0, float(self.t_span_var.get())); t_eval = np.linspace(t_span[0], t_span[1], 500)

                out_dir = Path("transit_outputs") / f"{scenario_name}_2D_{x_p}_{y_p}"
                out_dir.mkdir(parents=True, exist_ok=True); self._monkey_patch_matplotlib(out_dir)

                self.log(f"Running 2D Robust Regional Map...")
                robust = classify_with_multiple_initial_conditions(params, x_p, x_vals, y_p, y_vals, ic, t_span, t_eval, switches)
                
                print_ess_combinations_report(params, x_p, x_vals, y_p, y_vals, ic, t_span, t_eval, switches)
                
                x_lbl = PARAM_DEFS[x_p][1] + f" (${PARAM_DEFS[x_p][0]}$)"
                y_lbl = PARAM_DEFS[y_p][1] + f" (${PARAM_DEFS[y_p][0]}$)"
                plot_clean_regional_map(robust, f"Exact Simulated Grid: {x_p} vs {y_p}", x_lbl, y_lbl, style="sharp")
                plot_clean_regional_map(robust, f"Smoothed Regional Map: {x_p} vs {y_p}", x_lbl, y_lbl, style="smooth")

            def update_ui():
                self.current_output_dir = out_dir
                self.refresh_figures(out_dir)
                self.notebook.select(self.figures_tab)
                self.status_var.set("2D Analysis Complete.")
            self.after(0, update_ui)
        except Exception as e: 
            error_text = f"ERROR: {e}\n{traceback.format_exc()}"
            self.after(0, lambda msg=error_text: self.log(msg))

    def _run_3d_sensitivity(self):
        try:
            scenario_name = self.scenario_name_var.get().replace(" ", "_")
            self.after(0, lambda: self.status_var.set("Running 3D Analysis..."))
            with redirect_stdout(QueueWriter(self)), redirect_stderr(QueueWriter(self, is_error=True)):
                params, switches = self._get_params_from_ui(), self._get_switches_from_ui()
                
                x_p = self.tree3_x.item(self.tree3_x.selection()[0], "values")[0]
                y_p = self.tree3_y.item(self.tree3_y.selection()[0], "values")[0]
                z_p = self.tree3_z.item(self.tree3_z.selection()[0], "values")[0]
                
                x_vals = np.linspace(float(self.sens3_x_from.get()), float(self.sens3_x_to.get()), int(self.sens3_x_step.get()))
                y_vals = np.linspace(float(self.sens3_y_from.get()), float(self.sens3_y_to.get()), int(self.sens3_y_step.get()))
                z_vals = np.linspace(float(self.sens3_z_from.get()), float(self.sens3_z_to.get()), int(self.sens3_z_step.get()))

                ic = ast.literal_eval(self.text_widgets["initial_conditions"].get("1.0", "end").strip())
                t_span = (0.0, float(self.t_span_var.get())); t_eval = np.linspace(t_span[0], t_span[1], 500)

                out_dir = Path("transit_outputs") / f"{scenario_name}_3D_{x_p}_{y_p}_{z_p}"
                out_dir.mkdir(parents=True, exist_ok=True); self._monkey_patch_matplotlib(out_dir)

                self.log(f"Running 3D Robust Regional Map (N = {len(x_vals)*len(y_vals)*len(z_vals)} points)...")
                
                res_3d = classify_3d_sensitivity(params, x_p, x_vals, y_p, y_vals, z_p, z_vals, ic, t_span, t_eval, switches)
                
                x_lbl = PARAM_DEFS[x_p][1] + f" (${PARAM_DEFS[x_p][0]}$)"
                y_lbl = PARAM_DEFS[y_p][1] + f" (${PARAM_DEFS[y_p][0]}$)"
                z_lbl = PARAM_DEFS[z_p][1] + f" (${PARAM_DEFS[z_p][0]}$)"
                
                plot_3d_regional_map(res_3d, f"3D Regional Map: {x_p}, {y_p}, {z_p}", x_lbl, y_lbl, z_lbl)

            def update_ui():
                self.current_output_dir = out_dir
                self.refresh_figures(out_dir)
                self.notebook.select(self.figures_tab)
                self.status_var.set("3D Analysis Complete.")
            self.after(0, update_ui)
        except Exception as e: 
            error_text = f"ERROR: {e}\n{traceback.format_exc()}"
            self.after(0, lambda msg=error_text: self.log(msg))


    def _run_3d_plate_sensitivity(self):
        try:
            scenario_name = self.scenario_name_var.get().replace(" ", "_")
            self.after(0, lambda: self.status_var.set("Running 3D plate-map analysis..."))
            with redirect_stdout(QueueWriter(self)), redirect_stderr(QueueWriter(self, is_error=True)):
                params, switches = self._get_params_from_ui(), self._get_switches_from_ui()

                x_p = self.tree3_x.item(self.tree3_x.selection()[0], "values")[0]
                y_p = self.tree3_y.item(self.tree3_y.selection()[0], "values")[0]
                z_p = self.tree3_z.item(self.tree3_z.selection()[0], "values")[0]

                x_vals = np.linspace(float(self.sens3_x_from.get()), float(self.sens3_x_to.get()), int(self.sens3_x_step.get()))
                y_vals = np.linspace(float(self.sens3_y_from.get()), float(self.sens3_y_to.get()), int(self.sens3_y_step.get()))
                z_vals = np.linspace(float(self.sens3_z_from.get()), float(self.sens3_z_to.get()), int(self.sens3_z_step.get()))

                ic = ast.literal_eval(self.text_widgets["initial_conditions"].get("1.0", "end").strip())
                t_span = (0.0, float(self.t_span_var.get()))
                t_eval = np.linspace(t_span[0], t_span[1], 500)

                out_dir = Path("transit_outputs") / f"{scenario_name}_3DPlate_{x_p}_{y_p}_{z_p}"
                out_dir.mkdir(parents=True, exist_ok=True)
                self._monkey_patch_matplotlib(out_dir)

                self.log(f"Running 3D Plate Map (N = {len(x_vals)*len(y_vals)*len(z_vals)} points)...")

                res_3d = classify_3d_sensitivity(
                    params, x_p, x_vals, y_p, y_vals, z_p, z_vals, ic, t_span, t_eval, switches
                )

                x_lbl = PARAM_DEFS[x_p][1] + f" (${PARAM_DEFS[x_p][0]}$)"
                y_lbl = PARAM_DEFS[y_p][1] + f" (${PARAM_DEFS[y_p][0]}$)"
                z_lbl = PARAM_DEFS[z_p][1] + f" (${PARAM_DEFS[z_p][0]}$)"

                plot_3d_voxel_region_map(
                    res_3d,
                    f"3D Plate Map: {x_p}, {y_p}, {z_p}",
                    x_lbl, y_lbl, z_lbl
                )

            def update_ui():
                self.current_output_dir = out_dir
                self.refresh_figures(out_dir)
                self.notebook.select(self.figures_tab)
                self.status_var.set("3D plate-map analysis complete.")
            self.after(0, update_ui)
        except Exception as e:
            error_text = f"ERROR: {e}\n{traceback.format_exc()}"
            self.after(0, lambda msg=error_text: self.log(msg))
            
    def refresh_figures(self, output_dir: Optional[Path] = None):
        folder = output_dir or self.current_output_dir
        if folder is None or not Path(folder).exists(): return
        paths = sorted([p for p in Path(folder).rglob('*') if p.suffix.lower() in IMAGE_EXTS])
        self.figure_paths = paths; self.figure_cache.clear(); self.figure_list.delete(0, 'end')
        for p in paths: self.figure_list.insert('end', str(p.relative_to(folder)))
        if paths: self.figure_list.selection_set(0); self.show_selected_figure()

    def show_selected_figure(self, _event=None):
        sel = self.figure_list.curselection()
        if not sel: return
        img = self._load_photo(self.figure_paths[sel[0]], 520)
        self.figure_preview_label.configure(image=img); self.figure_preview_label.image = img

    def open_zoom_window(self, _event=None):
        if self.figure_list.curselection(): ZoomableImageWindow(self, self.figure_paths[self.figure_list.curselection()[0]])

    def _load_photo(self, path: Path, max_dim: int) -> tk.PhotoImage:
        img = tk.PhotoImage(file=str(path))
        scale = max(img.width() / max_dim, img.height() / max_dim, 1)
        if scale > 1: img = img.subsample(int(scale), int(scale))
        return img

if __name__ == '__main__':
    app = TransitGUI()
    app.mainloop()