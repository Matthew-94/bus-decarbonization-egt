# =============================================================================
# PHASE 4B-3
# TRAJECTORY-MECHANISM DIAGNOSTICS
# =============================================================================

import numpy as np

from transit_model_phase4B import (
    make_scenario,
    derived_quantities,
    expected_operator_payoffs,
    policy_thresholds,
    solve_replicator,
)


# =============================================================================
# COMMON INITIAL CONDITION
# State order = [z, w, y]
# =============================================================================

INITIAL_STATE = (0.05, 0.15, 0.20)

TAU_SPAN = (0.0, 300.0)
N_POINTS = 6001


# =============================================================================
# HELPER: first crossing of a threshold
# =============================================================================

def first_crossing_time(tau, values, threshold, direction="up"):

    values = np.asarray(values)
    tau = np.asarray(tau)

    if direction == "up":
        idx = np.where(values >= threshold)[0]
    elif direction == "down":
        idx = np.where(values <= threshold)[0]
    else:
        raise ValueError("direction must be 'up' or 'down'")

    if len(idx) == 0:
        return np.nan

    return float(tau[idx[0]])


# =============================================================================
# HELPER: linear interpolation of threshold crossing
# =============================================================================

def interpolated_crossing(tau, values, threshold):

    tau = np.asarray(tau)
    values = np.asarray(values)

    shifted = values - threshold

    crossing_idx = np.where(
        shifted[:-1] * shifted[1:] <= 0.0
    )[0]

    if len(crossing_idx) == 0:
        return np.nan

    i = crossing_idx[0]

    x0 = tau[i]
    x1 = tau[i + 1]

    y0 = values[i]
    y1 = values[i + 1]

    if abs(y1 - y0) < 1e-14:
        return float(x0)

    frac = (threshold - y0) / (y1 - y0)

    return float(
        x0 + frac * (x1 - x0)
    )


# =============================================================================
# MAIN
# =============================================================================

print("=" * 92)
print("PHASE 4B-3 — TRAJECTORY MECHANISM DIAGNOSTICS")
print("=" * 92)

print(
    "\nCommon initial state:"
    f" z0={INITIAL_STATE[0]:.3f},"
    f" w0={INITIAL_STATE[1]:.3f},"
    f" D0={1-INITIAL_STATE[0]-INITIAL_STATE[1]:.3f},"
    f" y0={INITIAL_STATE[2]:.3f}"
)

for scenario_name in ["S1", "S2", "S3"]:

    p = make_scenario(scenario_name)

    d = derived_quantities(p)
    thresholds = policy_thresholds(p)

    sol = solve_replicator(
        p=p,
        initial_state=INITIAL_STATE,
        tau_span=TAU_SPAN,
        n_points=N_POINTS,
    )

    tau = sol.t

    z = sol.y[0]
    w = sol.y[1]
    y = sol.y[2]

    D = 1.0 - z - w

    # -------------------------------------------------------------------------
    # Expected H and E payoff trajectories
    # -------------------------------------------------------------------------

    Pi_H = np.zeros_like(tau)
    Pi_E = np.zeros_like(tau)
    Pi_D = np.zeros_like(tau)

    for i, yi in enumerate(y):

        op = expected_operator_payoffs(
            y=float(yi),
            p=p,
        )

        Pi_H[i] = op["Pi_H"]
        Pi_E[i] = op["Pi_E"]
        Pi_D[i] = op["Pi_D"]

    HE_gap = Pi_H - Pi_E

    # -------------------------------------------------------------------------
    # Threshold diagnostics
    # -------------------------------------------------------------------------

    y_HE_star = thresholds["y_HE"]

    feasible_HE_threshold = (
        0.0 <= y_HE_star <= 1.0
    )

    if feasible_HE_threshold:

        tau_y_HE = interpolated_crossing(
            tau,
            y,
            y_HE_star,
        )

        tau_payoff_HE = interpolated_crossing(
            tau,
            HE_gap,
            0.0,
        )

        if np.isfinite(tau_y_HE):

            j = int(
                np.argmin(
                    np.abs(tau - tau_y_HE)
                )
            )

            z_at_switch = z[j]
            w_at_switch = w[j]
            D_at_switch = D[j]

        else:

            z_at_switch = np.nan
            w_at_switch = np.nan
            D_at_switch = np.nan

    else:

        tau_y_HE = np.nan
        tau_payoff_HE = np.nan

        z_at_switch = np.nan
        w_at_switch = np.nan
        D_at_switch = np.nan

    # -------------------------------------------------------------------------
    # Dominance / convergence diagnostics
    # -------------------------------------------------------------------------

    tau_y_90 = first_crossing_time(
        tau,
        y,
        0.90,
        direction="up",
    )

    tau_y_99 = first_crossing_time(
        tau,
        y,
        0.99,
        direction="up",
    )

    tau_E_90 = first_crossing_time(
        tau,
        w,
        0.90,
        direction="up",
    )

    tau_H_90 = first_crossing_time(
        tau,
        z,
        0.90,
        direction="up",
    )

    tau_D_10 = first_crossing_time(
        tau,
        D,
        0.10,
        direction="down",
    )

    # -------------------------------------------------------------------------
    # Transient extrema
    # -------------------------------------------------------------------------

    idx_w_max = int(np.argmax(w))
    idx_z_max = int(np.argmax(z))

    w_max = float(w[idx_w_max])
    tau_w_max = float(tau[idx_w_max])

    z_max = float(z[idx_z_max])
    tau_z_max = float(tau[idx_z_max])

    # -------------------------------------------------------------------------
    # Initial and final ranking
    # -------------------------------------------------------------------------

    initial_op = expected_operator_payoffs(
        y=INITIAL_STATE[2],
        p=p,
    )

    final_op = expected_operator_payoffs(
        y=float(y[-1]),
        p=p,
    )

    # -------------------------------------------------------------------------
    # Reporting
    # -------------------------------------------------------------------------

    print("\n" + scenario_name)
    print("-" * 66)

    print(
        "Baseline operator payoffs:"
        f" H={d['pi_H_B']:.4f},"
        f" E={d['pi_E_B']:.4f},"
        f" D={d['pi_D_B']:.4f}"
    )

    print(
        "Initial expected payoffs at y0:"
        f" H={initial_op['Pi_H']:.4f},"
        f" E={initial_op['Pi_E']:.4f},"
        f" D={initial_op['Pi_D']:.4f}"
    )

    print(
        "Final expected payoffs:"
        f" H={final_op['Pi_H']:.4f},"
        f" E={final_op['Pi_E']:.4f},"
        f" D={final_op['Pi_D']:.4f}"
    )

    print(
        "\nFinal state:"
        f" z_H={z[-1]:.6f},"
        f" w_E={w[-1]:.6f},"
        f" D={D[-1]:.6f},"
        f" y={y[-1]:.6f}"
    )

    print("\nPolicy commitment milestones:")
    print(f"  tau(y >= 0.90) = {tau_y_90:.4f}")
    print(f"  tau(y >= 0.99) = {tau_y_99:.4f}")

    print("\nTechnology milestones:")
    print(f"  tau(D <= 0.10) = {tau_D_10:.4f}")
    print(f"  tau(w >= 0.90) = {tau_E_90:.4f}")
    print(f"  tau(z >= 0.90) = {tau_H_90:.4f}")

    print("\nTransient extrema:")
    print(
        f"  max electric share = {w_max:.6f}"
        f" at tau={tau_w_max:.4f}"
    )
    print(
        f"  max hydrogen share = {z_max:.6f}"
        f" at tau={tau_z_max:.4f}"
    )

    print("\nH-E policy frontier:")

    print(
        f"  y_HE* = {y_HE_star:.6f}"
    )

    print(
        f"  feasible threshold? "
        f"{feasible_HE_threshold}"
    )

    if feasible_HE_threshold:

        print(
            f"  tau when y crosses y_HE* "
            f"= {tau_y_HE:.6f}"
        )

        print(
            f"  tau when Pi_H-Pi_E crosses zero "
            f"= {tau_payoff_HE:.6f}"
        )

        print(
            "  state near H-E ranking reversal:"
        )

        print(
            f"    z_H = {z_at_switch:.6f}"
        )

        print(
            f"    w_E = {w_at_switch:.6f}"
        )

        print(
            f"    D   = {D_at_switch:.6f}"
        )

    else:

        print(
            "  H-E indifference threshold lies "
            "outside the feasible policy interval."
        )

print("\nDiagnostics completed.")