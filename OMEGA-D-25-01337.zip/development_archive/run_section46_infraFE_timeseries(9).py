"""Run Analysis 2: nonlinear infrastructure fixed-entry burden sensitivity."""
from run_section46_premium_analysis import (
    make_base_extension_parameters,
    plot_infra_FE_time_series_sensitivity,
    OUTPUT_DIR,
)

if __name__ == "__main__":
    plot_infra_FE_time_series_sensitivity(make_base_extension_parameters())
    print(f"Figures saved in: {OUTPUT_DIR.resolve()}")