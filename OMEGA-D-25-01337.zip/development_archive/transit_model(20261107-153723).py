from __future__ import annotations

from dataclasses import dataclass, replace, asdict
from typing import Dict, Iterable, List, Tuple, Optional, Any
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
import matplotlib.patches as mpatches

# ============================================================
# 1) PARAMETERS AND MODEL SWITCHES
# ============================================================

@dataclass
class ModelSwitches:
    use_h_subsidy: bool = True
    use_e_subsidy: bool = True
    use_d_tax: bool = True
    use_h_greenness_penalty: bool = True
    use_e_greenness_penalty: bool = True

@dataclass
class Parameters:
    f_H: float = 5.0
    f_E: float = 2.0
    f_D: float = 5.0
    distance_km: float = 50.0
    fare_t: float = 3.0
    theta: float = 0.5
    theta_prime: float = 0.3
    phi: float = 0.4
    phi_prime: float = 0.2
    vartheta: float = 0.1
    vartheta_prime: float = 0.1
    mu: float = 0.08
    mu_prime: float = 0.05
    delta: float = 0.1
    delta_prime: float = 0.7
    gamma: float = 0.1
    gamma_prime: float = 0.3
    S_H: float = 7.0
    S_E: float = 4.0
    tax_T: float = 6.0
    R_H: float = 0.2
    R_E: float = 2.5
    R_D: float = 1.2
    c_p: float = 0.2
    xi_H: float = 0.00012
    xi_E: float = 0.00039
    xi_D: float = 0.00173
    q_H: float = 300.0
    q_E: float = 300.0
    q_D: float = 300.0
    C_H: float = 4.5
    C_E: float = 2.5
    C_D: float = 1.5
    chi_H: float = 4.5
    chi_E: float = 2.5
    chi_D: float = 1.5
    CS: float = 400.0
    rho_H: float = 1.0
    rho_E: float = 1.0

    # Nonlinear infrastructure-entry extension parameters.
    # Defaults deactivate the extension, so all baseline analytical results remain unchanged.
    infra_F_H: float = 0.0       # Fixed entry burden for hydrogen infrastructure
    infra_F_E: float = 0.0       # Fixed entry burden for electric infrastructure
    infra_lambda_H: float = 4.0  # Rate at which the initial hydrogen burden declines with adoption
    infra_lambda_E: float = 4.0  # Rate at which the initial electric burden declines with adoption
    infra_eta_H: float = 0.0     # Marginal hydrogen infrastructure burden
    infra_eta_E: float = 0.0     # Marginal electric infrastructure burden
    infra_zeta_H: float = 0.0    # Expansion burden after hydrogen capacity is binding
    infra_zeta_E: float = 0.0    # Expansion burden after electric capacity is binding
    infra_cap_H: float = 0.70    # Initial hydrogen infrastructure capacity threshold in strategic-weight units
    infra_cap_E: float = 0.70    # Initial electric infrastructure capacity threshold in strategic-weight units
    infra_psi_H: float = 0.50    # PA share of hydrogen infrastructure burden under supportive policy
    infra_psi_E: float = 0.50    # PA share of electric infrastructure burden under supportive policy
 
# ============================================================
# 2) CORE MODEL BUILDING BLOCKS
# ============================================================

def _active_value(value: float, active: bool) -> float:
    return value if active else 0.0

def get_active_policy_values(p: Parameters, s: ModelSwitches) -> Dict[str, float]:
    return {
        "S_H": _active_value(p.S_H, s.use_h_subsidy),
        "S_E": _active_value(p.S_E, s.use_e_subsidy),
        "T": _active_value(p.tax_T, s.use_d_tax),
    }

def compute_payoffs(p: Parameters, s: Optional[ModelSwitches] = None) -> Dict[str, float]:
    if s is None: s = ModelSwitches()
    policy = get_active_policy_values(p, s)
    S_H, S_E, T = policy["S_H"], policy["S_E"], policy["T"]

    h_penalty = p.mu * p.theta**2 / 2.0 if s.use_h_greenness_penalty else 0.0
    h_penalty_prime = p.mu * p.theta_prime**2 / 2.0 if s.use_h_greenness_penalty else 0.0
    e_penalty = p.mu * p.phi**2 / 2.0 if s.use_e_greenness_penalty else 0.0
    e_penalty_prime = p.mu * p.phi_prime**2 / 2.0 if s.use_e_greenness_penalty else 0.0

    TD1 = p.q_H * (p.fare_t - p.rho_H * p.C_H + S_H) - p.rho_H * p.R_H - h_penalty
    TD2 = p.q_H * (p.fare_t - p.rho_H * p.chi_H) - p.rho_H * p.R_H - h_penalty_prime
    TD3 = p.q_E * (p.fare_t - p.rho_E * p.C_E + S_E) - p.rho_E * p.R_E - e_penalty
    TD4 = p.q_E * (p.fare_t - p.rho_E * p.chi_E) - p.rho_E * p.R_E - e_penalty_prime
    TD5 = p.q_D * (p.fare_t - p.C_D - T) - p.R_D
    TD6 = p.q_D * (p.fare_t - p.chi_D) - p.R_D

    G1 = p.CS - S_H * p.q_H - p.rho_H * p.xi_H * p.q_H - p.c_p * p.rho_H * p.f_H
    G2 = p.CS - p.rho_H * p.xi_H * p.q_H - p.c_p * p.rho_H * p.f_H
    G3 = p.CS - S_E * p.q_E - p.rho_E * p.xi_E * p.q_E - p.c_p * p.rho_E * p.f_E
    G4 = p.CS - p.rho_E * p.xi_E * p.q_E - p.c_p * p.rho_E * p.f_E
    G5 = p.CS + T * p.q_D - p.xi_D * p.q_D - p.c_p * p.f_D
    G6 = p.CS - p.xi_D * p.q_D - p.c_p * p.f_D

    return {"TD1": TD1, "TD2": TD2, "TD3": TD3, "TD4": TD4, "TD5": TD5, "TD6": TD6,
            "G1": G1, "G2": G2, "G3": G3, "G4": G4, "G5": G5, "G6": G6}

# ============================================================
# 3) REPLICATOR DYNAMICS
# ============================================================

def compute_reduced_coefficients(p: Parameters, s: Optional[ModelSwitches] = None) -> Dict[str, float]:
    if s is None: s = ModelSwitches()
    policy = get_active_policy_values(p, s)
    S_H, S_E, T = policy["S_H"], policy["S_E"], policy["T"]
    mu_for_terms = p.mu
    theta_term = p.theta if s.use_h_greenness_penalty else 0.0
    theta_prime_term = p.theta_prime if s.use_h_greenness_penalty else 0.0
    phi_term = p.phi if s.use_e_greenness_penalty else 0.0
    phi_prime_term = p.phi_prime if s.use_e_greenness_penalty else 0.0

    # Hydrogen coefficients. rho_H scales the service-equivalent operating and acquisition burden.
    coef_a = 0.5 * (
        theta_term**2 * mu_for_terms
        - 2.0 * T * p.q_D
        - 2.0 * p.C_D * p.q_D
        + 2.0 * p.rho_H * p.C_H * p.q_H
        - 2.0 * p.q_H * S_H
        + 2.0 * p.q_D * p.chi_D
        - 2.0 * p.rho_H * p.q_H * p.chi_H
        - mu_for_terms * theta_prime_term**2
    )
    coef_b = 0.5 * (
        2.0 * p.fare_t * p.q_D
        - 2.0 * p.fare_t * p.q_H
        - 2.0 * p.R_D
        + 2.0 * p.rho_H * p.R_H
        - 2.0 * p.q_D * p.chi_D
        + 2.0 * p.rho_H * p.q_H * p.chi_H
        + mu_for_terms * theta_prime_term**2
    )

    # Electric coefficients. rho_E captures extra EPB requirements due to range, charging downtime, or spare-ratio needs.
    coef_c = 0.5 * (
        mu_for_terms * phi_term**2
        - 2.0 * T * p.q_D
        - 2.0 * p.C_D * p.q_D
        + 2.0 * p.rho_E * p.C_E * p.q_E
        - 2.0 * p.q_E * S_E
        + 2.0 * p.q_D * p.chi_D
        - 2.0 * p.rho_E * p.q_E * p.chi_E
        - mu_for_terms * phi_prime_term**2
    )
    coef_d = 0.5 * (
        2.0 * p.fare_t * p.q_D
        - 2.0 * p.fare_t * p.q_E
        - 2.0 * p.R_D
        + 2.0 * p.rho_E * p.R_E
        - 2.0 * p.q_D * p.chi_D
        + 2.0 * p.rho_E * p.q_E * p.chi_E
        + mu_for_terms * phi_prime_term**2
    )
    coef_g = -T * p.q_D - p.q_E * S_E
    coef_k = -T * p.q_D - p.q_H * S_H

    return {"a": coef_a, "b": coef_b, "c": coef_c, "d": coef_d, "g": coef_g, "k": coef_k, "TqD": T * p.q_D}

def replicator_rhs_reduced(t: float, variables: np.ndarray, p: Parameters, s: Optional[ModelSwitches] = None) -> List[float]:
    w, y, z = variables
    cfs = compute_reduced_coefficients(p, s)
    dw_dt = (w - 1.0) * w * (cfs["d"] + cfs["c"] * y) + w * (cfs["b"] + cfs["a"] * y) * z
    dy_dt = -((y - 1.0) * y * (cfs["g"] * w + cfs["k"] * z + cfs["TqD"]))
    dz_dt = (cfs["d"] * w + cfs["c"] * w * y + cfs["b"] * (z - 1.0) + cfs["a"] * y * (z - 1.0)) * z
    return [dw_dt, dy_dt, dz_dt]

# ============================================================
# 4) SOLVERS & CLASSIFICATION
# ============================================================

def solve_replicator(p: Parameters, initial_state: Iterable[float], t_span: Tuple[float, float] = (0.0, 0.08), t_eval: Optional[np.ndarray] = None, switches: Optional[ModelSwitches] = None) -> solve_ivp:
    if switches is None: switches = ModelSwitches()
    if t_eval is None: t_eval = np.linspace(t_span[0], t_span[1], 500)
    return solve_ivp(fun=lambda t, x: replicator_rhs_reduced(t, x, p, switches), t_span=t_span, y0=np.array(list(initial_state), dtype=float), t_eval=t_eval, method="RK45", atol=1e-9, rtol=1e-7)
def solve_multiple_initial_conditions(p: Parameters, initial_conditions: List[Iterable[float]], t_span: Tuple[float, float] = (0.0, 0.08), t_eval: Optional[np.ndarray] = None, switches: Optional[ModelSwitches] = None) -> Dict[str, Any]:
    return {f"run_{i}": solve_replicator(p, ic, t_span, t_eval, switches) for i, ic in enumerate(initial_conditions, start=1)}


# ============================================================
# 4A) NONLINEAR INFRASTRUCTURE-ENTRY EXTENSION
# ============================================================

def infrastructure_entry_burden(
    strategic_weight: float,
    fixed_entry_burden: float,
    decay_rate: float,
    marginal_burden: float,
    expansion_burden: float,
    capacity_threshold: float
) -> float:
    """
    Reduced-form nonlinear infrastructure-entry burden.

    Omega_i(x) = F_i exp(-lambda_i x) + eta_i x
                 + zeta_i max(0, x - cap_i)^2

    The first term represents the high initial infrastructure burden when adoption is low,
    the second term represents regular marginal expansion, and the third term represents
    extra expansion pressure once initial capacity becomes binding.
    """
    x = float(np.clip(strategic_weight, 0.0, 1.0))
    cap = float(np.clip(capacity_threshold, 0.0, 1.0))
    fixed = fixed_entry_burden * np.exp(-max(decay_rate, 0.0) * x)
    marginal = marginal_burden * x
    expansion = expansion_burden * max(0.0, x - cap) ** 2
    return float(fixed + marginal + expansion)


def compute_infrastructure_burdens(
    w: float,
    z: float,
    p: Parameters
) -> Dict[str, float]:
    """
    Returns state-dependent infrastructure burdens for EPB and HPB pathways.

    Internal state order is (w, y, z):
      w = electric strategic weight
      z = hydrogen strategic weight
    """
    omega_e = infrastructure_entry_burden(
        strategic_weight=w,
        fixed_entry_burden=p.infra_F_E,
        decay_rate=p.infra_lambda_E,
        marginal_burden=p.infra_eta_E,
        expansion_burden=p.infra_zeta_E,
        capacity_threshold=p.infra_cap_E,
    )
    omega_h = infrastructure_entry_burden(
        strategic_weight=z,
        fixed_entry_burden=p.infra_F_H,
        decay_rate=p.infra_lambda_H,
        marginal_burden=p.infra_eta_H,
        expansion_burden=p.infra_zeta_H,
        capacity_threshold=p.infra_cap_H,
    )
    return {"Omega_E": omega_e, "Omega_H": omega_h}


def compute_payoffs_nonlinear_infrastructure(
    p: Parameters,
    variables: Iterable[float],
    s: Optional[ModelSwitches] = None
) -> Dict[str, float]:
    """
    State-dependent payoff structure for the nonlinear infrastructure-entry extension.

    This function should be used only for the extended numerical analysis. It does not
    replace the baseline analytical payoff system used for the closed-form ESS conditions.
    """
    if s is None:
        s = ModelSwitches()

    w, y, z = map(float, variables)  # y is included for consistent state passing
    policy = get_active_policy_values(p, s)
    S_H, S_E, T = policy["S_H"], policy["S_E"], policy["T"]
    burdens = compute_infrastructure_burdens(w=w, z=z, p=p)
    Omega_E, Omega_H = burdens["Omega_E"], burdens["Omega_H"]

    psi_H = float(np.clip(p.infra_psi_H, 0.0, 1.0))
    psi_E = float(np.clip(p.infra_psi_E, 0.0, 1.0))

    h_penalty = p.mu * p.theta**2 / 2.0 if s.use_h_greenness_penalty else 0.0
    h_penalty_prime = p.mu * p.theta_prime**2 / 2.0 if s.use_h_greenness_penalty else 0.0
    e_penalty = p.mu * p.phi**2 / 2.0 if s.use_e_greenness_penalty else 0.0
    e_penalty_prime = p.mu * p.phi_prime**2 / 2.0 if s.use_e_greenness_penalty else 0.0

    # TO payoffs. Under supportive policy, the PA absorbs psi_i of the infrastructure burden.
    # Under no policy, the operator bears the full infrastructure-entry burden.
    TD1 = p.q_H * (p.fare_t - p.rho_H * p.C_H + S_H) - p.rho_H * p.R_H - (1.0 - psi_H) * Omega_H - h_penalty
    TD2 = p.q_H * (p.fare_t - p.rho_H * p.chi_H) - p.rho_H * p.R_H - Omega_H - h_penalty_prime
    TD3 = p.q_E * (p.fare_t - p.rho_E * p.C_E + S_E) - p.rho_E * p.R_E - (1.0 - psi_E) * Omega_E - e_penalty
    TD4 = p.q_E * (p.fare_t - p.rho_E * p.chi_E) - p.rho_E * p.R_E - Omega_E - e_penalty_prime
    TD5 = p.q_D * (p.fare_t - p.C_D - T) - p.R_D
    TD6 = p.q_D * (p.fare_t - p.chi_D) - p.R_D

    # PA payoffs. Infrastructure support is not free: under supportive policy, the PA pays psi_i Omega_i.
    G1 = p.CS - S_H * p.q_H - p.rho_H * p.xi_H * p.q_H - p.c_p * p.rho_H * p.f_H - psi_H * Omega_H
    G2 = p.CS - p.rho_H * p.xi_H * p.q_H - p.c_p * p.rho_H * p.f_H
    G3 = p.CS - S_E * p.q_E - p.rho_E * p.xi_E * p.q_E - p.c_p * p.rho_E * p.f_E - psi_E * Omega_E
    G4 = p.CS - p.rho_E * p.xi_E * p.q_E - p.c_p * p.rho_E * p.f_E
    G5 = p.CS + T * p.q_D - p.xi_D * p.q_D - p.c_p * p.f_D
    G6 = p.CS - p.xi_D * p.q_D - p.c_p * p.f_D

    return {
        "TD1": TD1, "TD2": TD2, "TD3": TD3, "TD4": TD4, "TD5": TD5, "TD6": TD6,
        "G1": G1, "G2": G2, "G3": G3, "G4": G4, "G5": G5, "G6": G6,
        "Omega_E": Omega_E, "Omega_H": Omega_H,
    }


def replicator_rhs_nonlinear_infrastructure(
    t: float,
    variables: np.ndarray,
    p: Parameters,
    s: Optional[ModelSwitches] = None
) -> List[float]:
    """
    Replicator dynamics for the nonlinear infrastructure-entry extension.

    This RHS is payoff-based rather than reduced-coefficient-based because Omega_E(w)
    and Omega_H(z) make the payoffs state-dependent.
    """
    if s is None:
        s = ModelSwitches()

    # Numerical safeguards: the feasible state space is w >= 0, y >= 0, z >= 0,
    # y <= 1, and w + z <= 1. The continuous replicator system preserves this
    # simplex analytically, but clipping avoids solver difficulties caused by tiny
    # floating-point excursions near the boundary.
    w, y, z = map(float, variables)
    w = float(np.clip(w, 0.0, 1.0))
    y = float(np.clip(y, 0.0, 1.0))
    z = float(np.clip(z, 0.0, 1.0))
    if w + z > 1.0:
        total_green = w + z
        w = w / total_green
        z = z / total_green
    diesel_weight = 1.0 - w - z
    pay = compute_payoffs_nonlinear_infrastructure(p=p, variables=(w, y, z), s=s)

    E_z = y * pay["TD1"] + (1.0 - y) * pay["TD2"]
    E_w = y * pay["TD3"] + (1.0 - y) * pay["TD4"]
    E_d = y * pay["TD5"] + (1.0 - y) * pay["TD6"]
    avg_to = z * E_z + w * E_w + diesel_weight * E_d

    E_y = z * pay["G1"] + w * pay["G3"] + diesel_weight * pay["G5"]
    E_not_y = z * pay["G2"] + w * pay["G4"] + diesel_weight * pay["G6"]

    dw_dt = w * (E_w - avg_to)
    dz_dt = z * (E_z - avg_to)
    dy_dt = y * (1.0 - y) * (E_y - E_not_y)

    return [dw_dt, dy_dt, dz_dt]


def solve_replicator_nonlinear_infrastructure(
    p: Parameters,
    initial_state: Iterable[float],
    t_span: Tuple[float, float] = (0.0, 0.08),
    t_eval: Optional[np.ndarray] = None,
    switches: Optional[ModelSwitches] = None
) -> solve_ivp:
    """Numerical solver for the nonlinear infrastructure-entry extension."""
    if switches is None:
        switches = ModelSwitches()
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 500)
    return solve_ivp(
        fun=lambda t, x: replicator_rhs_nonlinear_infrastructure(t, x, p, switches),
        t_span=t_span,
        y0=np.array(list(initial_state), dtype=float),
        t_eval=t_eval,
        # LSODA is more robust here because the nonlinear infrastructure burden can
        # make trajectories converge very quickly for large fixed-entry costs.
        method="LSODA",
        atol=1e-9,
        rtol=1e-7,
    )


def solve_multiple_initial_conditions_nonlinear_infrastructure(
    p: Parameters,
    initial_conditions: List[Iterable[float]],
    t_span: Tuple[float, float] = (0.0, 0.08),
    t_eval: Optional[np.ndarray] = None,
    switches: Optional[ModelSwitches] = None
) -> Dict[str, Any]:
    return {
        f"run_{i}": solve_replicator_nonlinear_infrastructure(p, ic, t_span, t_eval, switches)
        for i, ic in enumerate(initial_conditions, start=1)
    }


def classify_solution_nonlinear_infrastructure(
    sol: Any,
    p: Parameters,
    s: Optional[ModelSwitches] = None,
    tol: float = 1e-2,
    feasibility_eps: float = 1e-6,
    oscillation_tol: float = 5e-3,
    rhs_tol: float = 1e-4
) -> str:
    """
    Heuristic classifier for the nonlinear infrastructure-entry extension.
    It does not claim analytical ESS status; it classifies numerical final outcomes.
    """
    if s is None:
        s = ModelSwitches()

    cleaned = clean_final_state_for_classification(sol.y[:, -1], eps=feasibility_eps)
    if cleaned is None:
        return "Outside feasible simplex"

    w, y, z, _ = cleaned
    pure_label = classify_outcome((w, y, z), p=None, s=None, tol=tol, feasibility_eps=feasibility_eps)
    if pure_label != "Other":
        return pure_label

    n_tail = max(5, int(0.2 * sol.y.shape[1]))
    tail = sol.y[:, -n_tail:]
    tail_span = np.max(tail, axis=1) - np.min(tail, axis=1)
    rhs_norm = float(np.linalg.norm(replicator_rhs_nonlinear_infrastructure(sol.t[-1], np.array([w, y, z]), p, s)))

    if np.max(tail_span) > oscillation_tol and rhs_norm > rhs_tol:
        return "Limit cycle / oscillatory"
    if rhs_norm > rhs_tol:
        return "Other non-convergent"
    return "Other"


def classify_with_multiple_initial_conditions_nonlinear_infrastructure(
    base_params: Parameters,
    param_x: str,
    x_values: Iterable[float],
    param_y: str,
    y_values: Iterable[float],
    initial_conditions: List[Iterable[float]],
    t_span: Tuple[float, float],
    t_eval: Optional[np.ndarray],
    switches: Optional[ModelSwitches]
) -> Dict[str, Any]:
    """2D regional map helper for the nonlinear infrastructure-entry extension."""
    x_values, y_values = list(x_values), list(y_values)
    labels = np.empty((len(y_values), len(x_values)), dtype=object)

    for i, yv in enumerate(y_values):
        for j, xv in enumerate(x_values):
            p = replace(base_params, **{param_x: xv, param_y: yv})
            regime_labels = []
            for ic in initial_conditions:
                sol = solve_replicator_nonlinear_infrastructure(
                    p=p,
                    initial_state=ic,
                    t_span=t_span,
                    t_eval=t_eval,
                    switches=switches
                )
                regime_labels.append(classify_solution_nonlinear_infrastructure(sol, p=p, s=switches))

            unique_outcomes = sorted(list(set(regime_labels)))
            if len(unique_outcomes) == 1:
                labels[i, j] = unique_outcomes[0]
            else:
                short_names = [out.split(" ")[0] for out in unique_outcomes]
                labels[i, j] = "Bistable: " + " & ".join(short_names)

    return {
        "x_name": param_x,
        "x_values": x_values,
        "y_name": param_y,
        "y_values": y_values,
        "labels": labels
    }
def sanitize_final_state(w: float, y: float, z: float) -> tuple[float, float, float, float]:
    """
    Backward-compatible helper kept only for plotting/debugging.
    Do NOT use this for ESS classification.
    """
    w, y, z = map(lambda v: float(np.clip(v, 0.0, 1.0)), (w, y, z))
    total_green = w + z
    if total_green > 1.0:
        w, z = w / total_green, z / total_green
    return w, y, z, max(0.0, 1.0 - w - z)


def clean_final_state_for_classification(
    final_state: Iterable[float],
    eps: float = 1e-6
) -> Optional[Tuple[float, float, float, float]]:
    """
    Classification-safe feasibility check.
    Only snaps tiny numerical noise to the boundary.
    It does NOT renormalize the state.
    Returns (w, y, z, diesel_share) if feasible, otherwise None.
    """
    w, y, z = map(float, final_state)

    if not np.all(np.isfinite([w, y, z])):
        return None

    def snap_unit(v: float) -> float:
        if -eps <= v <= eps:
            return 0.0
        if 1.0 - eps <= v <= 1.0 + eps:
            return 1.0
        return v

    w, y, z = map(snap_unit, (w, y, z))

    if w < -eps or y < -eps or z < -eps:
        return None
    if w > 1.0 + eps or y > 1.0 + eps or z > 1.0 + eps:
        return None

    diesel_share = 1.0 - w - z
    if -eps <= diesel_share <= eps:
        diesel_share = 0.0

    if diesel_share < -eps or diesel_share > 1.0 + eps:
        return None

    return float(w), float(y), float(z), float(diesel_share)


def _safe_div(num: float, den: float, eps: float = 1e-12) -> Optional[float]:
    if abs(den) <= eps:
        return None
    return float(num / den)


def _build_equilibrium_state(
    z_val: Optional[float],
    w_val: Optional[float],
    y_val: Optional[float],
    eps: float = 1e-9
) -> Optional[Tuple[float, float, float]]:
    """
    Paper gives equilibria in (z, w, y) order.
    Internal simulation state is (w, y, z).
    """
    if z_val is None or w_val is None or y_val is None:
        return None

    cleaned = clean_final_state_for_classification((w_val, y_val, z_val), eps=eps)
    if cleaned is None:
        return None

    w, y, z, _ = cleaned
    return (w, y, z)


def get_equilibrium_catalog(
    p: Parameters,
    s: Optional[ModelSwitches] = None,
    eps: float = 1e-9
) -> Dict[str, Dict[str, Any]]:
    """
    Builds the analytical equilibrium catalog from the reduced coefficients
    and marks which equilibria satisfy the paper's ESS stability conditions.
    """
    if s is None:
        s = ModelSwitches()

    cfs = compute_reduced_coefficients(p, s)
    a, b, c, d = cfs["a"], cfs["b"], cfs["c"], cfs["d"]
    g, k, TqD = cfs["g"], cfs["k"], cfs["TqD"]

    catalog: Dict[str, Dict[str, Any]] = {}

    # Pure equilibria
    catalog["E1 (0,0,0)"] = {
        "state": (0.0, 0.0, 0.0),   # (w, y, z)
        "stable": (b > eps and d > eps and TqD < -eps)
    }
    catalog["E2 (1,0,0)"] = {
        "state": (0.0, 0.0, 1.0),
        "stable": (b < -eps and b < d - eps and TqD < -k - eps)
    }
    catalog["E3 (1,0,1)"] = {
        "state": (0.0, 1.0, 1.0),
        "stable": (a + b < -eps and a + b < c + d - eps and TqD > -k + eps)
    }
    catalog["E4 (0,1,0)"] = {
        "state": (1.0, 0.0, 0.0),
        "stable": (d < -eps and d < b - eps and g + TqD < -eps)
    }
    catalog["E5 (0,0,1)"] = {
        "state": (0.0, 1.0, 0.0),
        "stable": (a + b > eps and c + d > eps and TqD > eps)
    }
    catalog["E6 (0,1,1)"] = {
        "state": (1.0, 1.0, 0.0),
        "stable": (c + d < -eps and c + d < a + b - eps and g + TqD > eps)
    }

    # Mixed E7: paper order (z, w, y) = (-TqD/k, 0, -b/a)
    z7 = _safe_div(-TqD, k, eps)
    y7 = _safe_div(-b, a, eps)
    e7_state = _build_equilibrium_state(z7, 0.0, y7, eps=eps)
    e7_stable = (
        e7_state is not None and
        abs(a) > eps and
        ((b * c - a * d) / a) < -eps
    )
    catalog["E7 (Mixed)"] = {
        "state": e7_state,
        "stable": e7_stable
    }

    # Mixed E8: paper order (z, w, y) = (0, -TqD/g, -d/c)
    w8 = _safe_div(-TqD, g, eps)
    y8 = _safe_div(-d, c, eps)
    e8_state = _build_equilibrium_state(0.0, w8, y8, eps=eps)
    e8_stable = (
        e8_state is not None and
        abs(c) > eps and
        ((a * d - b * c) / c) < -eps
    )
    catalog["E8 (Mixed)"] = {
        "state": e8_state,
        "stable": e8_stable
    }

    # E9 candidate (unstable saddle): paper order (z, w, y)
    z9 = _safe_div(g + TqD, g - k, eps)
    w9 = _safe_div(-(k + TqD), g - k, eps)
    y9 = _safe_div(-b + d, a - c, eps)
    e9_state = _build_equilibrium_state(z9, w9, y9, eps=eps)
    catalog["E9 saddle (unstable)"] = {
        "state": e9_state,
        "stable": False
    }

    return catalog


def _match_state_to_catalog(
    state_wyz: Tuple[float, float, float],
    catalog: Dict[str, Dict[str, Any]],
    tol: float = 1e-2,
    stable_only: bool = True
) -> Optional[str]:
    for label, info in catalog.items():
        eq_state = info.get("state")
        if eq_state is None:
            continue
        if stable_only and not info.get("stable", False):
            continue

        if max(abs(state_wyz[i] - eq_state[i]) for i in range(3)) <= tol:
            return label

    return None


def classify_outcome(
    final_state: Iterable[float],
    p: Optional[Parameters] = None,
    s: Optional[ModelSwitches] = None,
    tol: float = 1e-2,
    feasibility_eps: float = 1e-6
) -> str:
    """
    Final-state classifier.
    If p is provided, this uses analytical ESS matching.
    """
    cleaned = clean_final_state_for_classification(final_state, eps=feasibility_eps)
    if cleaned is None:
        return "Outside feasible simplex"

    w, y, z, _ = cleaned

    # Fallback only if no parameter object is provided
    if p is None:
        is_0 = lambda val: val < tol
        is_1 = lambda val: val > 1.0 - tol

        if is_0(z) and is_0(w) and is_0(y):
            return "E1 (0,0,0)"
        if is_1(z) and is_0(w) and is_0(y):
            return "E2 (1,0,0)"
        if is_1(z) and is_0(w) and is_1(y):
            return "E3 (1,0,1)"
        if is_0(z) and is_1(w) and is_0(y):
            return "E4 (0,1,0)"
        if is_0(z) and is_0(w) and is_1(y):
            return "E5 (0,0,1)"
        if is_0(z) and is_1(w) and is_1(y):
            return "E6 (0,1,1)"
        return "Other"

    if s is None:
        s = ModelSwitches()

    catalog = get_equilibrium_catalog(p, s, eps=feasibility_eps)

    stable_label = _match_state_to_catalog((w, y, z), catalog, tol=tol, stable_only=True)
    if stable_label is not None:
        return stable_label

    e9_state = catalog["E9 saddle (unstable)"]["state"]
    if e9_state is not None:
        if max(abs([w - e9_state[0], y - e9_state[1], z - e9_state[2]][i]) for i in range(3)) <= tol:
            return "E9 saddle (unstable)"

    return "Other"


def classify_solution(
    sol: Any,
    p: Parameters,
    s: Optional[ModelSwitches] = None,
    tol: float = 1e-2,
    feasibility_eps: float = 1e-6,
    oscillation_tol: float = 5e-3,
    rhs_tol: float = 1e-4
) -> str:
    """
    Solution-aware classifier.
    Priority:
      1) stable ESS match
      2) unstable E9 saddle match
      3) oscillatory / limit-cycle-like behavior
      4) other non-convergent / other
    """
    if s is None:
        s = ModelSwitches()

    cleaned = clean_final_state_for_classification(sol.y[:, -1], eps=feasibility_eps)
    if cleaned is None:
        return "Outside feasible simplex"

    w, y, z, _ = cleaned

    # 1) ESS match
    label = classify_outcome((w, y, z), p=p, s=s, tol=tol, feasibility_eps=feasibility_eps)
    if label != "Other":
        return label

    # 2) Check dynamic behavior in the tail
    n_tail = max(5, int(0.2 * sol.y.shape[1]))
    tail = sol.y[:, -n_tail:]
    tail_span = np.max(tail, axis=1) - np.min(tail, axis=1)
    rhs_norm = float(np.linalg.norm(replicator_rhs_reduced(sol.t[-1], np.array([w, y, z]), p, s)))

    if np.max(tail_span) > oscillation_tol and rhs_norm > rhs_tol:
        return "Limit cycle / oscillatory"

    if rhs_norm > rhs_tol:
        return "Other non-convergent"

    return "Other"


def classify_with_multiple_initial_conditions(
    base_params: Parameters,
    param_x: str,
    x_values: Iterable[float],
    param_y: str,
    y_values: Iterable[float],
    initial_conditions: List[Iterable[float]],
    t_span: Tuple[float, float],
    t_eval: Optional[np.ndarray],
    switches: Optional[ModelSwitches]
) -> Dict[str, Any]:
    x_values, y_values = list(x_values), list(y_values)
    labels = np.empty((len(y_values), len(x_values)), dtype=object)

    for i, yv in enumerate(y_values):
        for j, xv in enumerate(x_values):
            p = replace(base_params, **{param_x: xv, param_y: yv})
            regime_labels = []

            for ic in initial_conditions:
                sol = solve_replicator(
                    p=p,
                    initial_state=ic,
                    t_span=t_span,
                    t_eval=t_eval,
                    switches=switches
                )
                regime_labels.append(classify_solution(sol, p=p, s=switches))

            unique_outcomes = sorted(list(set(regime_labels)))
            if len(unique_outcomes) == 1:
                labels[i, j] = unique_outcomes[0]
            else:
                short_names = [out.split(" ")[0] for out in unique_outcomes]
                labels[i, j] = "Bistable: " + " & ".join(short_names)

    return {
        "x_name": param_x,
        "x_values": x_values,
        "y_name": param_y,
        "y_values": y_values,
        "labels": labels
    }


def classify_3d_sensitivity(
    base_params: Parameters,
    param_x: str,
    x_values: Iterable[float],
    param_y: str,
    y_values: Iterable[float],
    param_z: str,
    z_values: Iterable[float],
    initial_conditions: List[Iterable[float]],
    t_span: Tuple[float, float],
    t_eval: Optional[np.ndarray],
    switches: Optional[ModelSwitches]
) -> Dict[str, Any]:

    results_flat = []

    for zv in z_values:
        for yv in y_values:
            for xv in x_values:
                p = replace(base_params, **{param_x: xv, param_y: yv, param_z: zv})
                regime_labels = []

                for ic in initial_conditions:
                    sol = solve_replicator(
                        p=p,
                        initial_state=ic,
                        t_span=t_span,
                        t_eval=t_eval,
                        switches=switches
                    )
                    regime_labels.append(classify_solution(sol, p=p, s=switches))

                unique_outcomes = sorted(list(set(regime_labels)))
                if len(unique_outcomes) == 1:
                    label = unique_outcomes[0]
                else:
                    short_names = [out.split(" ")[0] for out in unique_outcomes]
                    label = "Bistable: " + " & ".join(short_names)

                results_flat.append({
                    "x": xv,
                    "y": yv,
                    "z": zv,
                    "label": label
                })

    return {
        "x_name": param_x,
        "y_name": param_y,
        "z_name": param_z,
        "results_flat": results_flat
    }

# ============================================================
# 5) CLASSIC MANAGEMENT SCIENCE PLOTTING
# ============================================================

# Classic Elegant Palette
CLASSIC_COLORS = {
    "E1 (0,0,0)": "#fff7fb",
    "E2 (1,0,0)": "#ece7f2",
    "E3 (1,0,1)": "#d0d1e6",
    "E4 (0,1,0)": "#a6bddb",
    "E5 (0,0,1)": "#74a9cf",
    "E6 (0,1,1)": "#3690c0",
    "E7 (Mixed)": "#0570b0",
    "E8 (Mixed)": "#045a8d",
    "E9 saddle (unstable)": "#023858",
    "Limit cycle / oscillatory": "#d9d9d9",
    "Other non-convergent": "#969696",
    "Outside feasible simplex": "#737373",
    "Other": "#FFFFFF"
}
CLASSIC_BISTABLE = ["#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4"] # Burgundy, Rust, Ochre, Plum


# # Classic Elegant Palette
# CLASSIC_COLORS = {
#     "E1 (0,0,0)": "#555555",
#     "E2 (1,0,0)": "#7FF3FC",
#     "E3 (1,0,1)": "#F0EC17",
#     "E4 (0,1,0)": "#C3F375DA",
#     "E5 (0,0,1)": "#C2C2C2",
#     "E6 (0,1,1)": "#0F7BFF",
#     "E7 (Mixed)": "#FFCA56",
#     "E8 (Mixed)": "#C8DD52F2",
#     "E9 saddle (unstable)": "#EE1D2E",
#     "Limit cycle / oscillatory": "#F28E2B",
#     "Other non-convergent": "#9E9E9E",
#     "Outside feasible simplex": "#000000",
#     "Other": "#FFFFFF"
# }
# CLASSIC_BISTABLE = ["#7FF3FC", "#F0EC17", "#C2C2C2", "#C3F375DA"] # Burgundy, Rust, Ochre, Plum



def plot_clean_regional_map(
    sensitivity_result: Dict[str, Any], title: str, xlabel: str, ylabel: str, style: str = "smooth"
) -> None:
    
    # Global setup for classic academic look
    plt.rcParams['font.family'] = 'serif'
    
    # INCREASED FONT SIZES
    LABEL_SIZE, TICK_SIZE, LEGEND_SIZE = 24, 18, 14

    labels = sensitivity_result["labels"]
    x_values, y_values = np.array(sensitivity_result["x_values"], dtype=float), np.array(sensitivity_result["y_values"], dtype=float)
    unique_labels = sorted(list(set(labels.flatten())))
    
    active_colors = []
    bistable_counter = 0
    for lbl in unique_labels:
        if lbl in CLASSIC_COLORS: active_colors.append(CLASSIC_COLORS[lbl])
        elif "Bistable" in lbl:
            active_colors.append(CLASSIC_BISTABLE[bistable_counter % len(CLASSIC_BISTABLE)])
            bistable_counter += 1
        else: active_colors.append("#000000")

    label_to_int = {lbl: i for i, lbl in enumerate(unique_labels)}
    zmat = np.zeros(labels.shape, dtype=int)
    for i in range(labels.shape[0]):
        for j in range(labels.shape[1]): zmat[i, j] = label_to_int.get(labels[i, j], 0)

    bounds = np.arange(-0.5, len(unique_labels) + 0.5, 1)
    fig, ax = plt.subplots(figsize=(10, 8))

    # --- REGION BOUNDARIES ---
    if style == "smooth":
        X, Y = np.meshgrid(x_values, y_values)
        for i in range(len(unique_labels)):
            z_mask = np.where(zmat == i, 1, 0)
            if np.any(z_mask): ax.contourf(X, Y, z_mask, levels=[0.5, 1.5], colors=[active_colors[i]], antialiased=True)
        ax.contour(X, Y, zmat, levels=bounds, colors='black', linewidths=2.5, antialiased=True) 
    else:
        dx, dy = (x_values[1] - x_values[0]) if len(x_values)>1 else 1.0, (y_values[1] - y_values[0]) if len(y_values)>1 else 1.0
        for i in range(len(y_values)):
            for j in range(len(x_values)):
                rect = mpatches.Rectangle((x_values[j] - dx/2, y_values[i] - dy/2), dx, dy, facecolor=active_colors[zmat[i, j]], edgecolor="black", linewidth=2.5)
                ax.add_patch(rect)
        ax.set_xlim(x_values[0] - dx/2, x_values[-1] + dx/2); ax.set_ylim(y_values[0] - dy/2, y_values[-1] + dy/2)

    # --- BOX/SPINES ---
    for spine in ax.spines.values(): spine.set_linewidth(3.0)

    # --- LEGEND ---
    legend_patches = [mpatches.Patch(facecolor=active_colors[i], edgecolor="black", linewidth=1.5, label=unique_labels[i]) for i in range(len(unique_labels))]
    legend = ax.legend(handles=legend_patches, loc='center left', bbox_to_anchor=(1.05, 0.5), title="Equilibrium State", prop={'size': 16, 'weight': 'bold'}, frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
    plt.setp(legend.get_title(), fontsize=16, weight='bold')

    # --- TITLE REMOVED ---
    # ax.set_title(title, ...) is intentionally omitted

    # --- BOLD AND LARGER AXIS LABELS ---
    ax.set_xlabel(xlabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=12)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=12)
    
    # --- BOLD AND LARGER TICK NUMBERS ---
    ax.tick_params(axis='both', labelsize=TICK_SIZE)
    for tick in ax.get_xticklabels():
        tick.set_fontweight('bold')
    for tick in ax.get_yticklabels():
        tick.set_fontweight('bold')
    
    plt.tight_layout()
    plt.show()

def plot_3d_regional_map(sens_3d_result: Dict[str, Any], title: str, xlabel: str, ylabel: str, zlabel: str) -> None:
    
    plt.rcParams['font.family'] = 'serif'
    
    # INCREASED FONT SIZES
    LABEL_SIZE, TICK_SIZE, LEGEND_SIZE = 24, 18, 14

    results = sens_3d_result["results_flat"]
    unique_labels = sorted(list(set([r["label"] for r in results])))
    
    active_colors = {}
    bistable_counter = 0
    for lbl in unique_labels:
        if lbl in CLASSIC_COLORS: active_colors[lbl] = CLASSIC_COLORS[lbl]
        elif "Bistable" in lbl:
            active_colors[lbl] = CLASSIC_BISTABLE[bistable_counter % len(CLASSIC_BISTABLE)]
            bistable_counter += 1
        else: active_colors[lbl] = "#000000"

    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(111, projection='3d')

    for label in unique_labels:
        xs = [r["x"] for r in results if r["label"] == label]
        ys = [r["y"] for r in results if r["label"] == label]
        zs = [r["z"] for r in results if r["label"] == label]
        
        ax.scatter(xs, ys, zs, label=label, s=150, color=active_colors[label], edgecolor='black', linewidth=0.8, alpha=0.9)

    ax.xaxis.pane.fill, ax.yaxis.pane.fill, ax.zaxis.pane.fill = False, False, False
    ax.xaxis.line.set_linewidth(1.2); ax.yaxis.line.set_linewidth(1.2); ax.zaxis.line.set_linewidth(1.2)

    # --- TITLE REMOVED ---
    # ax.set_title(title, ...) is intentionally omitted

    # --- BOLD AND LARGER AXIS LABELS ---
    ax.set_xlabel(xlabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=15)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=15)
    ax.set_zlabel(zlabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=15)
    
    # --- BOLD AND LARGER TICK NUMBERS ---
    ax.tick_params(axis='both', labelsize=TICK_SIZE)
    for tick in ax.get_xticklabels():
        tick.set_fontweight('bold')
    for tick in ax.get_yticklabels():
        tick.set_fontweight('bold')
    for tick in ax.get_zticklabels():
        tick.set_fontweight('bold')

    # --- LEGEND ---
    legend = ax.legend(loc='center left', bbox_to_anchor=(1.1, 0.5), title="Equilibrium State", prop={'size': 16, 'weight': 'bold'}, frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
    plt.setp(legend.get_title(), fontsize=16, weight='bold')

    plt.tight_layout()
    plt.show()

def plot_3d_voxel_region_map(
    sens_3d_result: Dict[str, Any],
    title: str,
    xlabel: str,
    ylabel: str,
    zlabel: str
) -> None:
    plt.rcParams['font.family'] = 'serif'

    LABEL_SIZE, TICK_SIZE, LEGEND_SIZE = 24, 18, 14

    results = sens_3d_result["results_flat"]
    unique_labels = sorted(list(set([r["label"] for r in results])))

    active_colors = {}
    bistable_counter = 0
    for lbl in unique_labels:
        if lbl in CLASSIC_COLORS:
            active_colors[lbl] = CLASSIC_COLORS[lbl]
        elif "Bistable" in lbl:
            active_colors[lbl] = CLASSIC_BISTABLE[bistable_counter % len(CLASSIC_BISTABLE)]
            bistable_counter += 1
        else:
            active_colors[lbl] = "#000000"

    x_values = np.array(sorted(set(float(r["x"]) for r in results)), dtype=float)
    y_values = np.array(sorted(set(float(r["y"]) for r in results)), dtype=float)
    z_values = np.array(sorted(set(float(r["z"]) for r in results)), dtype=float)

    x_index = {v: i for i, v in enumerate(x_values)}
    y_index = {v: i for i, v in enumerate(y_values)}
    z_index = {v: i for i, v in enumerate(z_values)}

    label_grid = np.empty((len(x_values), len(y_values), len(z_values)), dtype=object)
    for r in results:
        i = x_index[float(r["x"])]
        j = y_index[float(r["y"])]
        k = z_index[float(r["z"])]
        label_grid[i, j, k] = r["label"]

    def centers_to_edges(vals: np.ndarray) -> np.ndarray:
        vals = np.asarray(vals, dtype=float)
        if len(vals) == 1:
            return np.array([vals[0] - 0.5, vals[0] + 0.5], dtype=float)

        mids = 0.5 * (vals[:-1] + vals[1:])
        first = vals[0] - (mids[0] - vals[0])
        last = vals[-1] + (vals[-1] - mids[-1])
        return np.concatenate(([first], mids, [last]))

    x_edges = centers_to_edges(x_values)
    y_edges = centers_to_edges(y_values)
    z_edges = centers_to_edges(z_values)

    X, Y, Z = np.meshgrid(x_edges, y_edges, z_edges, indexing="ij")

    fig = plt.figure(figsize=(13, 10))
    ax = fig.add_subplot(111, projection='3d')

    for label in unique_labels:
        filled = (label_grid == label)
        if not np.any(filled):
            continue

        facecolors = np.empty(filled.shape, dtype=object)
        facecolors[:] = active_colors[label]

        ax.voxels(
            X, Y, Z,
            filled,
            facecolors=facecolors,
            edgecolor='black',
            linewidth=0.25,
            shade=False
        )

    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.xaxis.line.set_linewidth(1.2)
    ax.yaxis.line.set_linewidth(1.2)
    ax.zaxis.line.set_linewidth(1.2)

    xr = max(x_edges[-1] - x_edges[0], 1e-9)
    yr = max(y_edges[-1] - y_edges[0], 1e-9)
    zr = max(z_edges[-1] - z_edges[0], 1e-9)
    ax.set_box_aspect((xr, yr, zr))

    ax.set_xlim(x_edges[0], x_edges[-1])
    ax.set_ylim(y_edges[0], y_edges[-1])
    ax.set_zlim(z_edges[0], z_edges[-1])

    ax.set_xlabel(xlabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=15)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=15)
    ax.set_zlabel(zlabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=15)

    ax.tick_params(axis='both', labelsize=TICK_SIZE)
    for tick in ax.get_xticklabels():
        tick.set_fontweight('bold')
    for tick in ax.get_yticklabels():
        tick.set_fontweight('bold')
    for tick in ax.get_zticklabels():
        tick.set_fontweight('bold')

    ax.view_init(elev=22, azim=-55)

    legend_patches = [
        mpatches.Patch(
            facecolor=active_colors[label],
            edgecolor="black",
            linewidth=1.0,
            label=label
        )
        for label in unique_labels
    ]
    legend = ax.legend(
        handles=legend_patches,
        loc='center left',
        bbox_to_anchor=(1.05, 0.5),
        title="Equilibrium State",
        prop={'size': 16, 'weight': 'bold'},
        frameon=True, facecolor='white', framealpha=0.95, edgecolor='black'
    )
    plt.setp(legend.get_title(), fontsize=16, weight='bold')

    plt.tight_layout()
    plt.show()


def print_ess_combinations_report(
    base_params: Parameters,
    param_x: str,
    x_values: Iterable[float],
    param_y: str,
    y_values: Iterable[float],
    initial_conditions: List[Iterable[float]],
    t_span: Tuple[float, float] = (0.0, 0.08),
    t_eval: Optional[np.ndarray] = None,
    switches: Optional[ModelSwitches] = None
) -> None:
    print(f"\n{'='*90}")
    print(f"ESS COMBINATIONS REPORT: {param_x} vs {param_y}")
    print(f"{'='*90}")
    print(f"{param_x:<12} | {param_y:<12} | {'Final state (w, y, z)':<35} | {'Dominant classification'}")
    print("-" * 90)

    for yv in y_values:
        for xv in x_values:
            p = replace(base_params, **{param_x: xv, param_y: yv})
            regime_labels, coords = [], []

            for ic in initial_conditions:
                sol = solve_replicator(
                    p=p,
                    initial_state=ic,
                    t_span=t_span,
                    t_eval=t_eval,
                    switches=switches
                )

                regime_labels.append(classify_solution(sol, p=p, s=switches))

                cleaned = clean_final_state_for_classification(sol.y[:, -1])
                if cleaned is None:
                    coords.append("infeasible")
                else:
                    w_fin, y_fin, z_fin, _ = cleaned
                    coords.append(f"w={w_fin:.3f}, y={y_fin:.3f}, z={z_fin:.3f}")

            unique_outcomes = sorted(list(set(regime_labels)))
            if len(unique_outcomes) == 1:
                final_label = unique_outcomes[0]
                display_coord = coords[0]
            else:
                short_names = [out.split(" ")[0] for out in unique_outcomes]
                final_label = "Bistable: " + " & ".join(short_names)
                display_coord = "Depends on IC"

            print(f"{xv:<12.4f} | {yv:<12.4f} | {display_coord:<35} | {final_label}")

    print(f"{'='*90}\n")



def classify_basin_of_attraction(
    p: Parameters,
    w_range: Tuple[float, float],
    y_range: Tuple[float, float],
    z0_fixed: float,
    resolution: int,
    t_span: Tuple[float, float],
    t_eval: Optional[np.ndarray],
    switches: Optional[ModelSwitches]
) -> Dict[str, Any]:

    if switches is None:
        switches = ModelSwitches()

    w_vals = np.linspace(w_range[0], w_range[1], resolution)
    y_vals = np.linspace(y_range[0], y_range[1], resolution)
    labels = np.empty((resolution, resolution), dtype=object)

    for i, y0 in enumerate(y_vals):
        for j, w0 in enumerate(w_vals):
            ic = [w0, y0, z0_fixed]
            sol = solve_replicator(
                p=p,
                initial_state=ic,
                t_span=t_span,
                t_eval=t_eval,
                switches=switches
            )
            labels[i, j] = classify_solution(sol, p=p, s=switches)

    return {
        "w_vals": w_vals,
        "y_vals": y_vals,
        "labels": labels,
        "z0_fixed": z0_fixed
    }

def plot_basin_of_attraction(basin_result: Dict[str, Any], xlabel: str, ylabel: str) -> None:
    plt.rcParams['font.family'] = 'serif'
    LABEL_SIZE, TICK_SIZE, LEGEND_SIZE = 24, 18, 14

    w_vals = basin_result["w_vals"]
    y_vals = basin_result["y_vals"]
    labels = basin_result["labels"]
    
    unique_labels = sorted(list(set(labels.flatten())))
    
    # Assign colors based on classic palettes
    active_colors = []
    bistable_counter = 0
    for lbl in unique_labels:
        if lbl in CLASSIC_COLORS: active_colors.append(CLASSIC_COLORS[lbl])
        elif "Bistable" in lbl:
            active_colors.append(CLASSIC_BISTABLE[bistable_counter % len(CLASSIC_BISTABLE)])
            bistable_counter += 1
        else: active_colors.append("#000000")
        
    label_to_int = {lbl: idx for idx, lbl in enumerate(unique_labels)}
    zmat = np.zeros(labels.shape, dtype=int)
    for i in range(len(y_vals)):
        for j in range(len(w_vals)): 
            zmat[i, j] = label_to_int[labels[i, j]]

    fig, ax = plt.subplots(figsize=(10, 8))
    X, Y = np.meshgrid(w_vals, y_vals)
    bounds = np.arange(-0.5, len(unique_labels) + 0.5, 1)
    
    for i in range(len(unique_labels)):
        z_mask = np.where(zmat == i, 1, 0)
        if np.any(z_mask): 
            ax.contourf(X, Y, z_mask, levels=[0.5, 1.5], colors=[active_colors[i]], antialiased=True)
            
    ax.contour(X, Y, zmat, levels=bounds, colors='black', linewidths=3.0, antialiased=True) 

    for spine in ax.spines.values(): spine.set_linewidth(3.0)

    legend_patches = [mpatches.Patch(facecolor=active_colors[i], edgecolor="black", linewidth=1.5, label=unique_labels[i]) for i in range(len(unique_labels))]
    legend = ax.legend(handles=legend_patches, loc='center left', bbox_to_anchor=(1.05, 0.5), title="Final Outcome", prop={'size': 16, 'weight': 'bold'}, frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
    plt.setp(legend.get_title(), fontsize=16, weight='bold')

    ax.set_xlabel(xlabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=12)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE, fontweight='bold', labelpad=12)
    
    ax.tick_params(axis='both', labelsize=TICK_SIZE)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight('bold')

    plt.tight_layout()
    plt.show()