"""Run only Analysis 3: combined rho_E--F_E viability frontier for Section 4.6."""

from run_section46_premium_analysis import (
    make_base_extension_parameters,
    plot_combined_rhoE_infraFE_frontier,
    OUTPUT_DIR,
)


def main() -> None:
    base_params = make_base_extension_parameters()
    plot_combined_rhoE_infraFE_frontier(base_params)
    print(f"\nFrontier figure and data saved in: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    main()