"""Run explanatory figure: nonlinear infrastructure-entry burden shape Omega_E(w)."""
from run_section46_premium_analysis import make_base_extension_parameters, plot_infrastructure_burden_shape, OUTPUT_DIR

if __name__ == "__main__":
    plot_infrastructure_burden_shape(make_base_extension_parameters())
    print(f"Figure saved in: {OUTPUT_DIR.resolve()}")