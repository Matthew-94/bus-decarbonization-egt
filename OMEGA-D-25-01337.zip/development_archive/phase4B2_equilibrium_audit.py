# =============================================================================
# PHASE 4B-2
# E1-E9 EQUILIBRIUM / JACOBIAN NUMERICAL CERTIFICATION
# =============================================================================

import numpy as np

from transit_model_phase4B import (
    make_scenario,
    derived_quantities,
    replicator_rhs,
    pure_stability_report,
)


# =============================================================================
# 1. FORMAL E1-E9 CANDIDATES
# =============================================================================

def equilibrium_candidates(p):

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GH1 = d["Gamma_H1"]

    GE0 = d["Gamma_E0"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    candidates = {

        # -------------------------------------------------------------
        # Six pure candidates
        # State order = [z, w, y]
        # -------------------------------------------------------------

        "E1 = D_B": np.array(
            [0.0, 0.0, 0.0]
        ),

        "E2 = H_B": np.array(
            [1.0, 0.0, 0.0]
        ),

        "E3 = E_B": np.array(
            [0.0, 1.0, 0.0]
        ),

        "E4 = D_A": np.array(
            [0.0, 0.0, 1.0]
        ),

        "E5 = H_A": np.array(
            [1.0, 0.0, 1.0]
        ),

        "E6 = E_A": np.array(
            [0.0, 1.0, 1.0]
        ),
    }

    # -------------------------------------------------------------
    # E7 = H-D mixed edge
    # -------------------------------------------------------------

    if (
        abs(DD - DH) > 1e-14
        and abs(GH1) > 1e-14
    ):

        z_HD = DD / (DD - DH)

        y_HD = -GH0 / GH1

        candidates["E7 = HD"] = np.array(
            [
                z_HD,
                0.0,
                y_HD,
            ]
        )

    else:

        candidates["E7 = HD"] = np.array(
            [np.nan, np.nan, np.nan]
        )

    # -------------------------------------------------------------
    # E8 = E-D mixed edge
    # -------------------------------------------------------------

    if (
        abs(DD - DE) > 1e-14
        and abs(GE1) > 1e-14
    ):

        w_ED = DD / (DD - DE)

        y_ED = -GE0 / GE1

        candidates["E8 = ED"] = np.array(
            [
                0.0,
                w_ED,
                y_ED,
            ]
        )

    else:

        candidates["E8 = ED"] = np.array(
            [np.nan, np.nan, np.nan]
        )

    # -------------------------------------------------------------
    # E9 = H-E mixed edge
    # Diesel share = 0
    # -------------------------------------------------------------

    denominator_delta = (
        DE - DH
    )

    denominator_gamma = (
        GH1 - GE1
    )

    if (
        abs(denominator_delta) > 1e-14
        and abs(denominator_gamma) > 1e-14
    ):

        z_HE = (
            DE
            / denominator_delta
        )

        w_HE = (
            -DH
            / denominator_delta
        )

        y_HE = (
            GE0 - GH0
        ) / denominator_gamma

        candidates["E9 = HE"] = np.array(
            [
                z_HE,
                w_HE,
                y_HE,
            ]
        )

    else:

        candidates["E9 = HE"] = np.array(
            [np.nan, np.nan, np.nan]
        )

    return candidates


# =============================================================================
# 2. FEASIBILITY
# =============================================================================

def is_feasible(
    state,
    tol=1e-10,
):

    state = np.asarray(
        state,
        dtype=float,
    )

    if not np.all(
        np.isfinite(state)
    ):
        return False

    z, w, y = state

    return (
        z >= -tol
        and z <= 1.0 + tol
        and w >= -tol
        and w <= 1.0 + tol
        and y >= -tol
        and y <= 1.0 + tol
        and z + w <= 1.0 + tol
    )


# =============================================================================
# 3. ANALYTICAL JACOBIAN
# =============================================================================

def analytical_jacobian(
    state,
    p,
):

    z, w, y = map(
        float,
        state,
    )

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GH1 = d["Gamma_H1"]

    GE0 = d["Gamma_E0"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH = GH0 + y * GH1
    GE = GE0 + y * GE1

    P = (
        DD
        + z * (DH - DD)
        + w * (DE - DD)
    )

    J = np.array(
        [

            [
                p.eta_TO
                * (
                    (1.0 - 2.0 * z) * GH
                    - w * GE
                ),

                -p.eta_TO
                * z
                * GE,

                p.eta_TO
                * z
                * (
                    (1.0 - z) * GH1
                    - w * GE1
                ),
            ],

            [
                -p.eta_TO
                * w
                * GH,

                p.eta_TO
                * (
                    (1.0 - 2.0 * w) * GE
                    - z * GH
                ),

                p.eta_TO
                * w
                * (
                    (1.0 - w) * GE1
                    - z * GH1
                ),
            ],

            [
                p.eta_PA
                * y
                * (1.0 - y)
                * (DH - DD),

                p.eta_PA
                * y
                * (1.0 - y)
                * (DE - DD),

                p.eta_PA
                * (1.0 - 2.0 * y)
                * P,
            ],
        ],
        dtype=float,
    )

    return J


# =============================================================================
# 4. NUMERICAL FINITE-DIFFERENCE JACOBIAN
# =============================================================================

def numerical_jacobian(
    state,
    p,
    h=1e-6,
):

    x = np.asarray(
        state,
        dtype=float,
    )

    J = np.zeros(
        (3, 3),
        dtype=float,
    )

    for j in range(3):

        xp = x.copy()
        xm = x.copy()

        xp[j] += h
        xm[j] -= h

        fp = replicator_rhs(
            0.0,
            xp,
            p,
        )

        fm = replicator_rhs(
            0.0,
            xm,
            p,
        )

        J[:, j] = (
            fp - fm
        ) / (2.0 * h)

    return J


# =============================================================================
# 5. LOCAL EIGENVALUE CLASSIFICATION
# =============================================================================

def eigenvalue_classification(
    eigvals,
    tol=1e-9,
):

    real_parts = np.real(
        eigvals
    )

    if np.all(
        real_parts < -tol
    ):

        return (
            "LOCALLY ASYMPTOTICALLY STABLE"
        )

    if np.any(
        real_parts > tol
    ):

        return "UNSTABLE"

    return (
        "NONHYPERBOLIC / "
        "NOT ASYMPTOTICALLY STABLE"
    )


# =============================================================================
# 6. FULL-INTERIOR DEGENERACY CONDITION
# =============================================================================

def full_interior_condition(p):

    d = derived_quantities(p)

    residual = (
        d["Gamma_H0"]
        * d["Gamma_E1"]
        -
        d["Gamma_E0"]
        * d["Gamma_H1"]
    )

    return residual


# =============================================================================
# 7. MAIN AUDIT
# =============================================================================

if __name__ == "__main__":

    print("=" * 92)

    print(
        "PHASE 4B-2 — "
        "E1-E9 EQUILIBRIUM AND "
        "JACOBIAN CERTIFICATION"
    )

    print("=" * 92)

    for scenario_name in [
        "S1",
        "S2",
        "S3",
    ]:

        p = make_scenario(
            scenario_name
        )

        candidates = (
            equilibrium_candidates(p)
        )

        pure_stability = (
            pure_stability_report(p)
        )

        print(
            f"\n\n{scenario_name}"
        )

        print("=" * 68)

        # ---------------------------------------------------------
        # Jacobian certification at one interior point
        # ---------------------------------------------------------

        test_state = np.array(
            [0.20, 0.40, 0.50]
        )

        J_analytic = (
            analytical_jacobian(
                test_state,
                p,
            )
        )

        J_numeric = (
            numerical_jacobian(
                test_state,
                p,
            )
        )

        J_error = np.max(
            np.abs(
                J_analytic
                - J_numeric
            )
        )

        print(
            "\nJacobian certification:"
        )

        print(
            "  max |J_analytic - "
            "J_numeric| = "
            f"{J_error:.3e}"
        )

        # ---------------------------------------------------------
        # Full interior condition
        # ---------------------------------------------------------

        interior_residual = (
            full_interior_condition(p)
        )

        print(
            "\nFull H/E/D interior "
            "degeneracy condition:"
        )

        print(
            "  Gamma_H0*Gamma_E1 "
            "- Gamma_E0*Gamma_H1 "
            f"= {interior_residual:.8f}"
        )

        if abs(
            interior_residual
        ) < 1e-10:

            print(
                "  Condition satisfied: "
                "nongeneric full-interior "
                "stationary set is possible."
            )

        else:

            print(
                "  Condition NOT satisfied: "
                "no generic full-interior "
                "stationary set."
            )

        # ---------------------------------------------------------
        # E1-E9 audit
        # ---------------------------------------------------------

        print(
            "\nE1-E9 candidates:"
        )

        for name, state in (
            candidates.items()
        ):

            feasible = is_feasible(
                state
            )

            if np.all(
                np.isfinite(state)
            ):

                residual = np.max(
                    np.abs(
                        replicator_rhs(
                            0.0,
                            state,
                            p,
                        )
                    )
                )

                J = (
                    analytical_jacobian(
                        state,
                        p,
                    )
                )

                eigvals = (
                    np.linalg.eigvals(J)
                )

                local_class = (
                    eigenvalue_classification(
                        eigvals
                    )
                )

                z, w, y = state

                print(
                    f"\n  {name}"
                )

                print(
                    f"    "
                    f"(z,w,y) = "
                    f"("
                    f"{z:.6f}, "
                    f"{w:.6f}, "
                    f"{y:.6f}"
                    f")"
                )

                print(
                    f"    feasible = "
                    f"{feasible}"
                )

                print(
                    f"    max RHS residual = "
                    f"{residual:.3e}"
                )

                print(
                    "    eigenvalues = "
                    + ", ".join(
                        f"{ev.real:+.6f}"
                        f"{ev.imag:+.6f}j"
                        for ev in eigvals
                    )
                )

                print(
                    f"    local class = "
                    f"{local_class}"
                )

            else:

                print(
                    f"\n  {name}"
                )

                print(
                    "    Undefined because "
                    "a required denominator "
                    "is zero."
                )

        # ---------------------------------------------------------
        # Cross-check pure stability
        # ---------------------------------------------------------

        print(
            "\nPure-equilibrium theoretical "
            "stability report:"
        )

        for name, stable in (
            pure_stability.items()
        ):

            if stable:

                print(
                    f"  STABLE: {name}"
                )

    print(
        "\n\nCertification completed."
    )