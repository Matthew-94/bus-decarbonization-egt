import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Import only the core math/classification functions from your model
from transit_model import (
    Parameters,
    ModelSwitches,
    classify_with_multiple_initial_conditions,
    classify_basin_of_attraction
)

# ============================================================
# 1. COLOR PALETTES & LABELS
# ============================================================
CLASSIC_COLORS = {
    "E1 (0,0,0)": "#fff7fb",
    "E2 (1,0,0)": "#c7e9b4",
    "E3 (1,0,1)": "#d0d1e6",
    "E4 (0,1,0)": "#3690c0",
    "E5 (0,0,1)": "#FDEADA",
    "E6 (0,1,1)": "#3690c0",
    "E7 (Mixed)": "#0570b0",
    "E8 (Mixed)": "#045a8d",
    "E9 saddle (unstable)": "#023858",
    "Limit cycle / oscillatory": "#EBF1DE",
    "Other non-convergent": "#3690c0",
    "Outside feasible simplex": "#737373",
    "Other": "#DCE6F2"
}

# Colors used when multiple equilibria are found (Bistability)
CLASSIC_BISTABLE = ["#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4"]

# --- YOUR NEW CUSTOM DISPLAY LABELS ---
DISPLAY_LABELS = {
    "E1 (0,0,0)": "E1 (0,0,0)",
    "E2 (1,0,0)": "E2 (1,0,0)",
    "E3 (1,0,1)": "E3 (1,0,1)",
    "E4 (0,1,0)": "E4 (0,1,0)",
    "E5 (0,0,1)": "E5 (0,0,1)",
    "E6 (0,1,1)": "E6 (0,1,1)",
    "E7 (Mixed)": "E7 (mixed)",
    "E8 (Mixed)": "E8 (mixed)",
    "E9 saddle (unstable)": "E9 saddle",
    "Limit cycle / oscillatory": "Limit cycle / oscillatory",
    "Other non-convergent": "Weakly non-convergent boundary",
    "Outside feasible simplex": "Outside feasible simplex",
    "Other": "Unclassified boundary point"
}

# ============================================================
# 2. CUSTOM PLOTTING FUNCTIONS
# ============================================================

def plot_clean_regional_map(sensitivity_result, title, xlabel, ylabel, style="smooth", save_name=None):
    """Customizable 2D Regional Map Plotter"""
    
    plt.rcParams['font.family'] = 'serif'
    LABEL_SIZE = 24       
    TICK_SIZE = 18        
    LEGEND_SIZE = 16      
    TITLE_SIZE = 20       
    FONT_WEIGHT = 'bold'  
    
    TICK_DIRECTION = 'in' 
    TICK_LENGTH = 8       
    TICK_WIDTH = 1.5      
    
    SHOW_GRID = False     
    GRID_ALPHA = 0.3      

    labels = sensitivity_result["labels"]
    x_values = np.array(sensitivity_result["x_values"], dtype=float)
    y_values = np.array(sensitivity_result["y_values"], dtype=float)
    unique_labels = sorted(list(set(labels.flatten())))
    
    active_colors = []
    bistable_counter = 0
    for lbl in unique_labels:
        if lbl in CLASSIC_COLORS: 
            active_colors.append(CLASSIC_COLORS[lbl])
        elif "Bistable" in lbl:
            active_colors.append(CLASSIC_BISTABLE[bistable_counter % len(CLASSIC_BISTABLE)])
            bistable_counter += 1
        else: 
            active_colors.append("#000000")

    label_to_int = {lbl: i for i, lbl in enumerate(unique_labels)}
    zmat = np.zeros(labels.shape, dtype=int)
    for i in range(labels.shape[0]):
        for j in range(labels.shape[1]): zmat[i, j] = label_to_int.get(labels[i, j], 0)

    bounds = np.arange(-0.5, len(unique_labels) + 0.5, 1)
    fig, ax = plt.subplots(figsize=(10, 8))

    if style == "smooth":
        X, Y = np.meshgrid(x_values, y_values)
        for i in range(len(unique_labels)):
            z_mask = np.where(zmat == i, 1, 0)
            if np.any(z_mask): ax.contourf(X, Y, z_mask, levels=[0.5, 1.5], colors=[active_colors[i]], antialiased=True)
        ax.contour(X, Y, zmat, levels=bounds, colors='black', linewidths=2.5, antialiased=True) 
    else:
        dx = (x_values[1] - x_values[0]) if len(x_values)>1 else 1.0
        dy = (y_values[1] - y_values[0]) if len(y_values)>1 else 1.0
        for i in range(len(y_values)):
            for j in range(len(x_values)):
                rect = mpatches.Rectangle((x_values[j] - dx/2, y_values[i] - dy/2), dx, dy, facecolor=active_colors[zmat[i, j]], edgecolor="black", linewidth=2.5)
                ax.add_patch(rect)
        ax.set_xlim(x_values[0] - dx/2, x_values[-1] + dx/2)
        ax.set_ylim(y_values[0] - dy/2, y_values[-1] + dy/2)

    for spine in ax.spines.values(): 
        spine.set_linewidth(1.5)

    # --- USE DISPLAY_LABELS HERE ---
    # .get(lbl, lbl) means: "look up the label in the dictionary. If it's a new 'Bistable' string, just use the string itself."
    legend_patches = [
        mpatches.Patch(
            facecolor=active_colors[i], 
            edgecolor="black", 
            linewidth=1.5, 
            label=DISPLAY_LABELS.get(unique_labels[i], unique_labels[i]) 
        ) 
        for i in range(len(unique_labels))
    ]
    
    legend = ax.legend(handles=legend_patches, loc='upper left', title="Equilibrium State", prop={'size': LEGEND_SIZE, 'weight': FONT_WEIGHT}, frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
    plt.setp(legend.get_title(), fontsize=LEGEND_SIZE, weight=FONT_WEIGHT)
    legend.set_draggable(True)

    if title:
        ax.set_title(title, fontsize=TITLE_SIZE, fontweight=FONT_WEIGHT, pad=15)
    
    ax.set_xlabel(xlabel, fontsize=LABEL_SIZE, fontweight=FONT_WEIGHT, labelpad=12)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE, fontweight=FONT_WEIGHT, labelpad=12)
    
    ax.tick_params(axis='both', which='major', labelsize=TICK_SIZE, direction=TICK_DIRECTION, bottom=True, top=True, left=True, right=True, length=TICK_LENGTH, width=TICK_WIDTH)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight(FONT_WEIGHT)
        
    if SHOW_GRID:
        ax.grid(True, linestyle='--', alpha=GRID_ALPHA, color='black', zorder=3)

    plt.tight_layout()
    
    if save_name:
        plt.savefig(save_name, dpi=600, bbox_inches='tight', format='png')
        print(f"Saved high-resolution plot to {save_name}")
        
    plt.show()


def plot_basin_of_attraction(basin_result, title, xlabel, ylabel, save_name=None):
    """Customizable Basin of Attraction Plotter"""
    
    plt.rcParams['font.family'] = 'serif'
    LABEL_SIZE = 24
    TICK_SIZE = 18
    LEGEND_SIZE = 16
    TITLE_SIZE = 20
    FONT_WEIGHT = 'bold'
    
    TICK_DIRECTION = 'in' 
    TICK_LENGTH = 8       
    TICK_WIDTH = 1.5      
    
    SHOW_GRID = False
    GRID_ALPHA = 0.3

    w_vals = basin_result["w_vals"]
    y_vals = basin_result["y_vals"]
    labels = basin_result["labels"]
    
    unique_labels = sorted(list(set(labels.flatten())))
    
    active_colors = []
    bistable_counter = 0
    for lbl in unique_labels:
        if lbl in CLASSIC_COLORS: 
            active_colors.append(CLASSIC_COLORS[lbl])
        elif "Bistable" in lbl:
            active_colors.append(CLASSIC_BISTABLE[bistable_counter % len(CLASSIC_BISTABLE)])
            bistable_counter += 1
        else: 
            active_colors.append("#000000")
        
    label_to_int = {lbl: idx for idx, lbl in enumerate(unique_labels)}
    zmat = np.zeros(labels.shape, dtype=int)
    for i in range(len(y_vals)):
        for j in range(len(w_vals)): 
            zmat[i, j] = label_to_int[labels[i, j]]

    fig, ax = plt.subplots(figsize=(10, 8))
    X, Y = np.meshgrid(w_vals, y_vals)
    bounds = np.arange(-0.5, len(unique_labels) + 0.5, 1)
    
    for i in range(len(unique_labels)):
        z_mask = np.where(zmat == i, 1, 0)
        if np.any(z_mask): 
            ax.contourf(X, Y, z_mask, levels=[0.5, 1.5], colors=[active_colors[i]], antialiased=True)
            
    ax.contour(X, Y, zmat, levels=bounds, colors='black', linewidths=3.0, antialiased=True) 

    for spine in ax.spines.values(): 
        spine.set_linewidth(1.5) 

    # --- USE DISPLAY_LABELS HERE ---
    legend_patches = [
        mpatches.Patch(
            facecolor=active_colors[i], 
            edgecolor="black", 
            linewidth=1.5, 
            label=DISPLAY_LABELS.get(unique_labels[i], unique_labels[i])
        ) 
        for i in range(len(unique_labels))
    ]
    
    legend = ax.legend(handles=legend_patches, loc='best', title="Final Outcome", prop={'size': LEGEND_SIZE, 'weight': FONT_WEIGHT}, frameon=True, facecolor='white', framealpha=0.95, edgecolor='black')
    plt.setp(legend.get_title(), fontsize=LEGEND_SIZE, weight=FONT_WEIGHT)
    legend.set_draggable(True)

    if title:
        ax.set_title(title, fontsize=TITLE_SIZE, fontweight=FONT_WEIGHT, pad=15)

    ax.set_xlabel(xlabel, fontsize=LABEL_SIZE, fontweight=FONT_WEIGHT, labelpad=12)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE, fontweight=FONT_WEIGHT, labelpad=12)
    
    ax.tick_params(axis='both', which='major', labelsize=TICK_SIZE, direction=TICK_DIRECTION, bottom=True, top=True, left=True, right=True, length=TICK_LENGTH, width=TICK_WIDTH)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight(FONT_WEIGHT)

    if SHOW_GRID:
        ax.grid(True, linestyle='--', alpha=GRID_ALPHA, color='black', zorder=3)

    # --- ADD z0 ANNOTATION INSIDE PLOT (CENTERED & LARGER) ---
    z0_val = basin_result.get("z0_fixed", None) 
    if z0_val is not None:
        # Anchored to the exact center (x=0.5, y=0.5 in axis coordinates)
        ax.text(0.5, 0.5, f"$\\mathbf{{z_0 = {z0_val}}}$", 
                transform=ax.transAxes, 
                fontsize=32, 
                fontweight='bold',
                va='center', ha='center',
                bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.9, edgecolor='black', linewidth=2.0),
                zorder=5)

    plt.tight_layout()
    
    if save_name:
        plt.savefig(save_name, dpi=600, bbox_inches='tight', format='png')
        print(f"Saved high-resolution plot to {save_name}")

    plt.show()

# ============================================================
# 3. MAIN EXECUTION 
# ============================================================

def main():
    base_params = Parameters() 
    switches = ModelSwitches()

    t_span = (0.0, 1)
    t_eval = np.linspace(t_span[0], t_span[1], 500)

    initial_conditions = [
        [0.2, 0.7, 0.1]
    ]

    # --- RUN 2D ROBUST ANALYSIS FOR THE SERVICE-EQUIVALENCY FACTOR ---
    # rho_E = 1.0 means one electric bus provides diesel-equivalent service.
    # rho_E > 1.0 captures extra EPB requirements due to range, charging downtime,
    # or spare-ratio needs. A practical range is often close to 1.0--1.2.
    print("Starting 2D Robust Analysis for rho_E.")
    x_param = 'rho_E'
    y_param = 'C_E'
    x_vals = np.linspace(1.0, 4, 10)
    y_vals = np.linspace(4, 40, 10)

    robust_results = classify_with_multiple_initial_conditions(
        base_params=base_params, param_x=x_param, x_values=x_vals,
        param_y=y_param, y_values=y_vals, initial_conditions=initial_conditions,
        t_span=t_span, t_eval=t_eval, switches=switches
    )

    plot_clean_regional_map(
        sensitivity_result=robust_results,
        title="",  
        xlabel=r"Electric Service-Equivalency Factor ($\rho_E$)",
        ylabel=r"Electric Operating Cost ($C_E$)",
        style="smooth",
        save_name="Robust_Map_rhoE_CE_HighRes.png" 
    )

    # # --- RUN BASIN OF ATTRACTION ---
    # print("Starting Basin of Attraction Analysis...")
    # resolution = 30
    # z0_fixed = 0.2
    # w_range = (0.01, 0.99)
    # y_range = (0.01, 0.99)

    # basin_results = classify_basin_of_attraction(
    #     p=base_params, w_range=w_range, y_range=y_range,
    #     z0_fixed=z0_fixed, resolution=resolution,
    #     t_span=t_span, t_eval=t_eval, switches=switches
    # )

    # plot_basin_of_attraction(
    #     basin_result=basin_results,
    #     title="", 
    #     xlabel=r"Initial Strategic Weight of Electric ($w_0$)",
    #     ylabel=r"Initial Strategic Weight of Policy ($y_0$)",
    #     save_name="Basin_of_Attraction_HighRes.png" 
    #  )

if __name__ == "__main__":
    main()