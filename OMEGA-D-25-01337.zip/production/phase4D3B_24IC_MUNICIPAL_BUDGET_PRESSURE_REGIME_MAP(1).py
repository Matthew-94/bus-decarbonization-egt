# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1C
# ANALYTICAL BIFURCATION AUDIT FOR OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE
#
# WHY THIS STEP IS NEEDED
# -----------------------
# The 24-IC maps in Phase 4D-1B revealed broad path-dependent regions.
# Because the audited infrastructure burden depends on the technology's own
# service share, the extension creates positive frequency dependence at low
# penetration:
#
#   Omega_i(x_i) is high when x_i is rare,
#   falls with deployment,
#   and rises mildly again at high penetration.
#
# Under the frozen policy block, Delta_H, Delta_E, Delta_D > 0 in S1-S3,
# therefore y -> 1 for all interior policy starts.
#
# Diesel is also strictly dominated by the non-focal clean competitor at y=1
# in all three scenarios. Hence the long-run extension reduces to an H-E edge
# problem with one state-dependent focal payoff:
#
#   g(x) = M(rho) - F_inf s(x)
#
# where
#
#   s(x) = exp(-4x) + 0.10 x + 0.50 max(0,x-0.70)^2.
#
# This script classifies the exact attractor structure analytically and
# separates:
#
#   1. unique focal-technology attraction,
#   2. pure H-E bistability,
#   3. pure-competitor + stable mixed H/E coexistence,
#   4. unique competitor attraction,
#   5. critical bifurcation boundaries.
#
# No ODE grid is needed. All outputs are saved to CSV.
# =============================================================================

from scipy.optimize import minimize_scalar, brentq
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================

# =============================================================================
# PHASE 4D-2A
# BOUNDED PASSENGER-UTILIZATION SPECIFICATION
# CALIBRATION + ANALYTICAL REGIME AUDIT
#
# PURPOSE
# -------
# Test whether replacing the baseline linear passenger-utilization equation
#
#   q_i = alpha_0 + gamma_1 U_i - gamma_2 U_O
#
# with the bounded outside-option Logit form
#
#   q_i^L = qbar / [1 + exp(-beta (U_i-U_O))]
#
# changes the strategic transition regimes.
#
# IMPORTANT
# ---------
# 1. Passengers still do NOT choose propulsion technologies directly.
#    q_i is utilization of transit service under configuration i relative to
#    the outside option.
#
# 2. The benchmark Logit calibration matches diesel utilization exactly:
#
#       U_D = 0, U_O = 1, q_D = 1.20.
#
#    Choosing qbar = 3 gives
#
#       beta_match = ln(1.5) ≈ 0.405465.
#
# 3. During the beta sensitivity sweep, qbar(beta) is re-anchored so that
#    q_D remains exactly 1.20 boardings/RVK. This isolates the SHAPE /
#    responsiveness of the bounded utilization function instead of changing
#    the overall transit-utilization scale at the same time.
#
# 4. The linear-demand consumer-surplus formula is NOT reused under Logit.
#    It is not required for the replicator dynamics because the PA update uses
#    only the incremental policy payoff Delta_i.
#
# ALL tables and sensitivity results are saved to CSV.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-2B
# 24-INITIAL-CONDITION CERTIFICATION OF BOUNDED PASSENGER UTILIZATION
#
# PURPOSE
# -------
# Numerically certify that the bounded outside-option Logit utilization model
# preserves the strategic transition regimes across:
#
#   beta = 0.15             (low sensitivity)
#   beta = ln(1.5)          (matched benchmark)
#   beta = 1.20             (high sensitivity)
#
# For every beta and scenario, qbar(beta) is chosen so that diesel utilization
# remains exactly q_D = 1.20 boardings/RVK. This isolates the curvature /
# responsiveness of the passenger-utilization specification.
#
# Each case is tested from 24 widely separated initial conditions.
#
# ALL trajectories and summaries are saved to CSV independently of figures.
# =============================================================================

from scipy.integrate import solve_ivp


# =============================================================================

# =============================================================================
# PHASE 4D-3A
# MUNICIPAL BUDGET-PRESSURE EXTENSION
# DIMENSIONAL + THRESHOLD CALIBRATION AUDIT
#
# PURPOSE
# -------
# Rebuild the fiscal-threshold robustness extension on the revised CAD/RVK
# payoff basis before running trajectories.
#
# Gross expected clean-technology subsidy exposure per delivered RVK:
#
#   B(z,w) = z S_H q_H + w S_E q_E
#
# Units: CAD/RVK.
#
# If total annual scheduled service is Q RVK/year, then annual subsidy exposure
# is simply Q * B(z,w), and the annual fiscal threshold is Q * B_bar.
# Therefore the dynamics can be analyzed cleanly in CAD/RVK without choosing
# an arbitrary numerical Q at this stage.
#
# IMPORTANT:
# Diesel environmental charges are NOT subtracted from B(z,w), because this
# extension measures GROSS subsidy-budget exposure. The core model already
# accounts for the fiscal effect of support/charges through lambda_F.
#
# DIMENSIONALLY NORMALIZED SOFT THRESHOLD:
#
#                    max(0, B - B_bar)^2
#   Psi_B = kappa_B -----------------------
#                           B_bar
#
# where:
#   B_bar   : fiscal tolerance threshold, CAD/RVK
#   kappa_B : dimensionless severity parameter
#   Psi_B   : CAD/RVK
#
# Revised PA dynamic:
#
#   y_dot = eta_PA y(1-y) [P(z,w) - Psi_B(z,w)]
#
# where:
#   P(z,w) = z Delta_H + w Delta_E + (1-z-w) Delta_D.
#
# This script DOES NOT yet run the full model. It calculates exact activation
# and policy-persistence thresholds so the final sensitivity domain is chosen
# from the model rather than guessed.
#
# ALL numerical outputs are saved to CSV.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-3B
# 24-INITIAL-CONDITION MUNICIPAL BUDGET-PRESSURE REGIME MAP
#
# PURPOSE
# -------
# Map how the nonlinear municipal fiscal threshold changes:
#
#   - policy persistence,
#   - technology selection,
#   - and the possibility of persistent/nonstationary transition dynamics.
#
# Fiscal burden:
#
#   B(z,w) = z S_H q_H + w S_E q_E
#
# Soft fiscal penalty:
#
#                      max(0, B-Bbar)^2
#   Psi_B = kappa_B * -------------------
#                            Bbar
#
# Revised PA update:
#
#   y_dot = eta_PA y(1-y) [P(z,w) - Psi_B(z,w)]
#
# The operator payoffs are unchanged directly; budget pressure acts through
# the endogenous policy weight y.
#
# COMMON sensitivity domain for all three scenarios:
#
#   Bbar    in [0.05, 0.70] CAD/RVK
#   kappa_B in [0.00, 2.00]
#
# At every grid point, the model is tested from the same 24 widely separated
# initial conditions used in the other final robustness analyses.
#
# ALL grid-level and IC-level results are saved to CSV independently of plots.
# =============================================================================

from scipy.integrate import solve_ivp
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

OUT_DIR = Path("Phase4D3B_budget_pressure_24IC_regime_maps")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CSV_DIR = OUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

DETAIL_DIR = CSV_DIR / "grid_IC_level_results"
DETAIL_DIR.mkdir(parents=True, exist_ok=True)

CONSENSUS_DIR = CSV_DIR / "grid_consensus_results"
CONSENSUS_DIR.mkdir(parents=True, exist_ok=True)

MATRIX_DIR = CSV_DIR / "plotting_matrices"
MATRIX_DIR.mkdir(parents=True, exist_ok=True)

TRAJ_DIR = CSV_DIR / "representative_trajectories"
TRAJ_DIR.mkdir(parents=True, exist_ok=True)

FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION FIGURE STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.3,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. 24 STRUCTURED INITIAL CONDITIONS
# =============================================================================

TECH_COMPOSITIONS = [
    ("D-heavy, slight E tilt",   0.05, 0.10),
    ("D-heavy, slight H tilt",   0.10, 0.05),
    ("E-heavy",                  0.05, 0.75),
    ("H-heavy",                  0.75, 0.05),
    ("E-leaning mixed",          0.20, 0.55),
    ("H-leaning mixed",          0.55, 0.20),
    ("Three-way balanced",       0.30, 0.30),
    ("Green-heavy H/E balanced", 0.45, 0.45),
]

POLICY_START_LEVELS = [
    ("Low policy",    0.10),
    ("Medium policy", 0.50),
    ("High policy",   0.90),
]

IC_ROWS = []
IC_ARRAY_ROWS = []

counter = 1

for comp_label, z0, w0 in TECH_COMPOSITIONS:

    D0 = 1.0 - z0 - w0

    for policy_label, y0 in POLICY_START_LEVELS:

        name = f"IC{counter:02d}"

        IC_ROWS.append({
            "IC": name,
            "Composition_group": comp_label,
            "Policy_group": policy_label,
            "z0_H": z0,
            "w0_E": w0,
            "D0": D0,
            "y0": y0,
        })

        IC_ARRAY_ROWS.append(
            [z0, w0, y0]
        )

        counter += 1

IC_DF = pd.DataFrame(IC_ROWS)
IC_ARRAY = np.asarray(IC_ARRAY_ROWS, dtype=float)
IC_NAMES = list(IC_DF["IC"])
N_IC = len(IC_NAMES)

assert N_IC == 24

IC_DF.to_csv(
    CSV_DIR / "initial_conditions_24.csv",
    index=False,
)


# =============================================================================
# 15. FISCAL FUNCTIONS
# =============================================================================

def gross_subsidy_burden(
    z,
    w,
    p,
    d,
):
    """
    Gross clean-technology subsidy exposure in CAD/RVK.
    Works with scalars or NumPy arrays.
    """
    return (
        z * p.S_H * d["q_H"]
        + w * p.S_E * d["q_E"]
    )


def fiscal_penalty(
    z,
    w,
    p,
    d,
    B_bar,
    kappa_B,
):
    """
    Psi_B = kappa_B * max(0,B-B_bar)^2 / B_bar
    Units: CAD/RVK.
    """
    if B_bar <= 0.0:
        raise ValueError("B_bar must be strictly positive.")

    B = gross_subsidy_burden(
        z=z,
        w=w,
        p=p,
        d=d,
    )

    excess = np.maximum(
        0.0,
        B - B_bar,
    )

    return (
        kappa_B
        * excess**2
        / B_bar
    )


# =============================================================================
# 16. BUDGET-PRESSURE REPLICATOR DYNAMICS
# =============================================================================

def batch_rhs_budget(
    tau,
    flat_state,
    p,
    B_bar,
    kappa_B,
    n_ic,
):

    X = np.asarray(
        flat_state,
        dtype=float,
    ).reshape(
        n_ic,
        3,
    )

    z = X[:, 0]
    w = X[:, 1]
    y = X[:, 2]

    D = 1.0 - z - w

    d = derived_quantities(
        p
    )

    Pi_H = (
        d["pi_H_B"]
        + y * p.S_H * d["q_H"]
    )

    Pi_E = (
        d["pi_E_B"]
        + y * p.S_E * d["q_E"]
    )

    Pi_D = (
        d["pi_D_B"]
        - y * p.T_D * d["q_D"]
    )

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + D * Pi_D
    )

    P_core = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    Psi = fiscal_penalty(
        z=z,
        w=w,
        p=p,
        d=d,
        B_bar=B_bar,
        kappa_B=kappa_B,
    )

    P_budget = (
        P_core
        - Psi
    )

    dz = (
        p.eta_TO
        * z
        * (Pi_H - Pi_bar)
    )

    dw = (
        p.eta_TO
        * w
        * (Pi_E - Pi_bar)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P_budget
    )

    return np.column_stack(
        [dz, dw, dy]
    ).reshape(-1)


# =============================================================================
# 17. SENSITIVITY DOMAIN
# =============================================================================

GRID_N = 31

B_BAR_VALUES = np.linspace(
    0.05,
    0.70,
    GRID_N,
)

KAPPA_VALUES = np.linspace(
    0.0,
    2.00,
    GRID_N,
)


# =============================================================================
# 18. NUMERICAL SETTINGS
# =============================================================================

ADAPTIVE_HORIZONS = [
    300.0,
    900.0,
    2000.0,
    4000.0,
]

SHARE_TOL = 0.995
POLICY_TOL = 0.995

RHS_STATIONARITY_TOL = 1e-7
SIMPLEX_CLEANUP_TOL = 1e-4


# =============================================================================
# 19. STATE SANITIZATION
# =============================================================================

def sanitize_state(
    state,
):

    z, w, y = map(
        float,
        state,
    )

    if (
        z < -SIMPLEX_CLEANUP_TOL
        or w < -SIMPLEX_CLEANUP_TOL
        or z + w > 1.0 + SIMPLEX_CLEANUP_TOL
    ):
        raise RuntimeError(
            "Material simplex violation: "
            f"z={z:.12f}, "
            f"w={w:.12f}, "
            f"z+w={z+w:.12f}"
        )

    z = max(
        0.0,
        z,
    )

    w = max(
        0.0,
        w,
    )

    if z + w > 1.0:

        total = (
            z + w
        )

        z /= total
        w /= total

    D = max(
        0.0,
        1.0 - z - w,
    )

    y = float(
        np.clip(
            y,
            0.0,
            1.0,
        )
    )

    return (
        z,
        w,
        D,
        y,
    )


# =============================================================================
# 20. SINGLE-STATE RHS NORM
# =============================================================================

def single_rhs_norm(
    z,
    w,
    y,
    p,
    B_bar,
    kappa_B,
):

    rhs = batch_rhs_budget(
        tau=0.0,
        flat_state=np.array(
            [z, w, y],
            dtype=float,
        ),
        p=p,
        B_bar=B_bar,
        kappa_B=kappa_B,
        n_ic=1,
    )

    return float(
        np.max(
            np.abs(
                rhs
            )
        )
    )


# =============================================================================
# 21. ENDPOINT CLASSIFICATION
# =============================================================================

def classify_endpoint(
    state,
    p,
    B_bar,
    kappa_B,
):

    z, w, D, y = sanitize_state(
        state
    )

    rhs_norm = single_rhs_norm(
        z=z,
        w=w,
        y=y,
        p=p,
        B_bar=B_bar,
        kappa_B=kappa_B,
    )

    # Pure technology + pure policy corners.
    if (
        z >= SHARE_TOL
        and y >= POLICY_TOL
        and rhs_norm <= 1e-5
    ):
        label = "H_A"

    elif (
        z >= SHARE_TOL
        and y <= 1.0 - POLICY_TOL
        and rhs_norm <= 1e-5
    ):
        label = "H_B"

    elif (
        w >= SHARE_TOL
        and y >= POLICY_TOL
        and rhs_norm <= 1e-5
    ):
        label = "E_A"

    elif (
        w >= SHARE_TOL
        and y <= 1.0 - POLICY_TOL
        and rhs_norm <= 1e-5
    ):
        label = "E_B"

    elif (
        D >= SHARE_TOL
        and y >= POLICY_TOL
        and rhs_norm <= 1e-5
    ):
        label = "D_A"

    elif (
        D >= SHARE_TOL
        and y <= 1.0 - POLICY_TOL
        and rhs_norm <= 1e-5
    ):
        label = "D_B"

    elif rhs_norm <= RHS_STATIONARITY_TOL:
        label = "Stationary mixed"

    else:
        label = "Nonstationary/slow"

    d = derived_quantities(
        p
    )

    B = float(
        gross_subsidy_burden(
            z=z,
            w=w,
            p=p,
            d=d,
        )
    )

    Psi = float(
        fiscal_penalty(
            z=z,
            w=w,
            p=p,
            d=d,
            B_bar=B_bar,
            kappa_B=kappa_B,
        )
    )

    P_core = float(
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    return {
        "Final_H": z,
        "Final_E": w,
        "Final_D": D,
        "Final_y": y,

        "Final_gross_subsidy_burden": B,
        "Final_fiscal_penalty": Psi,
        "Final_core_PA_increment": P_core,
        "Final_budget_adjusted_PA_increment": (
            P_core - Psi
        ),

        "RHS_norm": rhs_norm,
        "Endpoint_class": label,
    }


# =============================================================================
# 22. ADAPTIVE 24-IC SOLVER
# =============================================================================

def solve_24IC_adaptive(
    p,
    B_bar,
    kappa_B,
):

    X_current = np.array(
        IC_ARRAY,
        dtype=float,
        copy=True,
    )

    current_tau = 0.0
    effective_tau = ADAPTIVE_HORIZONS[-1]
    endpoint_results = None

    for target_tau in ADAPTIVE_HORIZONS:

        sol = solve_ivp(
            fun=lambda tau, flat_state: batch_rhs_budget(
                tau=tau,
                flat_state=flat_state,
                p=p,
                B_bar=B_bar,
                kappa_B=kappa_B,
                n_ic=N_IC,
            ),
            t_span=(
                current_tau,
                target_tau,
            ),
            y0=X_current.reshape(-1),
            t_eval=[
                target_tau
            ],
            method="DOP853",
            rtol=1e-9,
            atol=1e-11,
        )

        if not sol.success:
            raise RuntimeError(
                sol.message
            )

        X_current = (
            sol.y[:, -1]
            .reshape(
                N_IC,
                3,
            )
        )

        current_tau = target_tau

        endpoint_results = [
            classify_endpoint(
                state=X_current[i],
                p=p,
                B_bar=B_bar,
                kappa_B=kappa_B,
            )
            for i in range(N_IC)
        ]

        # Stop if every IC is stationary/pure.
        if all(
            result["Endpoint_class"]
            != "Nonstationary/slow"
            for result in endpoint_results
        ):
            effective_tau = target_tau
            break

    return (
        X_current,
        endpoint_results,
        effective_tau,
    )


# =============================================================================
# 23. GRID-POINT CONSENSUS
# =============================================================================

def classify_consensus(
    point_df,
):

    labels = list(
        point_df[
            "Endpoint_class"
        ]
    )

    unique_labels = set(
        labels
    )

    if (
        "Nonstationary/slow"
        in unique_labels
    ):

        consensus = (
            "Persistent/nonstationary"
        )

    elif len(
        unique_labels
    ) == 1:

        only = next(
            iter(
                unique_labels
            )
        )

        if only == "H_A":
            consensus = "Robust H_A"

        elif only == "H_B":
            consensus = "Robust H_B"

        elif only == "E_A":
            consensus = "Robust E_A"

        elif only == "E_B":
            consensus = "Robust E_B"

        elif only == "D_A":
            consensus = "Robust D_A"

        elif only == "D_B":
            consensus = "Robust D_B"

        elif only == "Stationary mixed":

            state_matrix = point_df[
                [
                    "Final_H",
                    "Final_E",
                    "Final_D",
                    "Final_y",
                ]
            ].to_numpy(
                dtype=float
            )

            spread = float(
                np.max(
                    np.ptp(
                        state_matrix,
                        axis=0,
                    )
                )
            )

            if spread <= 1e-3:
                consensus = "Robust stationary mixed"
            else:
                consensus = "Path-dependent"

        else:
            consensus = "Path-dependent"

    else:
        consensus = "Path-dependent"

    return {
        "Consensus": consensus,

        "Mean_final_H": float(
            point_df["Final_H"].mean()
        ),

        "Mean_final_E": float(
            point_df["Final_E"].mean()
        ),

        "Mean_final_D": float(
            point_df["Final_D"].mean()
        ),

        "Mean_final_y": float(
            point_df["Final_y"].mean()
        ),

        "Mean_final_budget_burden": float(
            point_df[
                "Final_gross_subsidy_burden"
            ].mean()
        ),

        "Mean_final_fiscal_penalty": float(
            point_df[
                "Final_fiscal_penalty"
            ].mean()
        ),

        "Max_RHS_norm": float(
            point_df["RHS_norm"].max()
        ),

        "N_H_A": int(
            np.sum(
                point_df["Endpoint_class"]
                == "H_A"
            )
        ),

        "N_E_A": int(
            np.sum(
                point_df["Endpoint_class"]
                == "E_A"
            )
        ),

        "N_E_B": int(
            np.sum(
                point_df["Endpoint_class"]
                == "E_B"
            )
        ),

        "N_stationary_mixed": int(
            np.sum(
                point_df["Endpoint_class"]
                == "Stationary mixed"
            )
        ),

        "N_nonstationary": int(
            np.sum(
                point_df["Endpoint_class"]
                == "Nonstationary/slow"
            )
        ),
    }


# =============================================================================
# 24. MAP CODEBOOK
# =============================================================================

CLASS_ORDER = [
    "Robust H_A",
    "Robust E_A",
    "Robust E_B",
    "Robust H_B",
    "Robust D_A",
    "Robust D_B",
    "Robust stationary mixed",
    "Path-dependent",
    "Persistent/nonstationary",
]

CLASS_TO_CODE = {
    label: i
    for i, label in enumerate(
        CLASS_ORDER
    )
}

CODE_TO_CLASS = {
    code: label
    for label, code in CLASS_TO_CODE.items()
}

CLASS_COLORS = {
    "Robust H_A": "#566B5C",
    "Robust E_A": "#6F8FA6",
    "Robust E_B": "#A9A9A9",
    "Robust H_B": "#7D6A58",
    "Robust D_A": "#C0C0C0",
    "Robust D_B": "#8E8E8E",
    "Robust stationary mixed": "#D4C7B5",
    "Path-dependent": "#B58A7B",
    "Persistent/nonstationary": "#EFEDE8",
}

pd.DataFrame(
    [
        {
            "Code": CLASS_TO_CODE[label],
            "Class": label,
            "Color": CLASS_COLORS[label],
        }
        for label in CLASS_ORDER
    ]
).to_csv(
    CSV_DIR / "outcome_codebook.csv",
    index=False,
)


# =============================================================================
# 25. EXACT PURE-POLICY PERSISTENCE CURVES
# =============================================================================

def kappa_star_curve(
    p,
    technology,
    B_values,
):

    d = derived_quantities(
        p
    )

    if technology == "H":

        b_i = (
            p.S_H
            * d["q_H"]
        )

        Delta_i = d["Delta_H"]

    elif technology == "E":

        b_i = (
            p.S_E
            * d["q_E"]
        )

        Delta_i = d["Delta_E"]

    else:

        raise ValueError(
            "technology must be H or E"
        )

    out = []

    for B_bar in B_values:

        if B_bar >= b_i:

            out.append(
                np.nan
            )

        else:

            out.append(
                Delta_i
                * B_bar
                / (
                    b_i - B_bar
                )**2
            )

    return np.asarray(
        out,
        dtype=float,
    )


# =============================================================================
# 26. RUN ONE SCENARIO MAP
# =============================================================================

def run_scenario_map(
    scenario_name,
):

    p = make_scenario(
        scenario_name
    )

    detail_rows = []
    consensus_rows = []

    matrix = np.full(
        (
            len(KAPPA_VALUES),
            len(B_BAR_VALUES),
        ),
        CLASS_TO_CODE[
            "Persistent/nonstationary"
        ],
        dtype=int,
    )

    total_points = (
        len(KAPPA_VALUES)
        * len(B_BAR_VALUES)
    )

    print(
        f"\nRunning {scenario_name}: "
        f"{len(B_BAR_VALUES)} x "
        f"{len(KAPPA_VALUES)} "
        f"= {total_points} grid points, "
        f"{N_IC} ICs per point"
    )

    for iy, kappa_B in enumerate(
        KAPPA_VALUES
    ):

        for ix, B_bar in enumerate(
            B_BAR_VALUES
        ):

            (
                X_final,
                results,
                effective_tau,
            ) = solve_24IC_adaptive(
                p=p,
                B_bar=float(B_bar),
                kappa_B=float(kappa_B),
            )

            point_rows = []

            for i, ic_name in enumerate(
                IC_NAMES
            ):

                meta = IC_DF[
                    IC_DF["IC"]
                    == ic_name
                ].iloc[0]

                row = {
                    "Scenario": scenario_name,
                    "Grid_ix": ix,
                    "Grid_iy": iy,

                    "B_bar_CAD_per_RVK": float(
                        B_bar
                    ),

                    "kappa_B": float(
                        kappa_B
                    ),

                    "IC": ic_name,

                    "z0_H": meta["z0_H"],
                    "w0_E": meta["w0_E"],
                    "D0": meta["D0"],
                    "y0": meta["y0"],

                    "Effective_tau": effective_tau,

                    **results[i],
                }

                detail_rows.append(
                    row
                )

                point_rows.append(
                    row
                )

            point_df = pd.DataFrame(
                point_rows
            )

            consensus = classify_consensus(
                point_df
            )

            consensus_row = {
                "Scenario": scenario_name,
                "Grid_ix": ix,
                "Grid_iy": iy,

                "B_bar_CAD_per_RVK": float(
                    B_bar
                ),

                "kappa_B": float(
                    kappa_B
                ),

                "Effective_tau": effective_tau,

                **consensus,
            }

            consensus_rows.append(
                consensus_row
            )

            matrix[
                iy,
                ix,
            ] = CLASS_TO_CODE[
                consensus[
                    "Consensus"
                ]
            ]

        print(
            f"  completed kappa row "
            f"{iy + 1}/"
            f"{len(KAPPA_VALUES)}"
        )

    return (
        pd.DataFrame(
            detail_rows
        ),
        pd.DataFrame(
            consensus_rows
        ),
        matrix,
    )


# =============================================================================
# 27. CLEAN MAP PLOT
# =============================================================================

SCENARIO_TITLES = {
    "S1": "Baseline conditions",
    "S2": "Intermediate conditions",
    "S3": "Advanced conditions",
}


def plot_scenario_map(
    scenario_name,
    consensus_df,
    matrix,
):

    p = make_scenario(
        scenario_name
    )

    colors = [
        CLASS_COLORS[
            label
        ]
        for label in CLASS_ORDER
    ]

    cmap = ListedColormap(
        colors
    )

    bounds = np.arange(
        -0.5,
        len(CLASS_ORDER) + 0.5,
        1.0,
    )

    norm = BoundaryNorm(
        bounds,
        cmap.N,
    )

    fig, ax = plt.subplots(
        figsize=(
            6.9,
            5.6,
        )
    )

    ax.pcolormesh(
        B_BAR_VALUES,
        KAPPA_VALUES,
        matrix,
        cmap=cmap,
        norm=norm,
        shading="nearest",
        edgecolors="none",
        antialiased=False,
    )

    # Exact policy-persistence thresholds at pure H and pure E.
    kH = kappa_star_curve(
        p=p,
        technology="H",
        B_values=B_BAR_VALUES,
    )

    kE = kappa_star_curve(
        p=p,
        technology="E",
        B_values=B_BAR_VALUES,
    )

    valid_H = (
        np.isfinite(kH)
        & (kH >= KAPPA_VALUES.min())
        & (kH <= KAPPA_VALUES.max())
    )

    valid_E = (
        np.isfinite(kE)
        & (kE >= KAPPA_VALUES.min())
        & (kE <= KAPPA_VALUES.max())
    )

    if np.any(
        valid_H
    ):

        ax.plot(
            B_BAR_VALUES[
                valid_H
            ],
            kH[
                valid_H
            ],
            linestyle="-",
            linewidth=1.2,
            color="#222222",
            label=r"H policy-persistence boundary",
        )

    if np.any(
        valid_E
    ):

        ax.plot(
            B_BAR_VALUES[
                valid_E
            ],
            kE[
                valid_E
            ],
            linestyle="--",
            linewidth=1.2,
            color="#222222",
            label=r"E policy-persistence boundary",
        )

    # Core benchmark is kappa=0. Bbar is irrelevant there.
    ax.annotate(
        "Core model",
        xy=(
            0.58,
            0.0,
        ),
        xytext=(
            0,
            8,
        ),
        textcoords="offset points",
        fontsize=8.6,
        ha="center",
        va="bottom",
    )

    ax.set_xlabel(
        r"Fiscal tolerance threshold, $\bar B$ (CAD/RVK)"
    )

    ax.set_ylabel(
        r"Fiscal-severity parameter, $\kappa_B$"
    )

    ax.set_title(
        SCENARIO_TITLES[
            scenario_name
        ]
        + "\nMunicipal budget pressure and policy persistence",
        fontweight="semibold",
        pad=8,
    )

    ax.set_xlim(
        B_BAR_VALUES.min(),
        B_BAR_VALUES.max(),
    )

    ax.set_ylim(
        KAPPA_VALUES.min(),
        KAPPA_VALUES.max(),
    )

    ax.grid(
        False
    )

    present_codes = sorted(
        int(v)
        for v in np.unique(
            matrix
        )
    )

    handles = [
        Patch(
            facecolor=CLASS_COLORS[
                CODE_TO_CLASS[
                    code
                ]
            ],
            edgecolor="black",
            linewidth=0.45,
            label=CODE_TO_CLASS[
                code
            ],
        )
        for code in present_codes
    ]

    if np.any(
        valid_H
    ):

        handles.append(
            Line2D(
                [0],
                [0],
                color="#222222",
                linestyle="-",
                linewidth=1.2,
                label="H policy-persistence boundary",
            )
        )

    if np.any(
        valid_E
    ):

        handles.append(
            Line2D(
                [0],
                [0],
                color="#222222",
                linestyle="--",
                linewidth=1.2,
                label="E policy-persistence boundary",
            )
        )

    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(
            0.5,
            -0.15,
        ),
        ncol=2,
        frameon=False,
        fontsize=8.1,
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR
        / f"{scenario_name}_budget_pressure_regime_map.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )

    fig.savefig(
        FIG_DIR
        / f"{scenario_name}_budget_pressure_regime_map.pdf",
        bbox_inches="tight",
        pad_inches=0.04,
    )

    plt.show()
    plt.close(
        fig
    )


# =============================================================================
# 28. REPRESENTATIVE S3 TRAJECTORIES
#
# These points deliberately span:
#   - strict budget pressure,
#   - intermediate feedback,
#   - lenient budget pressure.
#
# They are diagnostic only; the full map is the primary result.
# =============================================================================

REPRESENTATIVE_S3_POINTS = {
    "Strict": {
        "B_bar": 0.10,
        "kappa_B": 0.50,
    },
    "Intermediate": {
        "B_bar": 0.30,
        "kappa_B": 0.50,
    },
    "Lenient": {
        "B_bar": 0.60,
        "kappa_B": 0.50,
    },
}

TAU_REP = 1200.0
T_EVAL_REP = np.linspace(
    0.0,
    TAU_REP,
    6001,
)


def solve_single_trajectory(
    p,
    initial_state,
    B_bar,
    kappa_B,
):

    sol = solve_ivp(
        fun=lambda tau, state: batch_rhs_budget(
            tau=tau,
            flat_state=state,
            p=p,
            B_bar=B_bar,
            kappa_B=kappa_B,
            n_ic=1,
        ),
        t_span=(
            0.0,
            TAU_REP,
        ),
        y0=np.asarray(
            initial_state,
            dtype=float,
        ),
        t_eval=T_EVAL_REP,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(
            sol.message
        )

    return sol


p_S3 = make_scenario(
    "S3"
)

rep_frames = []

for point_name, point in REPRESENTATIVE_S3_POINTS.items():

    for i, ic_name in enumerate(
        IC_NAMES
    ):

        sol = solve_single_trajectory(
            p=p_S3,
            initial_state=IC_ARRAY[i],
            B_bar=point["B_bar"],
            kappa_B=point["kappa_B"],
        )

        z = sol.y[0]
        w = sol.y[1]
        y = sol.y[2]
        D = 1.0 - z - w

        d = derived_quantities(
            p_S3
        )

        B = gross_subsidy_burden(
            z=z,
            w=w,
            p=p_S3,
            d=d,
        )

        Psi = fiscal_penalty(
            z=z,
            w=w,
            p=p_S3,
            d=d,
            B_bar=point["B_bar"],
            kappa_B=point["kappa_B"],
        )

        P_core = (
            z * d["Delta_H"]
            + w * d["Delta_E"]
            + D * d["Delta_D"]
        )

        frame = pd.DataFrame({
            "Scenario": "S3",
            "Representative_point": point_name,
            "B_bar_CAD_per_RVK": point["B_bar"],
            "kappa_B": point["kappa_B"],
            "IC": ic_name,
            "tau": sol.t,
            "Hydrogen_z": z,
            "Electric_w": w,
            "Diesel_D": D,
            "Policy_y": y,
            "Gross_subsidy_burden": B,
            "Fiscal_penalty": Psi,
            "Core_PA_increment": P_core,
            "Budget_adjusted_PA_increment": (
                P_core - Psi
            ),
        })

        rep_frames.append(
            frame
        )


representative_df = pd.concat(
    rep_frames,
    ignore_index=True,
)

representative_df.to_csv(
    TRAJ_DIR
    / "S3_all_24IC_representative_budget_trajectories.csv",
    index=False,
)

for (
    point_name,
    ic_name,
), sub in representative_df.groupby(
    [
        "Representative_point",
        "IC",
    ]
):

    sub.to_csv(
        TRAJ_DIR
        / f"S3_{point_name}_{ic_name}_trajectory.csv",
        index=False,
    )


# =============================================================================
# 29. RUN ALL THREE MAPS
# =============================================================================

summary_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    (
        detail_df,
        consensus_df,
        matrix,
    ) = run_scenario_map(
        scenario_name
    )

    detail_df.to_csv(
        DETAIL_DIR
        / f"{scenario_name}_budget_pressure_IC_level.csv",
        index=False,
    )

    consensus_df.to_csv(
        CONSENSUS_DIR
        / f"{scenario_name}_budget_pressure_consensus.csv",
        index=False,
    )

    matrix_df = pd.DataFrame(
        matrix,
        index=KAPPA_VALUES,
        columns=B_BAR_VALUES,
    )

    matrix_df.index.name = (
        "kappa_B"
    )

    matrix_df.columns.name = (
        "B_bar_CAD_per_RVK"
    )

    matrix_df.to_csv(
        MATRIX_DIR
        / f"{scenario_name}_budget_pressure_outcome_matrix.csv"
    )

    plot_scenario_map(
        scenario_name=scenario_name,
        consensus_df=consensus_df,
        matrix=matrix,
    )

    counts = (
        consensus_df[
            "Consensus"
        ]
        .value_counts()
        .to_dict()
    )

    row = {
        "Scenario": scenario_name,
        "Grid_points": len(
            consensus_df
        ),
    }

    for label in CLASS_ORDER:

        row[
            label
        ] = int(
            counts.get(
                label,
                0,
            )
        )

    summary_rows.append(
        row
    )


# =============================================================================
# 30. SAVE SUMMARY / CONFIGURATION
# =============================================================================

summary_df = pd.DataFrame(
    summary_rows
)

summary_df.to_csv(
    CSV_DIR
    / "map_level_outcome_summary.csv",
    index=False,
)

run_config_df = pd.DataFrame([{
    "Grid_N": GRID_N,

    "B_bar_min": float(
        B_BAR_VALUES.min()
    ),
    "B_bar_max": float(
        B_BAR_VALUES.max()
    ),

    "kappa_B_min": float(
        KAPPA_VALUES.min()
    ),
    "kappa_B_max": float(
        KAPPA_VALUES.max()
    ),

    "Initial_conditions_per_point": N_IC,

    "Adaptive_horizons": " | ".join(
        str(v)
        for v in ADAPTIVE_HORIZONS
    ),

    "Share_tolerance": SHARE_TOL,
    "Policy_tolerance": POLICY_TOL,
    "RHS_stationarity_tolerance": RHS_STATIONARITY_TOL,

    "Penalty_formula":
        "kappa_B * max(0,B-Bbar)^2 / Bbar",
}])

run_config_df.to_csv(
    CSV_DIR
    / "run_configuration.csv",
    index=False,
)


# =============================================================================
# 31. FINAL PRINT
# =============================================================================

print("=" * 112)
print("PHASE 4D-3B — 24-IC MUNICIPAL BUDGET-PRESSURE MAP COMPLETED")
print("=" * 112)

print(
    f"\nInitial conditions per grid point: "
    f"{N_IC}"
)

print(
    f"Grid resolution: "
    f"{GRID_N} x {GRID_N}"
)

print(
    f"B_bar range: "
    f"{B_BAR_VALUES.min():.2f} "
    f"to {B_BAR_VALUES.max():.2f} CAD/RVK"
)

print(
    f"kappa_B range: "
    f"{KAPPA_VALUES.min():.2f} "
    f"to {KAPPA_VALUES.max():.2f}"
)

print("\nMAP-LEVEL OUTCOME COUNTS")
print("-" * 112)

for _, row in summary_df.iterrows():

    print(
        f"\n{row['Scenario']}"
    )

    for label in CLASS_ORDER:

        count = int(
            row[label]
        )

        if count > 0:

            print(
                f"  {label}: {count}"
            )


print("\nFiles saved under:")
print(
    f"  {OUT_DIR.resolve()}"
)

print("\nCSV RESULTS")
print("  initial_conditions_24.csv")
print("  grid_IC_level_results/*.csv")
print("  grid_consensus_results/*.csv")
print("  plotting_matrices/*.csv")
print("  representative_trajectories/*.csv")
print("  map_level_outcome_summary.csv")
print("  run_configuration.csv")
print("  outcome_codebook.csv")

print("\nPhase 4D-3B completed.")
