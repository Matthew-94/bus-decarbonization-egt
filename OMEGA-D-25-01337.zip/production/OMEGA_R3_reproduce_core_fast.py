"""Fast benchmark replication; run in archive/reproduction directory.
This verifies S1/S2/S3 payoffs, thresholds, and exact VOT recentering equivalence.
"""
from dataclasses import replace
from core_phase4B import make_scenario, derived_quantities, policy_thresholds, pure_stability_report

for s in ("S1", "S2", "S3"):
    p=make_scenario(s)
    d=derived_quantities(p)
    d_rec=derived_quantities(replace(p, lambda_time=10.0, U_0=7.166666666666666))
    keys=("U_H","U_E","U_D","q_H","q_E","q_D","pi_H_B","pi_E_B","pi_D_B","Delta_H","Delta_E","Delta_D")
    assert max(abs(d[k]-d_rec[k]) for k in keys)<1e-10
    thr=policy_thresholds(p)
    stability=pure_stability_report(p)
    print(s, {k:round(d[k],8) for k in ("q_H","q_E","q_D","Delta_H","Delta_E","Delta_D")},
          "y_HE",round(thr["y_HE"],8),"stable",stability)
