"""Targeted zero-share and small-entry check for Reviewer 1, Comment 4.

Requires transit_model_phase4B_1.py (the certified Phase 4B core) in the
same folder. This analysis does not modify any of the production equations.

Start from a pure-technology service allocation at y0=0.20. A one-time
entry seed redistributes epsilon of the existing service across all three
technologies, keeping Q and shares summing to one:
    x0(epsilon) = (1-epsilon)*x_pure + epsilon*(1/3,1/3,1/3).
The initial PA commitment is unchanged. Runs use the certified DOP853
solver and its published tolerances; tau is normalized adjustment time.
"""
from __future__ import annotations
from pathlib import Path
import csv
import sys
import importlib.util
import numpy as np

CORE = Path(__file__).resolve().with_name('transit_model_phase4B_1.py')
if not CORE.is_file():
    raise FileNotFoundError(f'Missing core model next to this script: {CORE}')
spec = importlib.util.spec_from_file_location('omega_certified_core', CORE)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

BASES = {
    'diesel-only': (0.0, 0.0),
    'electric-only': (0.0, 1.0),
    'hydrogen-only': (1.0, 0.0),
}
EPSILONS = (0.0, 1e-3, 1e-5)
PA_INITIAL = 0.20
TAU_END = 600.0
OUT = Path(__file__).resolve().with_name('OMEGA_R3_COMMENT4_seeded_entry_check.csv')
rows = []
for scenario in ('S1','S2','S3'):
    p = mod.make_scenario(scenario)
    for base_name, (z_base,w_base) in BASES.items():
        d_base = 1.0-z_base-w_base
        for eps in EPSILONS:
            z0=(1-eps)*z_base+eps/3.0
            w0=(1-eps)*w_base+eps/3.0
            d0=(1-eps)*d_base+eps/3.0
            assert abs(z0+w0+d0-1.0) < 1e-12
            sol=mod.solve_replicator(p,[z0,w0,PA_INITIAL],tau_span=(0.0,TAU_END),n_points=601)
            zf,wf,yf = map(float,sol.y[:,-1]);df=1.0-zf-wf
            shares={'H':zf,'E':wf,'D':df};winning=max(shares,key=shares.get)
            if shares[winning] < 0.995 or yf < 0.995:
                raise AssertionError(f'Unresolved trajectory: {scenario}, {base_name}, seed {eps}: {shares}, y={yf}')
            rows.append({
                'scenario':scenario, 'pure_initial_state':base_name,'entry_seed_epsilon':eps,
                'z0':z0,'w0':w0,'D0':d0,'y0':PA_INITIAL,
                'z_tau600':zf,'w_tau600':wf,'D_tau600':df,'y_tau600':yf,
                'dominant_end_technology':winning,
                'endpoint_label':f'{winning}_A',
                'tau_final':TAU_END,
                'method':'DOP853','rtol':1e-10,'atol':1e-12,
            })
OUT.parent.mkdir(parents=True,exist_ok=True)
with OUT.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f, fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
for scenario in ('S1','S2','S3'):
    print(scenario, ', '.join(f'{eps}: {sorted(set(r["endpoint_label"] for r in rows if r["scenario"]==scenario and r["entry_seed_epsilon"]==eps))}' for eps in EPSILONS))
print(f'Wrote {len(rows)} runs: {OUT}')
