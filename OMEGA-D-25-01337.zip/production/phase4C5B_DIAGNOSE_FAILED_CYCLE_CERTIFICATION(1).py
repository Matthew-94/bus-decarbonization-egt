# =============================================================================
# PHASE 4C-5B
# DIAGNOSE ANY EDGE-CYCLE START THAT FAILED THE AUTOMATED CERTIFICATION RULE
#
# This script DOES NOT rerun the model.
# It reads the CSV outputs already saved by Phase 4C-5 and determines exactly
# why any edge trajectory failed the original numerical certification flag.
#
# It also saves its own diagnostic CSV, following the project convention.
# =============================================================================

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import find_peaks


# =============================================================================
# 1. PATHS
# =============================================================================

BASE_DIR = Path("Phase4C5_analytical_classification")

CYCLE_DIR = (
    BASE_DIR
    / "csv_results"
    / "cycle_audit"
)

TRAJECTORY_DIR = (
    CYCLE_DIR
    / "individual_trajectories"
)

SUMMARY_FILE = (
    CYCLE_DIR
    / "HE_cycle_certification_summary_24IC.csv"
)

OUTPUT_DIR = (
    BASE_DIR
    / "cycle_failure_diagnostics"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# =============================================================================
# 2. ORIGINAL CERTIFICATION SETTINGS
# =============================================================================

AMP_TOL = 1e-4
INVARIANT_RANGE_TOL = 1e-3
MIN_TAIL_PEAKS = 3


# =============================================================================
# 3. LOAD SUMMARY
# =============================================================================

if not SUMMARY_FILE.exists():
    raise FileNotFoundError(
        f"Cannot find:\n{SUMMARY_FILE.resolve()}"
    )

summary = pd.read_csv(
    SUMMARY_FILE
)

failed = summary[
    ~summary["Cycle_certified"].astype(bool)
].copy()

print("=" * 100)
print("PHASE 4C-5B — FAILED CYCLE-CERTIFICATION DIAGNOSTIC")
print("=" * 100)

print(
    f"\nTotal edge-cycle tests = {len(summary)}"
)

print(
    f"Automatically certified = "
    f"{int(summary['Cycle_certified'].astype(bool).sum())}"
)

print(
    f"Flagged for diagnosis = {len(failed)}"
)


if failed.empty:

    print(
        "\nNo failed cycle certifications were found."
    )

    empty_output = pd.DataFrame(
        columns=[
            "Scenario",
            "Edge_IC",
            "Diagnostic_status",
        ]
    )

    empty_output.to_csv(
        OUTPUT_DIR
        / "cycle_failure_diagnostics.csv",
        index=False,
    )

else:

    diagnostic_rows = []

    for _, failed_row in failed.iterrows():

        scenario = str(
            failed_row["Scenario"]
        )

        edge_ic = str(
            failed_row["Edge_IC"]
        )

        trajectory_file = (
            TRAJECTORY_DIR
            / f"{scenario}_{edge_ic}_HE_cycle_trajectory.csv"
        )

        if not trajectory_file.exists():

            raise FileNotFoundError(
                f"Missing trajectory CSV:\n"
                f"{trajectory_file.resolve()}"
            )

        df = pd.read_csv(
            trajectory_file
        )

        tau = df["tau"].to_numpy(
            dtype=float
        )

        z = df["Hydrogen_z"].to_numpy(
            dtype=float
        )

        y = df["Policy_y"].to_numpy(
            dtype=float
        )

        invariant = df[
            "HE_first_integral"
        ].to_numpy(
            dtype=float
        )

        tau_end = float(
            tau[-1]
        )

        # ---------------------------------------------------------------------
        # Original 50% tail diagnostics
        # ---------------------------------------------------------------------

        tail50 = (
            tau >= 0.50 * tau_end
        )

        z50 = z[tail50]
        y50 = y[tail50]
        tau50 = tau[tail50]

        z_amp_50 = float(
            np.max(z50)
            - np.min(z50)
        )

        y_amp_50 = float(
            np.max(y50)
            - np.min(y50)
        )

        prominence_50 = max(
            1e-5,
            0.05 * z_amp_50,
        )

        peaks50, _ = find_peaks(
            z50,
            prominence=prominence_50,
        )

        peak_times_50 = (
            tau50[peaks50]
        )

        # ---------------------------------------------------------------------
        # 25% tail — useful if the orbit has a long period
        # ---------------------------------------------------------------------

        tail25 = (
            tau >= 0.25 * tau_end
        )

        z25 = z[tail25]
        y25 = y[tail25]
        tau25 = tau[tail25]

        z_amp_25 = float(
            np.max(z25)
            - np.min(z25)
        )

        y_amp_25 = float(
            np.max(y25)
            - np.min(y25)
        )

        prominence_25 = max(
            1e-5,
            0.05 * z_amp_25,
        )

        peaks25, _ = find_peaks(
            z25,
            prominence=prominence_25,
        )

        peak_times_25 = (
            tau25[peaks25]
        )

        # ---------------------------------------------------------------------
        # Full-run peak detection
        # ---------------------------------------------------------------------

        z_amp_full = float(
            np.max(z)
            - np.min(z)
        )

        y_amp_full = float(
            np.max(y)
            - np.min(y)
        )

        prominence_full = max(
            1e-5,
            0.05 * z_amp_full,
        )

        peaks_full, _ = find_peaks(
            z,
            prominence=prominence_full,
        )

        peak_times_full = (
            tau[peaks_full]
        )

        # ---------------------------------------------------------------------
        # Period diagnostics
        # ---------------------------------------------------------------------

        def period_stats(
            peak_times
        ):

            if len(peak_times) >= 2:

                periods = np.diff(
                    peak_times
                )

                mean_period = float(
                    np.mean(periods)
                )

                cv = float(
                    np.std(periods)
                    / np.mean(periods)
                )

                return (
                    mean_period,
                    cv,
                )

            return (
                np.nan,
                np.nan,
            )

        mean_period_50, cv_50 = (
            period_stats(
                peak_times_50
            )
        )

        mean_period_25, cv_25 = (
            period_stats(
                peak_times_25
            )
        )

        mean_period_full, cv_full = (
            period_stats(
                peak_times_full
            )
        )

        # ---------------------------------------------------------------------
        # First-integral drift
        # ---------------------------------------------------------------------

        invariant_range_full = float(
            np.max(invariant)
            - np.min(invariant)
        )

        invariant_range_50 = float(
            np.max(
                invariant[tail50]
            )
            - np.min(
                invariant[tail50]
            )
        )

        invariant_range_25 = float(
            np.max(
                invariant[tail25]
            )
            - np.min(
                invariant[tail25]
            )
        )

        # ---------------------------------------------------------------------
        # Identify exactly which original criterion failed
        # ---------------------------------------------------------------------

        failed_reasons = []

        if z_amp_50 <= AMP_TOL:
            failed_reasons.append(
                "hydrogen amplitude below tolerance"
            )

        if y_amp_50 <= AMP_TOL:
            failed_reasons.append(
                "policy amplitude below tolerance"
            )

        if (
            invariant_range_full
            >= INVARIANT_RANGE_TOL
        ):
            failed_reasons.append(
                "first-integral numerical drift above tolerance"
            )

        if (
            len(peaks50)
            < MIN_TAIL_PEAKS
        ):
            failed_reasons.append(
                "fewer than 3 peaks in second half of run"
            )

        # ---------------------------------------------------------------------
        # Evidence-based diagnostic interpretation
        # ---------------------------------------------------------------------

        if (
            z_amp_full > AMP_TOL
            and y_amp_full > AMP_TOL
            and invariant_range_full
            < INVARIANT_RANGE_TOL
            and len(peaks_full) >= 3
        ):

            interpretation = (
                "Persistent cycle supported; original flag is due "
                "to the tail-window/peak-count heuristic."
            )

        elif (
            z_amp_full > AMP_TOL
            and y_amp_full > AMP_TOL
            and invariant_range_50
            < INVARIANT_RANGE_TOL
            and len(peaks_full) >= 3
        ):

            interpretation = (
                "Persistent cycle strongly suggested, but the full-run "
                "first-integral drift criterion is conservative; rerun this "
                "single orbit with tighter tolerances if desired."
            )

        else:

            interpretation = (
                "Needs targeted longer/tighter rerun before numerical "
                "cycle certification."
            )

        diagnostic_rows.append(
            {
                "Scenario": scenario,
                "Edge_IC": edge_ic,

                "Original_failed_reasons": (
                    " | ".join(
                        failed_reasons
                    )
                ),

                "Hydrogen_amplitude_full": z_amp_full,
                "Policy_amplitude_full": y_amp_full,

                "Hydrogen_amplitude_tail50": z_amp_50,
                "Policy_amplitude_tail50": y_amp_50,

                "Hydrogen_amplitude_tail25": z_amp_25,
                "Policy_amplitude_tail25": y_amp_25,

                "Peaks_full": len(
                    peaks_full
                ),
                "Peaks_tail25": len(
                    peaks25
                ),
                "Peaks_tail50": len(
                    peaks50
                ),

                "Mean_period_full": mean_period_full,
                "Period_CV_full": cv_full,

                "Mean_period_tail25": mean_period_25,
                "Period_CV_tail25": cv_25,

                "Mean_period_tail50": mean_period_50,
                "Period_CV_tail50": cv_50,

                "Invariant_range_full": invariant_range_full,
                "Invariant_range_tail25": invariant_range_25,
                "Invariant_range_tail50": invariant_range_50,

                "Diagnostic_interpretation": interpretation,
            }
        )

        # ---------------------------------------------------------------------
        # Diagnostic figure
        # ---------------------------------------------------------------------

        fig, axes = plt.subplots(
            1,
            2,
            figsize=(10.5, 4.2),
        )

        axes[0].plot(
            tau,
            z,
            linewidth=1.2,
            label="Hydrogen share, z",
        )

        axes[0].plot(
            tau,
            y,
            linewidth=1.2,
            label="Policy weight, y",
        )

        axes[0].set_xlabel(
            r"Normalized evolutionary time, $\tau$"
        )

        axes[0].set_ylabel(
            "State value"
        )

        axes[0].set_title(
            f"{scenario} {edge_ic} — time series"
        )

        axes[0].legend(
            frameon=False
        )

        axes[1].plot(
            z,
            y,
            linewidth=0.9,
        )

        axes[1].set_xlabel(
            r"Hydrogen service share, $z$"
        )

        axes[1].set_ylabel(
            r"Active-policy weight, $y$"
        )

        axes[1].set_title(
            f"{scenario} {edge_ic} — phase portrait"
        )

        for ax in axes:
            ax.grid(False)

        fig.tight_layout()

        fig.savefig(
            OUTPUT_DIR
            / f"{scenario}_{edge_ic}_diagnostic.png",
            dpi=400,
            bbox_inches="tight",
        )

        plt.show()
        plt.close(fig)


    diagnostic_df = pd.DataFrame(
        diagnostic_rows
    )

    diagnostic_df.to_csv(
        OUTPUT_DIR
        / "cycle_failure_diagnostics.csv",
        index=False,
    )

    print("\nFAILED-CASE DIAGNOSTIC RESULTS")
    print("-" * 100)

    for _, row in diagnostic_df.iterrows():

        print(
            f"\n{row['Scenario']} | "
            f"{row['Edge_IC']}"
        )

        print(
            "Original failed reason(s): "
            f"{row['Original_failed_reasons']}"
        )

        print(
            f"Full-run peaks = "
            f"{int(row['Peaks_full'])}"
        )

        print(
            f"50%-tail peaks = "
            f"{int(row['Peaks_tail50'])}"
        )

        print(
            f"Full-run invariant range = "
            f"{row['Invariant_range_full']:.3e}"
        )

        print(
            f"50%-tail invariant range = "
            f"{row['Invariant_range_tail50']:.3e}"
        )

        print(
            "Interpretation: "
            f"{row['Diagnostic_interpretation']}"
        )


print("\nDiagnostic CSV saved to:")
print(
    (
        OUTPUT_DIR
        / "cycle_failure_diagnostics.csv"
    ).resolve()
)
