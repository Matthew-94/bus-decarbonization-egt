# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

PHASE4C5_DIR = Path("Phase4C5_analytical_classification")
PHASE4C5_DIR.mkdir(parents=True, exist_ok=True)

FIGURE_DIR = PHASE4C5_DIR / "figures"
FIGURE_DIR.mkdir(parents=True, exist_ok=True)

CSV_DIR_C5 = PHASE4C5_DIR / "csv_results"
CSV_DIR_C5.mkdir(parents=True, exist_ok=True)

MAP_CSV_DIR = CSV_DIR_C5 / "analytical_maps"
MAP_CSV_DIR.mkdir(parents=True, exist_ok=True)

CYCLE_CSV_DIR = CSV_DIR_C5 / "cycle_audit"
CYCLE_CSV_DIR.mkdir(parents=True, exist_ok=True)

CYCLE_TRAJECTORY_DIR = CYCLE_CSV_DIR / "individual_trajectories"
CYCLE_TRAJECTORY_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. CLEAN PUBLICATION STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.8,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. STRUCTURED 24-POINT FULL-SIMPLEX INITIAL-CONDITION DESIGN
# =============================================================================

TECH_COMPOSITIONS = [
    ("D-heavy, slight E tilt",   0.05, 0.10),
    ("D-heavy, slight H tilt",   0.10, 0.05),
    ("E-heavy",                  0.05, 0.75),
    ("H-heavy",                  0.75, 0.05),
    ("E-leaning mixed",          0.20, 0.55),
    ("H-leaning mixed",          0.55, 0.20),
    ("Three-way balanced",       0.30, 0.30),
    ("Green-heavy H/E balanced", 0.45, 0.45),
]

POLICY_START_LEVELS = [
    ("Low policy",    0.10),
    ("Medium policy", 0.50),
    ("High policy",   0.90),
]

FULL_IC_ROWS = []
FULL_IC_ARRAY_ROWS = []

ic_counter = 1

for composition_label, z0, w0 in TECH_COMPOSITIONS:

    D0 = 1.0 - z0 - w0

    for policy_label, y0 in POLICY_START_LEVELS:

        ic_name = f"IC{ic_counter:02d}"

        FULL_IC_ROWS.append({
            "IC": ic_name,
            "Composition_group": composition_label,
            "Policy_group": policy_label,
            "z0_H": z0,
            "w0_E": w0,
            "D0": D0,
            "y0": y0,
        })

        FULL_IC_ARRAY_ROWS.append(
            [z0, w0, y0]
        )

        ic_counter += 1

FULL_IC_DF = pd.DataFrame(FULL_IC_ROWS)
FULL_IC_ARRAY = np.asarray(FULL_IC_ARRAY_ROWS, dtype=float)
FULL_IC_NAMES = list(FULL_IC_DF["IC"])

FULL_IC_DF.to_csv(
    CSV_DIR_C5 / "initial_conditions_full_simplex_24.csv",
    index=False,
)


# =============================================================================
# 15. ANALYTICAL GRID DEFINITIONS
# =============================================================================

SCENARIOS = ["S1", "S2", "S3"]

# Dense analytical grid: no ODE is solved at these grid points.
# This is therefore much cheaper than the prior 24-IC simulation grid.
ANALYTICAL_GRID_N = 201

MAP_CONFIGS_C5 = {

    "capital_competition": {
        "x_param": "R_H",
        "x_values": np.linspace(400_000.0, 2_500_000.0, ANALYTICAL_GRID_N),
        "y_param": "R_E",
        "y_values": np.linspace(400_000.0, 2_500_000.0, ANALYTICAL_GRID_N),
        "x_label": r"Hydrogen bus acquisition cost, $R_H$ (million CAD/bus)",
        "y_label": r"Electric bus acquisition cost, $R_E$ (million CAD/bus)",
        "x_scale": 1e6,
        "y_scale": 1e6,
        "title_stub": "Capital-cost competition",
    },

    "hydrogen_learning": {
        "x_param": "fuel_H",
        "x_values": np.linspace(1.0, 15.0, ANALYTICAL_GRID_N),
        "y_param": "C_hat_H",
        "y_values": np.linspace(0.40, 2.40, ANALYTICAL_GRID_N),
        "x_label": r"Hydrogen price, $f_H$ (CAD/kg)",
        "y_label": r"Hydrogen non-energy operating cost, $\hat C_H$ (CAD/RVK)",
        "x_scale": 1.0,
        "y_scale": 1.0,
        "title_stub": "Hydrogen operating-learning frontier",
    },

    "policy_support": {
        "x_param": "S_H",
        "x_values": np.linspace(0.0, 2.0, ANALYTICAL_GRID_N),
        "y_param": "S_E",
        "y_values": np.linspace(0.0, 2.0, ANALYTICAL_GRID_N),
        "x_label": r"Hydrogen support intensity, $S_H$ (CAD/boarding)",
        "y_label": r"Electric support intensity, $S_E$ (CAD/boarding)",
        "x_scale": 1.0,
        "y_scale": 1.0,
        "title_stub": "Environmental-policy support frontier",
    },
}


# =============================================================================
# 16. MIXED EQUILIBRIUM CANDIDATES AND LOCAL STRUCTURE
# =============================================================================

ANALYTIC_TOL = 1e-10


def mixed_edge_candidates(p: Parameters) -> Dict[str, Dict[str, float]]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GH1 = d["Gamma_H1"]

    GE0 = d["Gamma_E0"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    result = {}

    # -------------------------------------------------------------------------
    # E7 = HD
    # -------------------------------------------------------------------------

    if abs(DD - DH) > ANALYTIC_TOL and abs(GH1) > ANALYTIC_TOL:

        z = DD / (DD - DH)
        w = 0.0
        y = -GH0 / GH1

        feasible = (
            ANALYTIC_TOL < z < 1.0 - ANALYTIC_TOL
            and ANALYTIC_TOL < y < 1.0 - ANALYTIC_TOL
        )

        K = (
            p.eta_TO
            * p.eta_PA
            * z
            * (1.0 - z)
            * y
            * (1.0 - y)
            * GH1
            * (DH - DD)
        )

        # Characteristic factor:
        # [lambda - eta_TO Gamma_E(y*)] [lambda^2 - K_HD] = 0
        transverse_eig = (
            p.eta_TO
            * (GE0 + y * GE1)
        )

        result["HD"] = {
            "z": z,
            "w": w,
            "y": y,
            "K": K,
            "transverse_eigenvalue": transverse_eig,
            "feasible": feasible,
        }

    # -------------------------------------------------------------------------
    # E8 = ED
    # -------------------------------------------------------------------------

    if abs(DD - DE) > ANALYTIC_TOL and abs(GE1) > ANALYTIC_TOL:

        z = 0.0
        w = DD / (DD - DE)
        y = -GE0 / GE1

        feasible = (
            ANALYTIC_TOL < w < 1.0 - ANALYTIC_TOL
            and ANALYTIC_TOL < y < 1.0 - ANALYTIC_TOL
        )

        K = (
            p.eta_TO
            * p.eta_PA
            * w
            * (1.0 - w)
            * y
            * (1.0 - y)
            * GE1
            * (DE - DD)
        )

        # Characteristic factor:
        # [lambda - eta_TO Gamma_H(y*)] [lambda^2 - K_ED] = 0
        transverse_eig = (
            p.eta_TO
            * (GH0 + y * GH1)
        )

        result["ED"] = {
            "z": z,
            "w": w,
            "y": y,
            "K": K,
            "transverse_eigenvalue": transverse_eig,
            "feasible": feasible,
        }

    # -------------------------------------------------------------------------
    # E9 = HE
    # -------------------------------------------------------------------------

    denom_delta = DE - DH
    denom_gamma = GH1 - GE1

    if (
        abs(denom_delta) > ANALYTIC_TOL
        and abs(denom_gamma) > ANALYTIC_TOL
    ):

        z = DE / denom_delta
        w = -DH / denom_delta
        y = (GE0 - GH0) / denom_gamma

        feasible = (
            ANALYTIC_TOL < z < 1.0 - ANALYTIC_TOL
            and ANALYTIC_TOL < w < 1.0 - ANALYTIC_TOL
            and ANALYTIC_TOL < y < 1.0 - ANALYTIC_TOL
            and abs(z + w - 1.0) <= 1e-8
        )

        K = (
            p.eta_TO
            * p.eta_PA
            * z
            * w
            * y
            * (1.0 - y)
            * (GH1 - GE1)
            * (DH - DE)
        )

        # Characteristic factor:
        # [lambda + eta_TO Gamma_H(y*)] [lambda^2 - K_HE] = 0
        transverse_eig = (
            -p.eta_TO
            * (GH0 + y * GH1)
        )

        result["HE"] = {
            "z": z,
            "w": w,
            "y": y,
            "K": K,
            "transverse_eigenvalue": transverse_eig,
            "feasible": feasible,
        }

    return result


# =============================================================================
# 17. ANALYTICAL REGIME CLASSIFIER
# =============================================================================

def analytical_regime(p: Parameters) -> Dict[str, object]:

    pure = pure_stability_report(p)

    stable_pure = [
        name
        for name, flag in pure.items()
        if flag
    ]

    mixed = mixed_edge_candidates(p)

    d = derived_quantities(p)

    full_interior_residual = (
        d["Gamma_H0"] * d["Gamma_E1"]
        - d["Gamma_E0"] * d["Gamma_H1"]
    )

    # -------------------------------------------------------------------------
    # Strict pure equilibrium
    # -------------------------------------------------------------------------

    if len(stable_pure) == 1:

        eq = stable_pure[0]

        if "H_" in eq:
            broad = "Stable H"

        elif "E_" in eq:
            broad = "Stable E"

        elif "D_" in eq:
            broad = "Stable D"

        else:
            broad = "Stable pure"

        return {
            "Analytical_class": broad,
            "Detailed_class": eq,
            "Stable_pure_count": 1,
            "Stable_pure_equilibria": eq,
            "Full_interior_residual": full_interior_residual,
            "Mixed_candidates": mixed,
        }

    # -------------------------------------------------------------------------
    # Genuine pure-equilibrium multistability
    # -------------------------------------------------------------------------

    if len(stable_pure) > 1:

        return {
            "Analytical_class": "Multiple stable pure equilibria",
            "Detailed_class": " | ".join(stable_pure),
            "Stable_pure_count": len(stable_pure),
            "Stable_pure_equilibria": " | ".join(stable_pure),
            "Full_interior_residual": full_interior_residual,
            "Mixed_candidates": mixed,
        }

    # -------------------------------------------------------------------------
    # Transversely attracting center-type edge candidates
    #
    # K < 0 gives an imaginary pair on the edge.
    # Negative transverse eigenvalue means the absent third technology is
    # locally selected against.
    # -------------------------------------------------------------------------

    center_edges = []

    for edge, info in mixed.items():

        if (
            info["feasible"]
            and info["K"] < -ANALYTIC_TOL
            and info["transverse_eigenvalue"] < -ANALYTIC_TOL
        ):
            center_edges.append(edge)

    if len(center_edges) == 1:

        edge = center_edges[0]

        return {
            "Analytical_class": f"Persistent {edge} cycling",
            "Detailed_class": f"Feasible transversely attracting {edge} center",
            "Stable_pure_count": 0,
            "Stable_pure_equilibria": "",
            "Full_interior_residual": full_interior_residual,
            "Mixed_candidates": mixed,
        }

    if len(center_edges) > 1:

        return {
            "Analytical_class": "Multiple center-type edge regimes",
            "Detailed_class": " | ".join(center_edges),
            "Stable_pure_count": 0,
            "Stable_pure_equilibria": "",
            "Full_interior_residual": full_interior_residual,
            "Mixed_candidates": mixed,
        }

    # -------------------------------------------------------------------------
    # Nongeneric full-interior degeneracy
    # -------------------------------------------------------------------------

    if abs(full_interior_residual) <= ANALYTIC_TOL:

        return {
            "Analytical_class": "Degenerate full-interior condition",
            "Detailed_class": "Gamma_H0 Gamma_E1 = Gamma_E0 Gamma_H1",
            "Stable_pure_count": 0,
            "Stable_pure_equilibria": "",
            "Full_interior_residual": full_interior_residual,
            "Mixed_candidates": mixed,
        }

    # -------------------------------------------------------------------------
    # Remaining exact boundary / non-LAS cases
    # -------------------------------------------------------------------------

    return {
        "Analytical_class": "Boundary / non-LAS case",
        "Detailed_class": "No strict pure LAS equilibrium and no certified attracting edge center",
        "Stable_pure_count": 0,
        "Stable_pure_equilibria": "",
        "Full_interior_residual": full_interior_residual,
        "Mixed_candidates": mixed,
    }


# =============================================================================
# 18. POLICY THRESHOLD SUMMARY
# =============================================================================

threshold_rows = []

for scenario_name in SCENARIOS:

    p = make_scenario(scenario_name)
    d = derived_quantities(p)

    # PA support-sustainability thresholds
    S_H_PA = (
        p.p_CO2 * (d["e_H"] - p.e_target)
        / (p.lambda_F * d["q_H"])
    )

    S_E_PA = (
        p.p_CO2 * (d["e_E"] - p.e_target)
        / (p.lambda_F * d["q_E"])
    )

    # Required H-E support differential at y=1.
    # General expression remains valid if q_H != q_E.
    # For the present benchmark q_H=q_E within each scenario.
    H_E_gap_per_H_boarding = (
        d["pi_E_B"] - d["pi_H_B"]
    ) / d["q_H"]

    threshold_rows.append({
        "Scenario": scenario_name,
        "S_H_PA_threshold": S_H_PA,
        "S_E_PA_threshold": S_E_PA,
        "H_E_private_gap_CAD_per_RVK": (
            d["pi_E_B"] - d["pi_H_B"]
        ),
        "H_E_support_differential_threshold_approx": H_E_gap_per_H_boarding,
        "q_H": d["q_H"],
        "q_E": d["q_E"],
    })

threshold_df = pd.DataFrame(threshold_rows)

threshold_df.to_csv(
    CSV_DIR_C5 / "policy_threshold_summary.csv",
    index=False,
)

print("=" * 110)
print("PHASE 4C-5 — EXACT POLICY THRESHOLDS")
print("=" * 110)

for _, row in threshold_df.iterrows():

    print(f"\n{row['Scenario']}")
    print("-" * 72)

    print(
        "PA hydrogen-support sustainability threshold: "
        f"S_H = {row['S_H_PA_threshold']:.6f} CAD/boarding"
    )

    print(
        "PA electric-support sustainability threshold: "
        f"S_E = {row['S_E_PA_threshold']:.6f} CAD/boarding"
    )

    print(
        "Approximate H-E support differential required at y=1: "
        f"{row['H_E_support_differential_threshold_approx']:.6f} CAD/boarding"
    )


# =============================================================================
# 19. ANALYTICAL MAP CODEBOOK
# =============================================================================

CLASS_ORDER = [
    "Stable D",
    "Stable E",
    "Stable H",
    "Persistent HE cycling",
    "Persistent HD cycling",
    "Persistent ED cycling",
    "Multiple stable pure equilibria",
    "Multiple center-type edge regimes",
    "Degenerate full-interior condition",
    "Boundary / non-LAS case",
]

CLASS_TO_CODE = {
    label: i
    for i, label in enumerate(CLASS_ORDER)
}

CODE_TO_CLASS = {
    code: label
    for label, code in CLASS_TO_CODE.items()
}

CLASS_COLORS = {
    "Stable D": "#A9A9A9",
    "Stable E": "#6F8FA6",
    "Stable H": "#566B5C",
    "Persistent HE cycling": "#D8CFC2",
    "Persistent HD cycling": "#C6B7A7",
    "Persistent ED cycling": "#C8C3B8",
    "Multiple stable pure equilibria": "#B58A7B",
    "Multiple center-type edge regimes": "#C7A68F",
    "Degenerate full-interior condition": "#E4E1DA",
    "Boundary / non-LAS case": "#F4F2ED",
}

pd.DataFrame(
    [
        {
            "Code": CLASS_TO_CODE[label],
            "Class": label,
            "Color": CLASS_COLORS[label],
        }
        for label in CLASS_ORDER
    ]
).to_csv(
    CSV_DIR_C5 / "analytical_outcome_codebook.csv",
    index=False,
)


# =============================================================================
# 20. ANALYTICAL GRID SCAN
# =============================================================================

map_summary_rows = []


def flatten_mixed_fields(mixed: Dict[str, Dict[str, float]]) -> Dict[str, object]:

    out = {}

    for edge in ["HD", "ED", "HE"]:

        info = mixed.get(edge)

        if info is None:

            out[f"{edge}_feasible"] = False
            out[f"{edge}_z"] = np.nan
            out[f"{edge}_w"] = np.nan
            out[f"{edge}_y"] = np.nan
            out[f"{edge}_K"] = np.nan
            out[f"{edge}_transverse_eig"] = np.nan

        else:

            out[f"{edge}_feasible"] = bool(info["feasible"])
            out[f"{edge}_z"] = info["z"]
            out[f"{edge}_w"] = info["w"]
            out[f"{edge}_y"] = info["y"]
            out[f"{edge}_K"] = info["K"]
            out[f"{edge}_transverse_eig"] = info["transverse_eigenvalue"]

    return out


def scan_analytical_map(
    scenario_name: str,
    map_name: str,
    config: Dict[str, object],
):

    base_p = make_scenario(scenario_name)

    x_values = np.asarray(config["x_values"], dtype=float)
    y_values = np.asarray(config["y_values"], dtype=float)

    matrix = np.full(
        (len(y_values), len(x_values)),
        CLASS_TO_CODE["Boundary / non-LAS case"],
        dtype=int,
    )

    rows = []

    print(
        f"\nAnalytical scan: {scenario_name} | {map_name} "
        f"({len(x_values)} x {len(y_values)})"
    )

    for iy, y_value in enumerate(y_values):

        for ix, x_value in enumerate(x_values):

            p = replace(
                base_p,
                **{
                    config["x_param"]: float(x_value),
                    config["y_param"]: float(y_value),
                },
            )

            result = analytical_regime(p)

            label = result["Analytical_class"]

            matrix[iy, ix] = CLASS_TO_CODE.get(
                label,
                CLASS_TO_CODE["Boundary / non-LAS case"],
            )

            row = {
                "Scenario": scenario_name,
                "Map": map_name,
                "Grid_ix": ix,
                "Grid_iy": iy,
                "x_param": config["x_param"],
                "y_param": config["y_param"],
                "x_value": float(x_value),
                "y_value": float(y_value),
                "Analytical_class": label,
                "Detailed_class": result["Detailed_class"],
                "Stable_pure_count": result["Stable_pure_count"],
                "Stable_pure_equilibria": result["Stable_pure_equilibria"],
                "Full_interior_residual": result["Full_interior_residual"],
                **flatten_mixed_fields(result["Mixed_candidates"]),
            }

            rows.append(row)

    df = pd.DataFrame(rows)

    return df, matrix


# =============================================================================
# 21. CLEAN ANALYTICAL MAP PLOTTING
# =============================================================================

def plot_analytical_map(
    scenario_name: str,
    map_name: str,
    config: Dict[str, object],
    df: pd.DataFrame,
    matrix: np.ndarray,
):

    x_raw = np.asarray(config["x_values"], dtype=float)
    y_raw = np.asarray(config["y_values"], dtype=float)

    x = x_raw / float(config["x_scale"])
    y = y_raw / float(config["y_scale"])

    present_codes = sorted(
        int(v)
        for v in np.unique(matrix)
    )

    # Build a compact map-specific palette while preserving the global code.
    full_colors = [
        CLASS_COLORS[label]
        for label in CLASS_ORDER
    ]

    cmap = ListedColormap(full_colors)

    bounds = np.arange(
        -0.5,
        len(CLASS_ORDER) + 0.5,
        1.0,
    )

    norm = BoundaryNorm(bounds, cmap.N)

    fig, ax = plt.subplots(
        figsize=(6.7, 5.5)
    )

    # Dense analytical grid means no artificial smoothing is needed.
    ax.pcolormesh(
        x,
        y,
        matrix,
        cmap=cmap,
        norm=norm,
        shading="nearest",
        edgecolors="none",
        antialiased=False,
    )

    # Thin exact class boundaries.
    if len(present_codes) > 1:

        levels = (
            np.array(present_codes[:-1], dtype=float)
            + 0.5
        )

        if len(levels) > 0:
            ax.contour(
                x,
                y,
                matrix,
                levels=levels,
                colors="white",
                linewidths=0.75,
            )

    # -------------------------------------------------------------------------
    # Benchmark
    # -------------------------------------------------------------------------

    base_p = make_scenario(scenario_name)

    bx = (
        getattr(base_p, config["x_param"])
        / float(config["x_scale"])
    )

    by = (
        getattr(base_p, config["y_param"])
        / float(config["y_scale"])
    )

    ax.scatter(
        [bx],
        [by],
        marker="*",
        s=78,
        facecolor="white",
        edgecolor="black",
        linewidth=0.9,
        zorder=6,
    )

    ax.annotate(
        "Benchmark",
        xy=(bx, by),
        xytext=(7, 5),
        textcoords="offset points",
        fontsize=8.6,
        va="bottom",
    )

    # -------------------------------------------------------------------------
    # Exact policy-threshold overlays
    # -------------------------------------------------------------------------

    if map_name == "policy_support":

        d0 = derived_quantities(base_p)

        SH_PA = (
            base_p.p_CO2
            * (d0["e_H"] - base_p.e_target)
            / (base_p.lambda_F * d0["q_H"])
        )

        # H-E active-payoff equality:
        # pi_H^B + S_H q_H = pi_E^B + S_E q_E
        SH_line = np.linspace(
            x_raw.min(),
            x_raw.max(),
            1000,
        )

        SE_line = (
            d0["pi_H_B"]
            - d0["pi_E_B"]
            + SH_line * d0["q_H"]
        ) / d0["q_E"]

        valid = (
            (SE_line >= y_raw.min())
            & (SE_line <= y_raw.max())
        )

        ax.axvline(
            SH_PA,
            color="#222222",
            linestyle="--",
            linewidth=1.0,
            alpha=0.9,
        )

        ax.plot(
            SH_line[valid],
            SE_line[valid],
            color="#222222",
            linestyle=":",
            linewidth=1.15,
            alpha=0.9,
        )

    # -------------------------------------------------------------------------
    # Labels / title
    # -------------------------------------------------------------------------

    scenario_title = {
        "S1": "Baseline conditions",
        "S2": "Intermediate conditions",
        "S3": "Advanced conditions",
    }[scenario_name]

    ax.set_title(
        f"{scenario_title}\n{config['title_stub']}",
        fontweight="semibold",
        pad=9,
    )

    ax.set_xlabel(config["x_label"])
    ax.set_ylabel(config["y_label"])

    ax.set_xlim(x.min(), x.max())
    ax.set_ylim(y.min(), y.max())

    ax.grid(False)

    for spine in ax.spines.values():
        spine.set_linewidth(0.85)

    # -------------------------------------------------------------------------
    # Legend — only classes present
    # -------------------------------------------------------------------------

    handles = []

    for code in present_codes:

        label = CODE_TO_CLASS[code]

        handles.append(
            Patch(
                facecolor=CLASS_COLORS[label],
                edgecolor="black",
                linewidth=0.45,
                label=label,
            )
        )

    if map_name == "policy_support":

        from matplotlib.lines import Line2D

        handles.extend([
            Line2D(
                [0], [0],
                color="#222222",
                linestyle="--",
                linewidth=1.0,
                label=r"PA threshold: $\Delta_H=0$",
            ),
            Line2D(
                [0], [0],
                color="#222222",
                linestyle=":",
                linewidth=1.15,
                label=r"H--E payoff frontier at $y=1$",
            ),
        ])

    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.14),
        ncol=min(3, len(handles)),
        frameon=False,
        fontsize=8.5,
    )

    plt.tight_layout()

    fig.savefig(
        FIGURE_DIR / f"{scenario_name}_{map_name}_analytical.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )

    fig.savefig(
        FIGURE_DIR / f"{scenario_name}_{map_name}_analytical.pdf",
        bbox_inches="tight",
        pad_inches=0.04,
    )

    plt.show()
    plt.close(fig)


# =============================================================================
# 22. RUN ALL ANALYTICAL MAPS
# =============================================================================

for scenario_name in SCENARIOS:

    for map_name, config in MAP_CONFIGS_C5.items():

        df_map, matrix = scan_analytical_map(
            scenario_name,
            map_name,
            config,
        )

        df_map.to_csv(
            MAP_CSV_DIR / f"{scenario_name}_{map_name}_analytical.csv",
            index=False,
        )

        counts = (
            df_map["Analytical_class"]
            .value_counts()
            .to_dict()
        )

        row = {
            "Scenario": scenario_name,
            "Map": map_name,
            "Grid_points": len(df_map),
        }

        for label in CLASS_ORDER:
            row[label] = int(counts.get(label, 0))

        map_summary_rows.append(row)

        plot_analytical_map(
            scenario_name,
            map_name,
            config,
            df_map,
            matrix,
        )

map_summary_df = pd.DataFrame(map_summary_rows)

map_summary_df.to_csv(
    CSV_DIR_C5 / "analytical_map_outcome_summary.csv",
    index=False,
)


# =============================================================================
# 23. REPRESENTATIVE POLICY-CYCLING POINTS
#
# Chosen to lie clearly inside the analytically certified H-E center region,
# away from the principal threshold boundaries.
# =============================================================================

REPRESENTATIVE_CYCLE_POINTS = {
    "S1": {"S_H": 1.85, "S_E": 0.05},
    "S2": {"S_H": 1.40, "S_E": 0.20},
    "S3": {"S_H": 1.35, "S_E": 0.50},
}

representative_rows = []

for scenario_name, vals in REPRESENTATIVE_CYCLE_POINTS.items():

    p = replace(
        make_scenario(scenario_name),
        S_H=vals["S_H"],
        S_E=vals["S_E"],
    )

    result = analytical_regime(p)

    HE = mixed_edge_candidates(p).get("HE")

    if (
        result["Analytical_class"] != "Persistent HE cycling"
        or HE is None
        or not HE["feasible"]
    ):
        raise RuntimeError(
            f"Representative cycle point for {scenario_name} "
            "is not analytically inside the Persistent HE cycling region."
        )

    linear_period = (
        2.0 * np.pi
        / np.sqrt(-HE["K"])
    )

    representative_rows.append({
        "Scenario": scenario_name,
        "S_H": vals["S_H"],
        "S_E": vals["S_E"],
        "E9_z_H": HE["z"],
        "E9_w_E": HE["w"],
        "E9_y": HE["y"],
        "K_HE": HE["K"],
        "Transverse_eigenvalue": HE["transverse_eigenvalue"],
        "Linearized_period": linear_period,
        "Analytical_class": result["Analytical_class"],
    })

representative_df = pd.DataFrame(representative_rows)

representative_df.to_csv(
    CYCLE_CSV_DIR / "representative_HE_cycle_points.csv",
    index=False,
)


# =============================================================================
# 24. TRANSVERSE-ATTRACTION CHECK FROM 24 FULL-SIMPLEX STARTS
# =============================================================================

def batch_rhs(
    tau: float,
    flat_state: np.ndarray,
    p: Parameters,
    n_ic: int,
) -> np.ndarray:

    X = np.asarray(flat_state, dtype=float).reshape(n_ic, 3)

    z = X[:, 0]
    w = X[:, 1]
    y = X[:, 2]

    D = 1.0 - z - w

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    Pi_bar = z * Pi_H + w * Pi_E + D * Pi_D

    P = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * P

    return np.column_stack([dz, dw, dy]).reshape(-1)


TRANSVERSE_TAU = 300.0
transverse_rows = []

for scenario_name, vals in REPRESENTATIVE_CYCLE_POINTS.items():

    p = replace(
        make_scenario(scenario_name),
        S_H=vals["S_H"],
        S_E=vals["S_E"],
    )

    n_ic = len(FULL_IC_ARRAY)

    sol = solve_ivp(
        fun=lambda tau, state: batch_rhs(tau, state, p, n_ic),
        t_span=(0.0, TRANSVERSE_TAU),
        y0=FULL_IC_ARRAY.reshape(-1),
        t_eval=[TRANSVERSE_TAU],
        method="DOP853",
        rtol=1e-9,
        atol=1e-11,
    )

    if not sol.success:
        raise RuntimeError(
            f"Transverse-attraction batch solve failed for {scenario_name}: "
            f"{sol.message}"
        )

    X = np.asarray(sol.y)[:, -1].reshape(n_ic, 3)

    for i, ic_name in enumerate(FULL_IC_NAMES):

        z = float(X[i, 0])
        w = float(X[i, 1])
        y = float(X[i, 2])
        D = float(1.0 - z - w)

        transverse_rows.append({
            "Scenario": scenario_name,
            "IC": ic_name,
            "tau": TRANSVERSE_TAU,
            "Final_H": z,
            "Final_E": w,
            "Final_D": D,
            "Final_y": y,
            "Abs_D": abs(D),
        })

transverse_df = pd.DataFrame(transverse_rows)

transverse_df.to_csv(
    CYCLE_CSV_DIR / "full_simplex_transverse_attraction_24IC.csv",
    index=False,
)


# =============================================================================
# 25. EXACT H-E EDGE FIRST INTEGRAL
#
# On D=0, w=1-z:
#
#   z_dot = eta_TO z(1-z) [A + B y]
#   y_dot = eta_PA y(1-y) [Delta_E + z(Delta_H-Delta_E)]
#
# with
#   A = pi_H^B - pi_E^B
#   B = S_H q_H - S_E q_E.
#
# A first integral is:
#
# I(z,y) =
#   Delta_E ln z - Delta_H ln(1-z)
#   - (eta_TO/eta_PA)
#     [ A ln y - (A+B) ln(1-y) ].
# =============================================================================

def HE_first_integral(
    z: np.ndarray,
    y: np.ndarray,
    p: Parameters,
    eps: float = 1e-12,
) -> np.ndarray:

    d = derived_quantities(p)

    A = d["pi_H_B"] - d["pi_E_B"]

    B = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    DH = d["Delta_H"]
    DE = d["Delta_E"]

    z = np.clip(
        np.asarray(z, dtype=float),
        eps,
        1.0 - eps,
    )

    y = np.clip(
        np.asarray(y, dtype=float),
        eps,
        1.0 - eps,
    )

    return (
        DE * np.log(z)
        - DH * np.log(1.0 - z)
        - (p.eta_TO / p.eta_PA)
        * (
            A * np.log(y)
            - (A + B) * np.log(1.0 - y)
        )
    )


# =============================================================================
# 26. 24 STRUCTURED EDGE INITIAL CONDITIONS AROUND E9
# =============================================================================

def _logit(x: float) -> float:
    return np.log(x / (1.0 - x))


def _logistic(u: float) -> float:
    return 1.0 / (1.0 + np.exp(-u))


def make_edge_initial_conditions(
    z_star: float,
    y_star: float,
) -> pd.DataFrame:
    """
    8 angular directions x 3 radii = 24 H-E-edge starts.

    Perturbations are generated in logit coordinates so all starts remain
    strictly inside 0<z<1 and 0<y<1.
    """

    angles = np.linspace(
        0.0,
        2.0 * np.pi,
        8,
        endpoint=False,
    )

    radii = [0.40, 0.80, 1.20]

    rows = []

    counter = 1

    for radius in radii:

        for angle in angles:

            z0 = _logistic(
                _logit(z_star)
                + radius * np.cos(angle)
            )

            y0 = _logistic(
                _logit(y_star)
                + radius * np.sin(angle)
            )

            rows.append({
                "Edge_IC": f"EIC{counter:02d}",
                "Radius": radius,
                "Angle_rad": angle,
                "z0_H": z0,
                "w0_E": 1.0 - z0,
                "D0": 0.0,
                "y0": y0,
            })

            counter += 1

    return pd.DataFrame(rows)


# =============================================================================
# 27. LONG-RUN EDGE-CYCLE CERTIFICATION
# =============================================================================

EDGE_TAU_END = 2000.0
EDGE_N_POINTS = 8001

cycle_summary_rows = []

for scenario_name, vals in REPRESENTATIVE_CYCLE_POINTS.items():

    p = replace(
        make_scenario(scenario_name),
        S_H=vals["S_H"],
        S_E=vals["S_E"],
    )

    HE = mixed_edge_candidates(p)["HE"]

    edge_ic_df = make_edge_initial_conditions(
        HE["z"],
        HE["y"],
    )

    edge_ic_df.to_csv(
        CYCLE_CSV_DIR / f"{scenario_name}_edge_initial_conditions_24.csv",
        index=False,
    )

    combined_traj_frames = []

    # -------------------------------------------------------------------------
    # Phase portrait
    # -------------------------------------------------------------------------

    fig_phase, ax_phase = plt.subplots(
        figsize=(6.2, 5.2)
    )

    for _, ic_row in edge_ic_df.iterrows():

        ic_name = ic_row["Edge_IC"]

        initial_state = (
            float(ic_row["z0_H"]),
            float(ic_row["w0_E"]),
            float(ic_row["y0"]),
        )

        tau_eval = np.linspace(
            0.0,
            EDGE_TAU_END,
            EDGE_N_POINTS,
        )

        sol = solve_ivp(
            fun=lambda tau, state: replicator_rhs(
                tau,
                state,
                p,
            ),
            t_span=(0.0, EDGE_TAU_END),
            y0=np.asarray(initial_state, dtype=float),
            t_eval=tau_eval,
            method="DOP853",
            rtol=1e-10,
            atol=1e-12,
        )

        if not sol.success:
            raise RuntimeError(
                f"Edge-cycle solve failed: {scenario_name}, {ic_name}: "
                f"{sol.message}"
            )

        tau = sol.t
        z = sol.y[0]
        w = sol.y[1]
        y = sol.y[2]
        D = 1.0 - z - w

        invariant = HE_first_integral(
            z,
            y,
            p,
        )

        trajectory_df = pd.DataFrame({
            "Scenario": scenario_name,
            "Edge_IC": ic_name,
            "tau": tau,
            "Hydrogen_z": z,
            "Electric_w": w,
            "Diesel_D": D,
            "Policy_y": y,
            "HE_first_integral": invariant,
        })

        trajectory_df.to_csv(
            CYCLE_TRAJECTORY_DIR
            / f"{scenario_name}_{ic_name}_HE_cycle_trajectory.csv",
            index=False,
        )

        combined_traj_frames.append(
            trajectory_df
        )

        # ---------------------------------------------------------------------
        # Tail diagnostics
        # ---------------------------------------------------------------------

        tail_mask = tau >= 0.50 * EDGE_TAU_END

        z_tail = z[tail_mask]
        y_tail = y[tail_mask]

        z_amp = float(
            np.max(z_tail) - np.min(z_tail)
        )

        y_amp = float(
            np.max(y_tail) - np.min(y_tail)
        )

        invariant_range = float(
            np.max(invariant) - np.min(invariant)
        )

        peaks, _ = find_peaks(
            z_tail,
            prominence=max(
                1e-5,
                0.05 * z_amp,
            ),
        )

        peak_times = tau[tail_mask][peaks]

        if len(peak_times) >= 3:

            periods = np.diff(peak_times)

            mean_period = float(
                np.mean(periods)
            )

            period_cv = float(
                np.std(periods)
                / np.mean(periods)
            )

        else:

            mean_period = np.nan
            period_cv = np.nan

        cycle_certified = (
            z_amp > 1e-4
            and y_amp > 1e-4
            and invariant_range < 1e-3
            and len(peak_times) >= 3
        )

        cycle_summary_rows.append({
            "Scenario": scenario_name,
            "Edge_IC": ic_name,
            "S_H": vals["S_H"],
            "S_E": vals["S_E"],
            "E9_z_H": HE["z"],
            "E9_w_E": HE["w"],
            "E9_y": HE["y"],
            "K_HE": HE["K"],
            "Transverse_eigenvalue": HE["transverse_eigenvalue"],
            "Hydrogen_amplitude_tail": z_amp,
            "Policy_amplitude_tail": y_amp,
            "Invariant_range_full_run": invariant_range,
            "Detected_tail_peaks": len(peak_times),
            "Mean_period_tail": mean_period,
            "Period_CV_tail": period_cv,
            "Cycle_certified": cycle_certified,
        })

        # Phase portrait — same restrained color, low opacity.
        ax_phase.plot(
            z,
            y,
            color="#6F7C86",
            linewidth=0.8,
            alpha=0.45,
        )

    # -------------------------------------------------------------------------
    # Save combined scenario trajectories
    # -------------------------------------------------------------------------

    combined_df = pd.concat(
        combined_traj_frames,
        ignore_index=True,
    )

    combined_df.to_csv(
        CYCLE_CSV_DIR
        / f"{scenario_name}_all_24_HE_cycle_trajectories.csv",
        index=False,
    )

    # -------------------------------------------------------------------------
    # Phase portrait formatting
    # -------------------------------------------------------------------------

    ax_phase.scatter(
        [HE["z"]],
        [HE["y"]],
        marker="*",
        s=90,
        facecolor="white",
        edgecolor="black",
        linewidth=0.9,
        zorder=6,
        label=r"$E_9$",
    )

    ax_phase.set_xlabel(
        r"Hydrogen service share, $z$"
    )

    ax_phase.set_ylabel(
        r"Active-policy weight, $y$"
    )

    ax_phase.set_title(
        {
            "S1": "Baseline conditions",
            "S2": "Intermediate conditions",
            "S3": "Advanced conditions",
        }[scenario_name]
        + "\nCertified H--E edge cycling",
        fontweight="semibold",
    )

    ax_phase.set_xlim(0.0, 1.0)
    ax_phase.set_ylim(0.0, 1.0)

    ax_phase.grid(False)

    ax_phase.legend(
        frameon=False,
        loc="best",
    )

    for spine in ax_phase.spines.values():
        spine.set_linewidth(0.85)

    plt.tight_layout()

    fig_phase.savefig(
        FIGURE_DIR / f"{scenario_name}_HE_cycle_phase_portrait.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )

    fig_phase.savefig(
        FIGURE_DIR / f"{scenario_name}_HE_cycle_phase_portrait.pdf",
        bbox_inches="tight",
        pad_inches=0.04,
    )

    plt.show()
    plt.close(fig_phase)


# =============================================================================
# 28. SAVE CYCLE AUDIT SUMMARY
# =============================================================================

cycle_summary_df = pd.DataFrame(
    cycle_summary_rows
)

cycle_summary_df.to_csv(
    CYCLE_CSV_DIR / "HE_cycle_certification_summary_24IC.csv",
    index=False,
)


# =============================================================================
# 29. PRINT FINAL PHASE 4C-5 SUMMARY
# =============================================================================

print("\n")
print("=" * 110)
print("PHASE 4C-5 — ANALYTICAL CLASSIFICATION AND CYCLING AUDIT COMPLETED")
print("=" * 110)

print("\nANALYTICAL MAP OUTCOME COUNTS")

for _, row in map_summary_df.iterrows():

    print(
        f"\n{row['Scenario']} | {row['Map']}"
    )

    for label in CLASS_ORDER:

        count = int(
            row.get(label, 0)
        )

        if count > 0:
            print(
                f"  {label}: {count}"
            )

print("\nREPRESENTATIVE H-E CYCLING POINTS")

for _, row in representative_df.iterrows():

    print(
        f"\n{row['Scenario']}: "
        f"S_H={row['S_H']:.3f}, "
        f"S_E={row['S_E']:.3f}"
    )

    print(
        f"  E9 = "
        f"(z={row['E9_z_H']:.6f}, "
        f"w={row['E9_w_E']:.6f}, "
        f"y={row['E9_y']:.6f})"
    )

    print(
        f"  K_HE={row['K_HE']:.8f}, "
        f"transverse eigenvalue={row['Transverse_eigenvalue']:.8f}"
    )

    print(
        f"  linearized period≈{row['Linearized_period']:.4f}"
    )

print("\nCYCLE CERTIFICATION RATES")

for scenario_name in SCENARIOS:

    sub = cycle_summary_df[
        cycle_summary_df["Scenario"] == scenario_name
    ]

    certified = int(
        sub["Cycle_certified"].sum()
    )

    total = len(sub)

    print(
        f"  {scenario_name}: "
        f"{certified}/{total} edge starts certified as persistent cycles"
    )

print("\nTRANSVERSE ATTRACTION CHECK")

for scenario_name in SCENARIOS:

    sub = transverse_df[
        transverse_df["Scenario"] == scenario_name
    ]

    print(
        f"  {scenario_name}: "
        f"max |D(tau={TRANSVERSE_TAU:.0f})| "
        f"across 24 full-simplex starts = "
        f"{sub['Abs_D'].max():.3e}"
    )

print("\nFiles saved under:")
print(f"  {PHASE4C5_DIR.resolve()}")

print("\nKey CSV outputs:")
print("  policy_threshold_summary.csv")
print("  analytical_map_outcome_summary.csv")
print("  analytical_maps/*.csv")
print("  cycle_audit/representative_HE_cycle_points.csv")
print("  cycle_audit/full_simplex_transverse_attraction_24IC.csv")
print("  cycle_audit/HE_cycle_certification_summary_24IC.csv")
print("  cycle_audit/individual_trajectories/*.csv")
print("  cycle_audit/S1_all_24_HE_cycle_trajectories.csv")
print("  cycle_audit/S2_all_24_HE_cycle_trajectories.csv")
print("  cycle_audit/S3_all_24_HE_cycle_trajectories.csv")

print("\nPhase 4C-5 completed.")
