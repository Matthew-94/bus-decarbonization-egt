# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    y_HE = (
        (d["pi_E_B"] - d["pi_H_B"])
        / denominator_HE
    )

    y_HD = (
        (d["pi_D_B"] - d["pi_H_B"])
        / denominator_HD
    )

    y_ED = (
        (d["pi_D_B"] - d["pi_E_B"])
        / denominator_ED
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )


# =============================================================================
# 12. MULTI-INITIAL-CONDITION DESIGN
# =============================================================================

INITIAL_CONDITIONS = {

    # Diesel-heavy, low initial policy commitment
    "IC1": (0.05, 0.15, 0.20),

    # Diesel-heavy, high initial policy commitment
    "IC2": (0.05, 0.15, 0.80),

    # Electric-heavy, low initial policy commitment
    "IC3": (0.10, 0.70, 0.20),

    # Electric-heavy, high initial policy commitment
    "IC4": (0.10, 0.70, 0.80),

    # Hydrogen-heavy, low initial policy commitment
    "IC5": (0.70, 0.10, 0.20),

    # Hydrogen-heavy, high initial policy commitment
    "IC6": (0.70, 0.10, 0.80),

    # Balanced interior state
    "IC7": (0.30, 0.30, 0.50),
}


# =============================================================================
# 13. PRODUCTION SETTINGS
# =============================================================================

SCENARIOS = ["S1", "S2", "S3"]

# 120 is long enough to show convergence for all seven initial states while
# retaining useful visibility of the S3 D -> E -> H transition.
TAU_SPAN = (0.0, 120.0)
N_POINTS = 6001

REPRESENTATIVE_IC = "IC1"


# =============================================================================
# 14. PLOT SETTINGS
# =============================================================================

TECH_COLORS = {
    "H": "#333333",
    "E": "#557A95",
    "D": "#999999",
    "Y": "#8B5E5E",
}

LINE_STYLES = {
    "IC1": "-",
    "IC2": "--",
    "IC3": "-.",
    "IC4": ":",
    "IC5": (0, (5, 2)),
    "IC6": (0, (3, 1, 1, 1)),
    "IC7": (0, (1, 1)),
}

NORMAL_LINEWIDTH = 1.35
REPRESENTATIVE_LINEWIDTH = 2.5


# =============================================================================
# 15. DIAGNOSTIC HELPERS
# =============================================================================

def interpolated_crossing(tau, values, threshold):

    tau = np.asarray(tau)
    values = np.asarray(values)

    shifted = values - threshold

    crossing_idx = np.where(
        shifted[:-1] * shifted[1:] <= 0.0
    )[0]

    if len(crossing_idx) == 0:
        return np.nan

    i = crossing_idx[0]

    t0 = tau[i]
    t1 = tau[i + 1]

    v0 = values[i]
    v1 = values[i + 1]

    if abs(v1 - v0) < 1e-14:
        return float(t0)

    fraction = (threshold - v0) / (v1 - v0)

    return float(t0 + fraction * (t1 - t0))


def first_crossing_time(
    tau,
    values,
    threshold,
    direction="up",
):

    tau = np.asarray(tau)
    values = np.asarray(values)

    if direction == "up":
        idx = np.where(values >= threshold)[0]

    elif direction == "down":
        idx = np.where(values <= threshold)[0]

    else:
        raise ValueError("direction must be 'up' or 'down'.")

    if len(idx) == 0:
        return np.nan

    return float(tau[idx[0]])


# =============================================================================
# 16. PRE-RUN CERTIFICATION
# =============================================================================

print("=" * 100)
print("PHASE 4C — STANDALONE MODEL CERTIFICATION")
print("=" * 100)

for scenario_name in SCENARIOS:

    p = make_scenario(scenario_name)

    d = derived_quantities(p)

    stability = pure_stability_report(p)

    error = certify_rhs_equivalence(p)

    thresholds = policy_thresholds(p)

    print(f"\n{scenario_name}")
    print("-" * 70)

    print(
        f"q_H={d['q_H']:.4f}, "
        f"q_E={d['q_E']:.4f}, "
        f"q_D={d['q_D']:.4f}"
    )

    print(
        f"pi_H^B={d['pi_H_B']:.4f}, "
        f"pi_E^B={d['pi_E_B']:.4f}, "
        f"pi_D^B={d['pi_D_B']:.4f}"
    )

    print(
        f"Delta_H={d['Delta_H']:.6f}, "
        f"Delta_E={d['Delta_E']:.6f}, "
        f"Delta_D={d['Delta_D']:.6f}"
    )

    print(
        f"y_HE*={thresholds['y_HE']:.6f}"
    )

    print(
        f"Direct/Gamma RHS maximum error = {error:.3e}"
    )

    stable = [
        name
        for name, flag in stability.items()
        if flag
    ]

    print(
        "Stable pure rest point(s): "
        + (", ".join(stable) if stable else "None")
    )


# =============================================================================
# 17. MULTI-START TRAJECTORY PRODUCTION
# =============================================================================

summary_rows = []
all_trajectory_rows = []

for scenario_name in SCENARIOS:

    p = make_scenario(scenario_name)

    thresholds = policy_thresholds(p)
    y_HE_star = thresholds["y_HE"]

    # One independent 2x2 figure for each scenario
    fig, axes = plt.subplots(
        2,
        2,
        figsize=(11.5, 8.0),
        sharex=True,
        sharey=True,
    )

    ax_H = axes[0, 0]
    ax_E = axes[0, 1]
    ax_D = axes[1, 0]
    ax_Y = axes[1, 1]

    for ic_name, initial_state in INITIAL_CONDITIONS.items():

        sol = solve_replicator(
            p=p,
            initial_state=initial_state,
            tau_span=TAU_SPAN,
            n_points=N_POINTS,
        )

        tau = sol.t

        z = sol.y[0]
        w = sol.y[1]
        y = sol.y[2]

        D = 1.0 - z - w

        # Clip only tiny solver roundoff for figures/reporting.
        z_plot = np.clip(z, 0.0, 1.0)
        w_plot = np.clip(w, 0.0, 1.0)
        y_plot = np.clip(y, 0.0, 1.0)
        D_plot = np.clip(D, 0.0, 1.0)

        linewidth = (
            REPRESENTATIVE_LINEWIDTH
            if ic_name == REPRESENTATIVE_IC
            else NORMAL_LINEWIDTH
        )

        alpha = (
            1.0
            if ic_name == REPRESENTATIVE_IC
            else 0.70
        )

        linestyle = LINE_STYLES[ic_name]

        # Hydrogen
        ax_H.plot(
            tau,
            z_plot,
            color=TECH_COLORS["H"],
            linestyle=linestyle,
            linewidth=linewidth,
            alpha=alpha,
            label=ic_name,
        )

        # Electric
        ax_E.plot(
            tau,
            w_plot,
            color=TECH_COLORS["E"],
            linestyle=linestyle,
            linewidth=linewidth,
            alpha=alpha,
        )

        # Diesel
        ax_D.plot(
            tau,
            D_plot,
            color=TECH_COLORS["D"],
            linestyle=linestyle,
            linewidth=linewidth,
            alpha=alpha,
        )

        # Policy
        ax_Y.plot(
            tau,
            y_plot,
            color=TECH_COLORS["Y"],
            linestyle=linestyle,
            linewidth=linewidth,
            alpha=alpha,
        )

        # ---------------------------------------------------------------------
        # Expected H/E payoff trajectories
        # ---------------------------------------------------------------------

        Pi_H = np.zeros_like(tau)
        Pi_E = np.zeros_like(tau)

        for i, yi in enumerate(y):

            op = expected_operator_payoffs(
                y=float(yi),
                p=p,
            )

            Pi_H[i] = op["Pi_H"]
            Pi_E[i] = op["Pi_E"]

        HE_gap = Pi_H - Pi_E

        # ---------------------------------------------------------------------
        # PA policy-advantage trajectory
        # ---------------------------------------------------------------------

        d_now = derived_quantities(p)

        policy_advantage = (
            z * d_now["Delta_H"]
            + w * d_now["Delta_E"]
            + D * d_now["Delta_D"]
        )

        # ---------------------------------------------------------------------
        # SAVE COMPLETE TRAJECTORY TO CSV
        #
        # One file is written for every Scenario x Initial Condition.
        # These files are independent of the plotting code and can later be
        # used to recreate figures in any desired style/software.
        # ---------------------------------------------------------------------

        trajectory_df = pd.DataFrame(
            {
                "Scenario": scenario_name,
                "IC": ic_name,
                "tau": tau,
                "Hydrogen_z": z_plot,
                "Electric_w": w_plot,
                "Diesel_share": D_plot,
                "Policy_y": y_plot,
                "Pi_H": Pi_H,
                "Pi_E": Pi_E,
                "Pi_D": np.array(
                    [
                        expected_operator_payoffs(float(yi), p)["Pi_D"]
                        for yi in y
                    ],
                    dtype=float,
                ),
                "Pi_H_minus_Pi_E": HE_gap,
                "PA_policy_advantage": policy_advantage,
            }
        )

        individual_csv = (
            TRAJECTORY_CSV_DIR
            / f"{scenario_name}_{ic_name}_trajectory.csv"
        )

        trajectory_df.to_csv(
            individual_csv,
            index=False,
        )

        all_trajectory_rows.append(
            trajectory_df
        )

        # ---------------------------------------------------------------------
        # H-E threshold diagnostics
        # ---------------------------------------------------------------------

        if 0.0 <= y_HE_star <= 1.0:

            tau_HE_policy = interpolated_crossing(
                tau,
                y,
                y_HE_star,
            )

            tau_HE_payoff = interpolated_crossing(
                tau,
                HE_gap,
                0.0,
            )

        else:

            tau_HE_policy = np.nan
            tau_HE_payoff = np.nan

        # ---------------------------------------------------------------------
        # Transition milestones
        # ---------------------------------------------------------------------

        tau_H90 = first_crossing_time(
            tau,
            z_plot,
            0.90,
            direction="up",
        )

        tau_E90 = first_crossing_time(
            tau,
            w_plot,
            0.90,
            direction="up",
        )

        tau_D10 = first_crossing_time(
            tau,
            D_plot,
            0.10,
            direction="down",
        )

        tau_Y90 = first_crossing_time(
            tau,
            y_plot,
            0.90,
            direction="up",
        )

        idx_Emax = int(np.argmax(w_plot))

        E_max = float(w_plot[idx_Emax])
        tau_Emax = float(tau[idx_Emax])

        # ---------------------------------------------------------------------
        # Save row
        # ---------------------------------------------------------------------

        summary_rows.append(
            {
                "Scenario": scenario_name,
                "IC": ic_name,

                "z0": initial_state[0],
                "w0": initial_state[1],
                "D0": (
                    1.0
                    - initial_state[0]
                    - initial_state[1]
                ),
                "y0": initial_state[2],

                "Final_H": float(z_plot[-1]),
                "Final_E": float(w_plot[-1]),
                "Final_D": float(D_plot[-1]),
                "Final_y": float(y_plot[-1]),

                "tau_H90": tau_H90,
                "tau_E90": tau_E90,
                "tau_D10": tau_D10,
                "tau_y90": tau_Y90,

                "Max_E": E_max,
                "tau_Max_E": tau_Emax,

                "y_HE_star": y_HE_star,
                "tau_y_HE": tau_HE_policy,
                "tau_payoff_HE": tau_HE_payoff,
            }
        )

    # =========================================================================
    # Figure formatting
    # =========================================================================

    panel_info = [
        (ax_H, r"(a) Hydrogen service share, $z$"),
        (ax_E, r"(b) Electric service share, $w$"),
        (ax_D, r"(c) Diesel service share, $1-z-w$"),
        (ax_Y, r"(d) Active-policy weight, $y$"),
    ]

    for ax, title in panel_info:

        ax.set_title(
            title,
            fontsize=12,
            fontweight="bold",
        )

        ax.set_xlim(TAU_SPAN)
        ax.set_ylim(-0.02, 1.02)

        ax.tick_params(
            axis="both",
            labelsize=10,
            direction="in",
        )

        ax.grid(False)

        for spine in ax.spines.values():
            spine.set_linewidth(1.0)

    # S3 policy threshold is shown in the policy panel.
    if (
        scenario_name == "S3"
        and 0.0 <= y_HE_star <= 1.0
    ):

        ax_Y.axhline(
            y=y_HE_star,
            color="black",
            linewidth=1.25,
            linestyle="-.",
        )

        ax_Y.text(
            68.0,
            y_HE_star + 0.035,
            rf"$y_{{HE}}^*={y_HE_star:.2f}$",
            fontsize=10,
        )

    # Axis labels
    ax_D.set_xlabel(
        r"Normalized evolutionary time, $\tau$",
        fontsize=11,
    )

    ax_Y.set_xlabel(
        r"Normalized evolutionary time, $\tau$",
        fontsize=11,
    )

    ax_H.set_ylabel(
        "Evolutionary strategy weight",
        fontsize=11,
    )

    ax_D.set_ylabel(
        "Evolutionary strategy weight",
        fontsize=11,
    )

    scenario_titles = {
        "S1": "Baseline transition conditions",
        "S2": "Intermediate transition conditions",
        "S3": "Advanced transition conditions",
    }

    fig.suptitle(
        scenario_titles[scenario_name],
        fontsize=14,
        fontweight="bold",
        y=0.99,
    )

    # Shared initial-condition legend
    handles, labels = ax_H.get_legend_handles_labels()

    fig.legend(
        handles,
        labels,
        loc="lower center",
        ncol=7,
        frameon=False,
        fontsize=9,
        bbox_to_anchor=(0.5, 0.005),
    )

    fig.tight_layout(
        rect=[0.02, 0.06, 1.0, 0.96]
    )

    fig.savefig(
        OUTPUT_DIR / f"Fig_{scenario_name}_multistart_dynamics.pdf",
        bbox_inches="tight",
    )

    fig.savefig(
        OUTPUT_DIR / f"Fig_{scenario_name}_multistart_dynamics.png",
        dpi=600,
        bbox_inches="tight",
    )

    plt.show()
    plt.close(fig)

    # -------------------------------------------------------------------------
    # SAVE ONE LONG-FORM CSV CONTAINING ALL INITIAL CONDITIONS FOR THIS SCENARIO
    # -------------------------------------------------------------------------

    scenario_frames = [
        df
        for df in all_trajectory_rows
        if len(df) > 0
        and df["Scenario"].iloc[0] == scenario_name
    ]

    scenario_long_df = pd.concat(
        scenario_frames,
        ignore_index=True,
    )

    scenario_long_df.to_csv(
        SCENARIO_CSV_DIR
        / f"{scenario_name}_all_initial_conditions.csv",
        index=False,
    )


# =============================================================================
# 18. S3 PAYOFF-REVERSAL FIGURE
# =============================================================================

p = make_scenario("S3")

y_grid = np.linspace(0.0, 1.0, 1001)

Pi_H = np.zeros_like(y_grid)
Pi_E = np.zeros_like(y_grid)
Pi_D = np.zeros_like(y_grid)

for i, yi in enumerate(y_grid):

    op = expected_operator_payoffs(
        y=float(yi),
        p=p,
    )

    Pi_H[i] = op["Pi_H"]
    Pi_E[i] = op["Pi_E"]
    Pi_D[i] = op["Pi_D"]

y_HE = policy_thresholds(p)["y_HE"]

Pi_switch = np.interp(
    y_HE,
    y_grid,
    Pi_H,
)

# Save the complete payoff-reversal curve so the figure can be recreated
# independently later.
payoff_reversal_df = pd.DataFrame(
    {
        "Policy_y": y_grid,
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
        "Pi_H_minus_Pi_E": Pi_H - Pi_E,
        "y_HE_star": np.full_like(y_grid, y_HE, dtype=float),
    }
)

payoff_reversal_df.to_csv(
    DIAGNOSTIC_CSV_DIR
    / "S3_policy_payoff_reversal_curve.csv",
    index=False,
)

fig, ax = plt.subplots(
    figsize=(7.2, 5.0)
)

ax.plot(
    y_grid,
    Pi_H,
    color=TECH_COLORS["H"],
    linewidth=2.4,
    label=r"$\Pi_H(y)$",
)

ax.plot(
    y_grid,
    Pi_E,
    color=TECH_COLORS["E"],
    linewidth=2.4,
    label=r"$\Pi_E(y)$",
)

ax.plot(
    y_grid,
    Pi_D,
    color=TECH_COLORS["D"],
    linewidth=2.2,
    linestyle="--",
    label=r"$\Pi_D(y)$",
)

ax.axvline(
    y_HE,
    color="black",
    linestyle="-.",
    linewidth=1.5,
)

ax.scatter(
    [y_HE],
    [Pi_switch],
    s=45,
    color="black",
    zorder=5,
)

ax.annotate(
    (
        rf"$y_{{HE}}^*={y_HE:.2f}$"
        "\nH--E payoff reversal"
    ),
    xy=(y_HE, Pi_switch),
    xytext=(0.50, Pi_switch + 0.22),
    arrowprops=dict(
        arrowstyle="->",
        linewidth=1.0,
    ),
    fontsize=10,
)

ax.text(
    0.17,
    2.52,
    "Electric-favorable\nselection pressure",
    ha="center",
    va="center",
    fontsize=10,
)

ax.text(
    0.86,
    2.52,
    "Hydrogen-favorable\nselection pressure",
    ha="center",
    va="center",
    fontsize=10,
)

ax.set_xlabel(
    r"Active-policy weight, $y$",
    fontsize=11,
)

ax.set_ylabel(
    "Expected operator payoff (CAD/RVK)",
    fontsize=11,
)

ax.set_xlim(0.0, 1.0)

ax.legend(
    frameon=False,
    fontsize=10,
    loc="lower left",
)

ax.tick_params(
    labelsize=10,
    direction="in",
)

ax.grid(False)

for spine in ax.spines.values():
    spine.set_linewidth(1.0)

plt.tight_layout()

fig.savefig(
    OUTPUT_DIR / "Fig_S3_policy_payoff_reversal.pdf",
    bbox_inches="tight",
)

fig.savefig(
    OUTPUT_DIR / "Fig_S3_policy_payoff_reversal.png",
    dpi=600,
    bbox_inches="tight",
)

plt.show()
plt.close(fig)


# =============================================================================
# 19. SAVE NUMERICAL SUMMARY
# =============================================================================

summary = pd.DataFrame(summary_rows)

summary.to_csv(
    CSV_DIR / "Phase4C_multistart_summary.csv",
    index=False,
)

# Also retain the summary in the top output folder for convenience.
summary.to_csv(
    OUTPUT_DIR / "Phase4C_multistart_summary.csv",
    index=False,
)

# -------------------------------------------------------------------------
# Master long-form trajectory CSV: all scenarios and all initial conditions
# -------------------------------------------------------------------------

master_trajectory_df = pd.concat(
    all_trajectory_rows,
    ignore_index=True,
)

master_trajectory_df.to_csv(
    CSV_DIR / "ALL_scenarios_ALL_initial_conditions_trajectories.csv",
    index=False,
)

# -------------------------------------------------------------------------
# Scenario parameter CSV
# -------------------------------------------------------------------------

parameter_rows = []

for scenario_name in SCENARIOS:
    p = make_scenario(scenario_name)
    row = {"Scenario": scenario_name}
    row.update(vars(p))
    parameter_rows.append(row)

parameter_df = pd.DataFrame(parameter_rows)

parameter_df.to_csv(
    DIAGNOSTIC_CSV_DIR / "scenario_parameters.csv",
    index=False,
)

# -------------------------------------------------------------------------
# Derived-quantity and threshold CSV
# -------------------------------------------------------------------------

derived_rows = []

for scenario_name in SCENARIOS:

    p = make_scenario(scenario_name)
    d = derived_quantities(p)
    th = policy_thresholds(p)

    row = {
        "Scenario": scenario_name,
        **d,
        **th,
    }

    derived_rows.append(row)

derived_df = pd.DataFrame(derived_rows)

derived_df.to_csv(
    DIAGNOSTIC_CSV_DIR
    / "scenario_derived_quantities_and_thresholds.csv",
    index=False,
)


# =============================================================================
# 20. PRINT FINAL-STATE AUDIT
# =============================================================================

print("\n")
print("=" * 110)
print("PHASE 4C — MULTI-INITIAL-CONDITION FINAL-STATE AUDIT")
print("=" * 110)

for scenario_name in SCENARIOS:

    print(f"\n{scenario_name}")
    print("-" * 90)

    subset = summary[
        summary["Scenario"] == scenario_name
    ]

    for _, row in subset.iterrows():

        print(
            f"{row['IC']}: "
            f"H={row['Final_H']:.6f}, "
            f"E={row['Final_E']:.6f}, "
            f"D={row['Final_D']:.6f}, "
            f"y={row['Final_y']:.6f}"
        )

    if scenario_name == "S3":

        print("\nS3 H-E reversal diagnostics:")

        for _, row in subset.iterrows():

            print(
                f"{row['IC']}: "
                f"tau(y=y_HE*)={row['tau_y_HE']:.4f}, "
                f"tau(Pi_H=Pi_E)={row['tau_payoff_HE']:.4f}, "
                f"max E={row['Max_E']:.4f} "
                f"at tau={row['tau_Max_E']:.4f}"
            )


# =============================================================================
# 21. FILE LIST
# =============================================================================

print("\nFiles created in:")
print(f"  {OUTPUT_DIR.resolve()}")

print("\nFIGURES")
print("  Fig_S1_multistart_dynamics.png / .pdf")
print("  Fig_S2_multistart_dynamics.png / .pdf")
print("  Fig_S3_multistart_dynamics.png / .pdf")
print("  Fig_S3_policy_payoff_reversal.png / .pdf")

print("\nCSV RESULTS")
print("  csv_results/Phase4C_multistart_summary.csv")
print("  csv_results/ALL_scenarios_ALL_initial_conditions_trajectories.csv")
print("  csv_results/trajectories_individual/S1_IC1_trajectory.csv ... S3_IC7_trajectory.csv")
print("  csv_results/trajectories_by_scenario/S1_all_initial_conditions.csv")
print("  csv_results/trajectories_by_scenario/S2_all_initial_conditions.csv")
print("  csv_results/trajectories_by_scenario/S3_all_initial_conditions.csv")
print("  csv_results/diagnostics/S3_policy_payoff_reversal_curve.csv")
print("  csv_results/diagnostics/scenario_parameters.csv")
print("  csv_results/diagnostics/scenario_derived_quantities_and_thresholds.csv")

print("\nPhase 4C standalone production completed.")
