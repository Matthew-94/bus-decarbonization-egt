# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1C
# ANALYTICAL BIFURCATION AUDIT FOR OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE
#
# WHY THIS STEP IS NEEDED
# -----------------------
# The 24-IC maps in Phase 4D-1B revealed broad path-dependent regions.
# Because the audited infrastructure burden depends on the technology's own
# service share, the extension creates positive frequency dependence at low
# penetration:
#
#   Omega_i(x_i) is high when x_i is rare,
#   falls with deployment,
#   and rises mildly again at high penetration.
#
# Under the frozen policy block, Delta_H, Delta_E, Delta_D > 0 in S1-S3,
# therefore y -> 1 for all interior policy starts.
#
# Diesel is also strictly dominated by the non-focal clean competitor at y=1
# in all three scenarios. Hence the long-run extension reduces to an H-E edge
# problem with one state-dependent focal payoff:
#
#   g(x) = M(rho) - F_inf s(x)
#
# where
#
#   s(x) = exp(-4x) + 0.10 x + 0.50 max(0,x-0.70)^2.
#
# This script classifies the exact attractor structure analytically and
# separates:
#
#   1. unique focal-technology attraction,
#   2. pure H-E bistability,
#   3. pure-competitor + stable mixed H/E coexistence,
#   4. unique competitor attraction,
#   5. critical bifurcation boundaries.
#
# No ODE grid is needed. All outputs are saved to CSV.
# =============================================================================

from scipy.optimize import minimize_scalar, brentq
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================

# =============================================================================
# PHASE 4D-2A
# BOUNDED PASSENGER-UTILIZATION SPECIFICATION
# CALIBRATION + ANALYTICAL REGIME AUDIT
#
# PURPOSE
# -------
# Test whether replacing the baseline linear passenger-utilization equation
#
#   q_i = alpha_0 + gamma_1 U_i - gamma_2 U_O
#
# with the bounded outside-option Logit form
#
#   q_i^L = qbar / [1 + exp(-beta (U_i-U_O))]
#
# changes the strategic transition regimes.
#
# IMPORTANT
# ---------
# 1. Passengers still do NOT choose propulsion technologies directly.
#    q_i is utilization of transit service under configuration i relative to
#    the outside option.
#
# 2. The benchmark Logit calibration matches diesel utilization exactly:
#
#       U_D = 0, U_O = 1, q_D = 1.20.
#
#    Choosing qbar = 3 gives
#
#       beta_match = ln(1.5) ≈ 0.405465.
#
# 3. During the beta sensitivity sweep, qbar(beta) is re-anchored so that
#    q_D remains exactly 1.20 boardings/RVK. This isolates the SHAPE /
#    responsiveness of the bounded utilization function instead of changing
#    the overall transit-utilization scale at the same time.
#
# 4. The linear-demand consumer-surplus formula is NOT reused under Logit.
#    It is not required for the replicator dynamics because the PA update uses
#    only the incremental policy payoff Delta_i.
#
# ALL tables and sensitivity results are saved to CSV.
# =============================================================================


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

OUT_DIR = Path("Phase4D2A_passenger_logit_calibration_audit")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CSV_D2A = OUT_DIR / "csv_results"
CSV_D2A.mkdir(parents=True, exist_ok=True)

FIG_D2A = OUT_DIR / "figures"
FIG_D2A.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION FIGURE STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.8,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. MATCHED LOGIT CALIBRATION
# =============================================================================

Q_D_TARGET = 1.20
QBAR_MATCH = 3.00

# Since U_D = 0 and U_O = 1:
# 1.20 = 3 / (1 + exp(beta))
# exp(beta) = 1.5
BETA_MATCH = float(
    np.log(
        1.5
    )
)

BETA_GRID = np.linspace(
    0.15,
    1.20,
    211,
)


# =============================================================================
# 15. LOGIT UTILIZATION
# =============================================================================

def qbar_to_anchor_diesel(
    beta,
    U_D,
    U_O,
    q_D_target=Q_D_TARGET,
):
    """
    Choose qbar so the Logit model reproduces q_D_target exactly.
    """

    return float(
        q_D_target
        * (
            1.0
            + np.exp(
                -beta
                * (
                    U_D
                    - U_O
                )
            )
        )
    )


def bounded_q(
    U,
    U_O,
    beta,
    qbar,
):

    return float(
        qbar
        / (
            1.0
            + np.exp(
                -beta
                * (
                    U
                    - U_O
                )
            )
        )
    )


# =============================================================================
# 16. DERIVED QUANTITIES UNDER BOUNDED UTILIZATION
# =============================================================================

def derived_logit(
    p,
    beta,
    anchor_diesel=True,
    qbar_fixed=QBAR_MATCH,
):
    """
    Rebuild all quantities that depend on q_i.

    Operating cost and annualized capital cost remain exactly the same as in
    the frozen core model.

    Consumer-surplus levels are deliberately omitted because the linear
    q^2/(2 gamma_1 beta_t) expression is not valid for this Logit specification.
    """

    linear = derived_quantities(
        p
    )

    U_H = linear["U_H"]
    U_E = linear["U_E"]
    U_D = linear["U_D"]

    if anchor_diesel:

        qbar = qbar_to_anchor_diesel(
            beta=beta,
            U_D=U_D,
            U_O=p.U_O,
        )

    else:

        qbar = float(
            qbar_fixed
        )

    q_H = bounded_q(
        U_H,
        p.U_O,
        beta,
        qbar,
    )

    q_E = bounded_q(
        U_E,
        p.U_O,
        beta,
        qbar,
    )

    q_D = bounded_q(
        U_D,
        p.U_O,
        beta,
        qbar,
    )

    C_H = linear["C_H"]
    C_E = linear["C_E"]
    C_D = linear["C_D"]

    cap_H = linear["cap_H"]
    cap_E = linear["cap_E"]
    cap_D = linear["cap_D"]

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    pi_H_A = (
        pi_H_B
        + p.S_H * q_H
    )

    pi_E_A = (
        pi_E_B
        + p.S_E * q_E
    )

    pi_D_A = (
        pi_D_B
        - p.T_D * q_D
    )

    e_H = (
        p.l
        * q_H
        * p.nu_H
    )

    e_E = (
        p.l
        * q_E
        * p.nu_E
    )

    e_D = (
        p.l
        * q_D
        * p.nu_D
    )

    Delta_H = (
        p.p_CO2
        * (
            e_H
            - p.e_target
        )
        - p.lambda_F
        * p.S_H
        * q_H
    )

    Delta_E = (
        p.p_CO2
        * (
            e_E
            - p.e_target
        )
        - p.lambda_F
        * p.S_E
        * q_E
    )

    Delta_D = (
        p.p_CO2
        * (
            e_D
            - p.e_target
        )
        + p.lambda_F
        * p.T_D
        * q_D
    )

    Gamma_H0 = (
        pi_H_B
        - pi_D_B
    )

    Gamma_H1 = (
        p.S_H
        * q_H
        + p.T_D
        * q_D
    )

    Gamma_E0 = (
        pi_E_B
        - pi_D_B
    )

    Gamma_E1 = (
        p.S_E
        * q_E
        + p.T_D
        * q_D
    )

    return {
        "beta": beta,
        "qbar": qbar,

        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 17. PURE-EQUILIBRIUM STABILITY UNDER ALTERNATIVE q_i
# =============================================================================

def pure_stability_from_derived(
    d,
):

    GH0 = d["Gamma_H0"]
    GH1 = d["Gamma_H1"]

    GE0 = d["Gamma_E0"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_at_1 = (
        GH0
        + GH1
    )

    GE_at_1 = (
        GE0
        + GE1
    )

    stable = []

    if (
        GH0 < 0.0
        and GE0 < 0.0
        and DD < 0.0
    ):
        stable.append(
            "D_B"
        )

    if (
        GH0 > 0.0
        and GH0 > GE0
        and DH < 0.0
    ):
        stable.append(
            "H_B"
        )

    if (
        GE0 > 0.0
        and GE0 > GH0
        and DE < 0.0
    ):
        stable.append(
            "E_B"
        )

    if (
        GH_at_1 < 0.0
        and GE_at_1 < 0.0
        and DD > 0.0
    ):
        stable.append(
            "D_A"
        )

    if (
        GH_at_1 > 0.0
        and GH_at_1 > GE_at_1
        and DH > 0.0
    ):
        stable.append(
            "H_A"
        )

    if (
        GE_at_1 > 0.0
        and GE_at_1 > GH_at_1
        and DE > 0.0
    ):
        stable.append(
            "E_A"
        )

    return stable


def y_HE_threshold(
    d,
):

    numerator = (
        d["pi_E_B"]
        - d["pi_H_B"]
    )

    denominator = (
        d["Gamma_H1"]
        - d["Gamma_E1"]
    )

    if abs(
        denominator
    ) < 1e-12:

        return np.nan

    return float(
        numerator
        / denominator
    )


# =============================================================================
# 18. MATCHED-CALIBRATION AUDIT
# =============================================================================

matched_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    p = make_scenario(
        scenario_name
    )

    linear = derived_quantities(
        p
    )

    logit = derived_logit(
        p,
        beta=BETA_MATCH,
        anchor_diesel=False,
        qbar_fixed=QBAR_MATCH,
    )

    stable_linear = [
        name
        for name, flag in pure_stability_report(
            p
        ).items()
        if flag
    ]

    stable_logit = pure_stability_from_derived(
        logit
    )

    matched_rows.append({
        "Scenario": scenario_name,

        "beta_match": BETA_MATCH,
        "qbar_match": QBAR_MATCH,

        "U_H": linear["U_H"],
        "U_E": linear["U_E"],
        "U_D": linear["U_D"],

        "q_H_linear": linear["q_H"],
        "q_H_logit": logit["q_H"],
        "q_H_difference": (
            logit["q_H"]
            - linear["q_H"]
        ),

        "q_E_linear": linear["q_E"],
        "q_E_logit": logit["q_E"],
        "q_E_difference": (
            logit["q_E"]
            - linear["q_E"]
        ),

        "q_D_linear": linear["q_D"],
        "q_D_logit": logit["q_D"],
        "q_D_difference": (
            logit["q_D"]
            - linear["q_D"]
        ),

        "pi_H_B_linear": linear["pi_H_B"],
        "pi_H_B_logit": logit["pi_H_B"],

        "pi_E_B_linear": linear["pi_E_B"],
        "pi_E_B_logit": logit["pi_E_B"],

        "pi_D_B_linear": linear["pi_D_B"],
        "pi_D_B_logit": logit["pi_D_B"],

        "Delta_H_linear": linear["Delta_H"],
        "Delta_H_logit": logit["Delta_H"],

        "Delta_E_linear": linear["Delta_E"],
        "Delta_E_logit": logit["Delta_E"],

        "Delta_D_linear": linear["Delta_D"],
        "Delta_D_logit": logit["Delta_D"],

        "y_HE_linear": (
            (
                linear["pi_E_B"]
                - linear["pi_H_B"]
            )
            / (
                linear["Gamma_H1"]
                - linear["Gamma_E1"]
            )
        ),

        "y_HE_logit": y_HE_threshold(
            logit
        ),

        "Stable_linear": (
            " | ".join(
                stable_linear
            )
        ),

        "Stable_logit": (
            " | ".join(
                stable_logit
            )
        ),
    })


matched_df = pd.DataFrame(
    matched_rows
)

matched_df.to_csv(
    CSV_D2A
    / "matched_linear_vs_logit_audit.csv",
    index=False,
)


# =============================================================================
# 19. beta-SENSITIVITY SWEEP
#
# q_D is held at exactly 1.20 by adjusting qbar(beta).
# =============================================================================

sweep_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    p = make_scenario(
        scenario_name
    )

    for beta in BETA_GRID:

        d = derived_logit(
            p,
            beta=float(
                beta
            ),
            anchor_diesel=True,
        )

        stable = pure_stability_from_derived(
            d
        )

        if len(
            stable
        ) == 1:

            stable_label = (
                stable[0]
            )

        elif len(
            stable
        ) == 0:

            stable_label = (
                "No pure LAS"
            )

        else:

            stable_label = (
                "Multiple: "
                + " | ".join(
                    stable
                )
            )

        sweep_rows.append({
            "Scenario": scenario_name,
            "beta": float(beta),
            "qbar_anchored": d["qbar"],

            "q_H": d["q_H"],
            "q_E": d["q_E"],
            "q_D": d["q_D"],

            "pi_H_B": d["pi_H_B"],
            "pi_E_B": d["pi_E_B"],
            "pi_D_B": d["pi_D_B"],

            "pi_H_A": d["pi_H_A"],
            "pi_E_A": d["pi_E_A"],
            "pi_D_A": d["pi_D_A"],

            "Delta_H": d["Delta_H"],
            "Delta_E": d["Delta_E"],
            "Delta_D": d["Delta_D"],

            "y_HE_star": y_HE_threshold(
                d
            ),

            "Stable_pure": stable_label,
        })


sweep_df = pd.DataFrame(
    sweep_rows
)

sweep_df.to_csv(
    CSV_D2A
    / "beta_sensitivity_anchored_diesel.csv",
    index=False,
)


# =============================================================================
# 20. REGIME SEGMENTS
# =============================================================================

segment_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = (
        sweep_df[
            sweep_df[
                "Scenario"
            ]
            == scenario_name
        ]
        .sort_values(
            "beta"
        )
        .reset_index(
            drop=True
        )
    )

    start_idx = 0
    current_label = (
        sub.loc[
            0,
            "Stable_pure"
        ]
    )

    for i in range(
        1,
        len(sub),
    ):

        label = (
            sub.loc[
                i,
                "Stable_pure"
            ]
        )

        if label != current_label:

            segment_rows.append({
                "Scenario": scenario_name,
                "Stable_pure": current_label,
                "beta_min": float(
                    sub.loc[
                        start_idx,
                        "beta"
                    ]
                ),
                "beta_max": float(
                    sub.loc[
                        i - 1,
                        "beta"
                    ]
                ),
            })

            start_idx = i
            current_label = label

    segment_rows.append({
        "Scenario": scenario_name,
        "Stable_pure": current_label,
        "beta_min": float(
            sub.loc[
                start_idx,
                "beta"
            ]
        ),
        "beta_max": float(
            sub.loc[
                len(sub) - 1,
                "beta"
            ]
        ),
    })


segment_df = pd.DataFrame(
    segment_rows
)

segment_df.to_csv(
    CSV_D2A
    / "beta_regime_segments.csv",
    index=False,
)


# =============================================================================
# 21. SUMMARY STATISTICS
# =============================================================================

summary_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = sweep_df[
        sweep_df[
            "Scenario"
        ]
        == scenario_name
    ]

    summary_rows.append({
        "Scenario": scenario_name,

        "beta_min": float(
            sub["beta"].min()
        ),
        "beta_max": float(
            sub["beta"].max()
        ),

        "q_H_min": float(
            sub["q_H"].min()
        ),
        "q_H_max": float(
            sub["q_H"].max()
        ),

        "q_E_min": float(
            sub["q_E"].min()
        ),
        "q_E_max": float(
            sub["q_E"].max()
        ),

        "q_D_min": float(
            sub["q_D"].min()
        ),
        "q_D_max": float(
            sub["q_D"].max()
        ),

        "y_HE_min": float(
            np.nanmin(
                sub["y_HE_star"]
            )
        ),

        "y_HE_max": float(
            np.nanmax(
                sub["y_HE_star"]
            )
        ),

        "Delta_H_min": float(
            sub["Delta_H"].min()
        ),
        "Delta_H_max": float(
            sub["Delta_H"].max()
        ),

        "Delta_E_min": float(
            sub["Delta_E"].min()
        ),
        "Delta_E_max": float(
            sub["Delta_E"].max()
        ),

        "Delta_D_min": float(
            sub["Delta_D"].min()
        ),
        "Delta_D_max": float(
            sub["Delta_D"].max()
        ),

        "Distinct_stable_regimes": (
            " | ".join(
                sorted(
                    set(
                        sub[
                            "Stable_pure"
                        ]
                    )
                )
            )
        ),
    })


summary_df = pd.DataFrame(
    summary_rows
)

summary_df.to_csv(
    CSV_D2A
    / "beta_sensitivity_summary.csv",
    index=False,
)


# =============================================================================
# 22. FIGURE — UTILIZATION RESPONSE
# =============================================================================

fig, ax = plt.subplots(
    figsize=(
        6.7,
        4.9,
    )
)

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = sweep_df[
        sweep_df[
            "Scenario"
        ]
        == scenario_name
    ]

    # H and E are identical in passenger-facing utility within each scenario.
    ax.plot(
        sub["beta"],
        sub["q_H"],
        linewidth=1.6,
        label=(
            f"{scenario_name}: "
            r"$q_H^L=q_E^L$"
        ),
    )

ax.axhline(
    Q_D_TARGET,
    linestyle="--",
    linewidth=1.0,
    color="0.30",
    label=r"Anchored diesel utilization, $q_D=1.20$",
)

ax.axvline(
    BETA_MATCH,
    linestyle=":",
    linewidth=1.0,
    color="0.20",
    label=r"Matched benchmark, $\beta=\ln(1.5)$",
)

ax.set_xlabel(
    r"Logit sensitivity parameter, $\beta$"
)

ax.set_ylabel(
    "Passenger utilization (boardings/RVK)"
)

ax.set_title(
    "Bounded passenger-utilization sensitivity",
    fontweight="semibold",
)

ax.grid(
    False
)

ax.legend(
    frameon=False,
    fontsize=8.3,
)

fig.tight_layout()

fig.savefig(
    FIG_D2A
    / "bounded_utilization_beta_response.png",
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    FIG_D2A
    / "bounded_utilization_beta_response.pdf",
    bbox_inches="tight",
)

plt.show()
plt.close(
    fig
)


# =============================================================================
# 23. FIGURE — H-E POLICY THRESHOLD
# =============================================================================

fig, ax = plt.subplots(
    figsize=(
        6.7,
        4.9,
    )
)

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = sweep_df[
        sweep_df[
            "Scenario"
        ]
        == scenario_name
    ]

    ax.plot(
        sub["beta"],
        sub["y_HE_star"],
        linewidth=1.6,
        label=scenario_name,
    )

ax.axhline(
    0.0,
    linestyle="--",
    linewidth=0.8,
    color="0.40",
)

ax.axhline(
    1.0,
    linestyle="--",
    linewidth=0.8,
    color="0.40",
)

ax.axvline(
    BETA_MATCH,
    linestyle=":",
    linewidth=1.0,
    color="0.20",
)

ax.set_xlabel(
    r"Logit sensitivity parameter, $\beta$"
)

ax.set_ylabel(
    r"H--E payoff threshold, $y_{HE}^{*}$"
)

ax.set_title(
    "Policy threshold under bounded passenger utilization",
    fontweight="semibold",
)

ax.grid(
    False
)

ax.legend(
    frameon=False
)

fig.tight_layout()

fig.savefig(
    FIG_D2A
    / "bounded_utilization_yHE_threshold.png",
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    FIG_D2A
    / "bounded_utilization_yHE_threshold.pdf",
    bbox_inches="tight",
)

plt.show()
plt.close(
    fig
)


# =============================================================================
# 24. PRINT AUDIT
# =============================================================================

print("=" * 108)
print("PHASE 4D-2A — BOUNDED PASSENGER-UTILIZATION CALIBRATION AUDIT")
print("=" * 108)

print("\nA. MATCHED LOGIT CALIBRATION")
print("-" * 108)

print(
    f"beta_match = ln(1.5) = "
    f"{BETA_MATCH:.9f}"
)

print(
    f"qbar_match = "
    f"{QBAR_MATCH:.6f} boardings/RVK"
)

for _, row in matched_df.iterrows():

    print(
        f"\n{row['Scenario']}"
    )

    print(
        f"  q_H: linear={row['q_H_linear']:.6f}, "
        f"Logit={row['q_H_logit']:.6f}, "
        f"diff={row['q_H_difference']:+.6f}"
    )

    print(
        f"  q_E: linear={row['q_E_linear']:.6f}, "
        f"Logit={row['q_E_logit']:.6f}, "
        f"diff={row['q_E_difference']:+.6f}"
    )

    print(
        f"  q_D: linear={row['q_D_linear']:.6f}, "
        f"Logit={row['q_D_logit']:.6f}, "
        f"diff={row['q_D_difference']:+.6f}"
    )

    print(
        f"  y_HE*: linear={row['y_HE_linear']:.6f}, "
        f"Logit={row['y_HE_logit']:.6f}"
    )

    print(
        f"  stable pure: "
        f"linear={row['Stable_linear']} | "
        f"Logit={row['Stable_logit']}"
    )


print("\nB. beta-SENSITIVITY REGIME SEGMENTS")
print("-" * 108)

for _, row in segment_df.iterrows():

    print(
        f"{row['Scenario']}: "
        f"beta in "
        f"[{row['beta_min']:.3f}, "
        f"{row['beta_max']:.3f}] "
        f"-> {row['Stable_pure']}"
    )


print("\nC. beta-SENSITIVITY SUMMARY")
print("-" * 108)

for _, row in summary_df.iterrows():

    print(
        f"\n{row['Scenario']}"
    )

    print(
        f"  q_H=q_E range: "
        f"{row['q_H_min']:.4f} "
        f"to {row['q_H_max']:.4f}"
    )

    print(
        f"  q_D range: "
        f"{row['q_D_min']:.4f} "
        f"to {row['q_D_max']:.4f}"
    )

    print(
        f"  y_HE* range: "
        f"{row['y_HE_min']:.4f} "
        f"to {row['y_HE_max']:.4f}"
    )

    print(
        f"  stable regime(s): "
        f"{row['Distinct_stable_regimes']}"
    )


print("\nD. DIMENSIONAL / MODELING NOTE")
print("-" * 108)
print(
    "  The bounded specification changes q_i, fare revenue, emissions, "
    "operator payoffs, and Delta_i consistently."
)
print(
    "  The linear-demand CS=q^2/(2 gamma_1 beta_t) formula is NOT reused "
    "under Logit."
)
print(
    "  This robustness test concerns strategic transition patterns; the PA "
    "replicator depends on Delta_i, so no absolute Logit consumer-surplus "
    "formula is needed for the dynamic comparison."
)

print("\nFiles saved under:")
print(
    f"  {OUT_DIR.resolve()}"
)

print("\nCSV RESULTS")
print("  matched_linear_vs_logit_audit.csv")
print("  beta_sensitivity_anchored_diesel.csv")
print("  beta_regime_segments.csv")
print("  beta_sensitivity_summary.csv")

print("\nPhase 4D-2A completed.")
