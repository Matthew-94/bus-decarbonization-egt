# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

PHASE4D1B_DIR = Path("Phase4D1B_operational_infrastructure_frontier")
PHASE4D1B_DIR.mkdir(parents=True, exist_ok=True)

CSV_D1B_DIR = PHASE4D1B_DIR / "csv_results"
CSV_D1B_DIR.mkdir(parents=True, exist_ok=True)

DETAIL_DIR = CSV_D1B_DIR / "grid_IC_level_results"
DETAIL_DIR.mkdir(parents=True, exist_ok=True)

CONSENSUS_DIR = CSV_D1B_DIR / "grid_consensus_results"
CONSENSUS_DIR.mkdir(parents=True, exist_ok=True)

MATRIX_DIR = CSV_D1B_DIR / "plotting_matrices"
MATRIX_DIR.mkdir(parents=True, exist_ok=True)

FIG_D1B_DIR = PHASE4D1B_DIR / "figures"
FIG_D1B_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION FIGURE STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.8,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. STRUCTURED 24-POINT INITIAL-CONDITION DESIGN
# =============================================================================

TECH_COMPOSITIONS = [
    ("D-heavy, slight E tilt",   0.05, 0.10),
    ("D-heavy, slight H tilt",   0.10, 0.05),
    ("E-heavy",                  0.05, 0.75),
    ("H-heavy",                  0.75, 0.05),
    ("E-leaning mixed",          0.20, 0.55),
    ("H-leaning mixed",          0.55, 0.20),
    ("Three-way balanced",       0.30, 0.30),
    ("Green-heavy H/E balanced", 0.45, 0.45),
]

POLICY_START_LEVELS = [
    ("Low policy",    0.10),
    ("Medium policy", 0.50),
    ("High policy",   0.90),
]

IC_ROWS = []
IC_ARRAY_ROWS = []

ic_counter = 1

for composition_label, z0, w0 in TECH_COMPOSITIONS:

    D0 = 1.0 - z0 - w0

    for policy_label, y0 in POLICY_START_LEVELS:

        ic_name = f"IC{ic_counter:02d}"

        IC_ROWS.append({
            "IC": ic_name,
            "Composition_group": composition_label,
            "Policy_group": policy_label,
            "z0_H": z0,
            "w0_E": w0,
            "D0": D0,
            "y0": y0,
        })

        IC_ARRAY_ROWS.append(
            [z0, w0, y0]
        )

        ic_counter += 1

IC_DF = pd.DataFrame(IC_ROWS)
IC_ARRAY = np.asarray(IC_ARRAY_ROWS, dtype=float)
IC_NAMES = list(IC_DF["IC"])
N_IC = len(IC_NAMES)

assert N_IC == 24

IC_DF.to_csv(
    CSV_D1B_DIR / "initial_conditions_24.csv",
    index=False,
)


# =============================================================================
# 15. AUDITED INFRASTRUCTURE SHAPE
# =============================================================================

LAMBDA_INF = 4.0
A_ETA = 0.10
A_ZETA = 0.50
XBAR_INF = 0.70


def omega_infrastructure(
    x,
    F_inf,
):
    """
    Moderate nonlinear infrastructure burden in CAD/RVK.

    eta  = A_ETA  * F_inf
    zeta = A_ZETA * F_inf
    """

    x = np.asarray(
        x,
        dtype=float,
    )

    eta = (
        A_ETA
        * F_inf
    )

    zeta = (
        A_ZETA
        * F_inf
    )

    return (
        F_inf
        * np.exp(
            -LAMBDA_INF * x
        )
        + eta * x
        + zeta
        * np.maximum(
            0.0,
            x - XBAR_INF,
        ) ** 2
    )


def omega_per_unit_F(
    x,
):

    return float(
        np.exp(
            -LAMBDA_INF * x
        )
        + A_ETA * x
        + A_ZETA
        * max(
            0.0,
            x - XBAR_INF,
        ) ** 2
    )


# =============================================================================
# 16. SCENARIO-SPECIFIC FRONTIER RANGES
#
# Chosen from the Phase 4D-1A exact break-even audit:
#
#   S1: rho_E* ≈ 2.65 vs H
#   S2: rho_E* ≈ 1.96 vs H
#   S3: rho_H* ≈ 1.095 vs E
#
# The F_inf ranges extend materially beyond the audited local break-even
# values so that basin/path-dependence and pure-corner loss can both appear.
# =============================================================================

GRID_N = 31

FRONTIER_CONFIGS = {

    "S1": {
        "focal": "E",
        "rho_param": "rho_E",
        "rho_values": np.linspace(
            1.0,
            3.0,
            GRID_N,
        ),
        "F_values": np.linspace(
            0.0,
            3.0,
            GRID_N,
        ),
        "x_label": r"Electric service-equivalency factor, $\rho_E$",
        "y_label": r"Electric infrastructure-entry scale, $F_E^{\mathrm{inf}}$ (CAD/RVK)",
        "title": "Baseline conditions",
    },

    "S2": {
        "focal": "E",
        "rho_param": "rho_E",
        "rho_values": np.linspace(
            1.0,
            2.5,
            GRID_N,
        ),
        "F_values": np.linspace(
            0.0,
            2.0,
            GRID_N,
        ),
        "x_label": r"Electric service-equivalency factor, $\rho_E$",
        "y_label": r"Electric infrastructure-entry scale, $F_E^{\mathrm{inf}}$ (CAD/RVK)",
        "title": "Intermediate conditions",
    },

    "S3": {
        "focal": "H",
        "rho_param": "rho_H",
        "rho_values": np.linspace(
            1.0,
            1.35,
            GRID_N,
        ),
        "F_values": np.linspace(
            0.0,
            0.80,
            GRID_N,
        ),
        "x_label": r"Hydrogen service-equivalency factor, $\rho_H$",
        "y_label": r"Hydrogen infrastructure-entry scale, $F_H^{\mathrm{inf}}$ (CAD/RVK)",
        "title": "Advanced conditions",
    },
}


# =============================================================================
# 17. NUMERICAL SETTINGS
# =============================================================================

# Adaptive horizons reduce false "unresolved" labels near basin boundaries.
ADAPTIVE_HORIZONS = [
    300.0,
    800.0,
    1600.0,
    3000.0,
]

PURE_SHARE_TOL = 0.98
RHS_STATIONARITY_TOL = 1e-7

# Tiny solver drift is projected back to the simplex only when genuinely small.
SIMPLEX_CLEANUP_TOL = 1e-4


# =============================================================================
# 18. EXTENDED PAYOFFS
# =============================================================================

def expected_operator_payoffs_extended(
    z,
    w,
    y,
    p,
    F_H_inf=0.0,
    F_E_inf=0.0,
):
    """
    State-dependent expected operator payoffs.

    rho_i enters derived_quantities(p) through annualized capital cost only.
    Infrastructure burden is then subtracted from the corresponding
    technology's CAD/RVK payoff.
    """

    d = derived_quantities(
        p
    )

    Pi_H = (
        d["pi_H_B"]
        + y * p.S_H * d["q_H"]
        - omega_infrastructure(
            z,
            F_H_inf,
        )
    )

    Pi_E = (
        d["pi_E_B"]
        + y * p.S_E * d["q_E"]
        - omega_infrastructure(
            w,
            F_E_inf,
        )
    )

    Pi_D = (
        d["pi_D_B"]
        - y * p.T_D * d["q_D"]
    )

    return (
        Pi_H,
        Pi_E,
        Pi_D,
    )


# =============================================================================
# 19. BATCHED 24-IC EXTENDED REPLICATOR DYNAMICS
# =============================================================================

def batch_rhs_extended(
    tau,
    flat_state,
    p,
    n_ic,
    F_H_inf,
    F_E_inf,
):

    X = np.asarray(
        flat_state,
        dtype=float,
    ).reshape(
        n_ic,
        3,
    )

    z = X[:, 0]
    w = X[:, 1]
    y = X[:, 2]

    D = (
        1.0
        - z
        - w
    )

    (
        Pi_H,
        Pi_E,
        Pi_D,
    ) = expected_operator_payoffs_extended(
        z=z,
        w=w,
        y=y,
        p=p,
        F_H_inf=F_H_inf,
        F_E_inf=F_E_inf,
    )

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + D * Pi_D
    )

    d = derived_quantities(
        p
    )

    # Infrastructure and rho extensions are operator-side frictions.
    # PA incremental policy payoffs remain the frozen Delta_i expressions.
    P = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    dz = (
        p.eta_TO
        * z
        * (
            Pi_H
            - Pi_bar
        )
    )

    dw = (
        p.eta_TO
        * w
        * (
            Pi_E
            - Pi_bar
        )
    )

    dy = (
        p.eta_PA
        * y
        * (
            1.0 - y
        )
        * P
    )

    return np.column_stack(
        [dz, dw, dy]
    ).reshape(-1)


# =============================================================================
# 20. FINAL-STATE SANITIZATION
# =============================================================================

def sanitize_state(
    state,
):

    z, w, y = map(
        float,
        state,
    )

    y = float(
        np.clip(
            y,
            0.0,
            1.0,
        )
    )

    # Do not silently repair material errors.
    if (
        z < -SIMPLEX_CLEANUP_TOL
        or w < -SIMPLEX_CLEANUP_TOL
        or z + w
        > 1.0 + SIMPLEX_CLEANUP_TOL
    ):
        raise RuntimeError(
            "Material simplex violation: "
            f"z={z:.12f}, "
            f"w={w:.12f}, "
            f"z+w={z+w:.12f}"
        )

    z = max(
        0.0,
        z,
    )

    w = max(
        0.0,
        w,
    )

    if z + w > 1.0:

        total = (
            z + w
        )

        z = (
            z / total
        )

        w = (
            w / total
        )

    D = max(
        0.0,
        1.0 - z - w,
    )

    return (
        z,
        w,
        D,
        y,
    )


# =============================================================================
# 21. SINGLE-IC RHS NORM
# =============================================================================

def single_rhs_norm(
    z,
    w,
    y,
    p,
    F_H_inf,
    F_E_inf,
):

    rhs = batch_rhs_extended(
        0.0,
        np.array(
            [z, w, y],
            dtype=float,
        ),
        p=p,
        n_ic=1,
        F_H_inf=F_H_inf,
        F_E_inf=F_E_inf,
    )

    return float(
        np.max(
            np.abs(
                rhs
            )
        )
    )


# =============================================================================
# 22. PER-IC CLASSIFICATION
# =============================================================================

def classify_final_state(
    state,
    p,
    F_H_inf,
    F_E_inf,
):

    z, w, D, y = sanitize_state(
        state
    )

    rhs_norm = single_rhs_norm(
        z=z,
        w=w,
        y=y,
        p=p,
        F_H_inf=F_H_inf,
        F_E_inf=F_E_inf,
    )

    if z >= PURE_SHARE_TOL:
        technology_class = "H"

    elif w >= PURE_SHARE_TOL:
        technology_class = "E"

    elif D >= PURE_SHARE_TOL:
        technology_class = "D"

    elif rhs_norm <= RHS_STATIONARITY_TOL:
        technology_class = "Mixed"

    else:
        technology_class = "Unresolved"

    return {
        "Final_H": z,
        "Final_E": w,
        "Final_D": D,
        "Final_y": y,

        "Fleet_share_sum": (
            z + w + D
        ),

        "RHS_norm": rhs_norm,
        "Technology_class": technology_class,
    }


# =============================================================================
# 23. ADAPTIVE 24-IC SOLVER
# =============================================================================

def solve_adaptive_24IC(
    p,
    F_H_inf,
    F_E_inf,
):

    X_current = np.array(
        IC_ARRAY,
        dtype=float,
        copy=True,
    )

    current_tau = 0.0
    effective_tau = ADAPTIVE_HORIZONS[-1]

    final_results = None

    for target_tau in ADAPTIVE_HORIZONS:

        sol = solve_ivp(
            fun=lambda tau, flat_state: batch_rhs_extended(
                tau=tau,
                flat_state=flat_state,
                p=p,
                n_ic=N_IC,
                F_H_inf=F_H_inf,
                F_E_inf=F_E_inf,
            ),
            t_span=(
                current_tau,
                target_tau,
            ),
            y0=X_current.reshape(-1),
            t_eval=[
                target_tau
            ],
            method="DOP853",
            rtol=1e-9,
            atol=1e-11,
        )

        if not sol.success:

            raise RuntimeError(
                sol.message
            )

        X_current = (
            sol.y[:, -1]
            .reshape(
                N_IC,
                3,
            )
        )

        current_tau = (
            target_tau
        )

        final_results = []

        unresolved_found = False

        for i in range(
            N_IC
        ):

            result = classify_final_state(
                X_current[i],
                p=p,
                F_H_inf=F_H_inf,
                F_E_inf=F_E_inf,
            )

            if (
                result[
                    "Technology_class"
                ]
                == "Unresolved"
            ):
                unresolved_found = True

            final_results.append(
                result
            )

        if not unresolved_found:

            effective_tau = (
                target_tau
            )

            break

    return (
        X_current,
        final_results,
        effective_tau,
    )


# =============================================================================
# 24. CONSENSUS CLASSIFICATION
# =============================================================================

def consensus_classification(
    point_df,
):

    classes = list(
        point_df[
            "Technology_class"
        ]
    )

    unique_classes = set(
        classes
    )

    frac_H = float(
        np.mean(
            point_df[
                "Technology_class"
            ]
            == "H"
        )
    )

    frac_E = float(
        np.mean(
            point_df[
                "Technology_class"
            ]
            == "E"
        )
    )

    frac_D = float(
        np.mean(
            point_df[
                "Technology_class"
            ]
            == "D"
        )
    )

    frac_Mixed = float(
        np.mean(
            point_df[
                "Technology_class"
            ]
            == "Mixed"
        )
    )

    frac_Unresolved = float(
        np.mean(
            point_df[
                "Technology_class"
            ]
            == "Unresolved"
        )
    )

    if frac_Unresolved > 0.0:

        consensus = (
            "Persistent/slow"
        )

    elif len(unique_classes) == 1:

        only = next(
            iter(
                unique_classes
            )
        )

        if only == "H":
            consensus = "Robust H"

        elif only == "E":
            consensus = "Robust E"

        elif only == "D":
            consensus = "Robust D"

        elif only == "Mixed":

            # Confirm that all stationary mixed states are approximately the same.
            state_matrix = point_df[
                [
                    "Final_H",
                    "Final_E",
                    "Final_D",
                    "Final_y",
                ]
            ].to_numpy(
                dtype=float
            )

            spread = float(
                np.max(
                    np.ptp(
                        state_matrix,
                        axis=0,
                    )
                )
            )

            if spread <= 1e-3:
                consensus = "Robust mixed"
            else:
                consensus = "Path-dependent"

        else:
            consensus = "Path-dependent"

    else:

        consensus = (
            "Path-dependent"
        )

    return {
        "Consensus": consensus,

        "Fraction_H": frac_H,
        "Fraction_E": frac_E,
        "Fraction_D": frac_D,
        "Fraction_Mixed": frac_Mixed,
        "Fraction_Unresolved": frac_Unresolved,

        "Mean_final_H": float(
            point_df[
                "Final_H"
            ].mean()
        ),

        "Mean_final_E": float(
            point_df[
                "Final_E"
            ].mean()
        ),

        "Mean_final_D": float(
            point_df[
                "Final_D"
            ].mean()
        ),

        "Mean_final_y": float(
            point_df[
                "Final_y"
            ].mean()
        ),

        "Max_RHS_norm": float(
            point_df[
                "RHS_norm"
            ].max()
        ),
    }


# =============================================================================
# 25. MAP CODEBOOK
# =============================================================================

CLASS_ORDER = [
    "Robust D",
    "Robust E",
    "Robust H",
    "Robust mixed",
    "Path-dependent",
    "Persistent/slow",
]

CLASS_TO_CODE = {
    label: i
    for i, label in enumerate(
        CLASS_ORDER
    )
}

CODE_TO_CLASS = {
    code: label
    for label, code in CLASS_TO_CODE.items()
}

CLASS_COLORS = {
    "Robust D": "#A9A9A9",
    "Robust E": "#6F8FA6",
    "Robust H": "#566B5C",
    "Robust mixed": "#CFCAC1",
    "Path-dependent": "#B58A7B",
    "Persistent/slow": "#EFEDE8",
}

pd.DataFrame(
    [
        {
            "Code": CLASS_TO_CODE[label],
            "Class": label,
            "Color": CLASS_COLORS[label],
        }
        for label in CLASS_ORDER
    ]
).to_csv(
    CSV_D1B_DIR
    / "outcome_codebook.csv",
    index=False,
)


# =============================================================================
# 26. BENCHMARK 24-IC CERTIFICATION
# =============================================================================

benchmark_rows = []

print("=" * 108)
print("PHASE 4D-1B — BENCHMARK 24-IC EXTENSION NESTING CHECK")
print("=" * 108)

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    base_p = make_scenario(
        scenario_name
    )

    (
        X_final,
        results,
        effective_tau,
    ) = solve_adaptive_24IC(
        p=base_p,
        F_H_inf=0.0,
        F_E_inf=0.0,
    )

    point_rows = []

    for i, ic_name in enumerate(
        IC_NAMES
    ):

        row = {
            "Scenario": scenario_name,
            "IC": ic_name,
            "rho_H": base_p.rho_H,
            "rho_E": base_p.rho_E,
            "F_H_inf": 0.0,
            "F_E_inf": 0.0,
            "Effective_tau": effective_tau,
            **results[i],
        }

        benchmark_rows.append(
            row
        )

        point_rows.append(
            row
        )

    point_df = pd.DataFrame(
        point_rows
    )

    consensus = consensus_classification(
        point_df
    )

    print(
        f"\n{scenario_name}: "
        f"{consensus['Consensus']}"
    )

    print(
        f"  mean final H={consensus['Mean_final_H']:.6f}, "
        f"E={consensus['Mean_final_E']:.6f}, "
        f"D={consensus['Mean_final_D']:.6f}, "
        f"y={consensus['Mean_final_y']:.6f}"
    )


benchmark_df = pd.DataFrame(
    benchmark_rows
)

benchmark_df.to_csv(
    CSV_D1B_DIR
    / "benchmark_24IC_extension_nesting_check.csv",
    index=False,
)


# =============================================================================
# 27. LOCAL PURE-CORNER STABILITY GUIDE
#
# This is NOT used to classify the simulation results.
# It is only a theoretical overlay for interpretation.
#
# For the focal technology at x=1 and y=1:
#
#   remaining private margin after rho
#       = baseline focal-vs-closest gap
#         - (rho-1)c_cap
#
# and
#
#   Omega_i(1) = F_inf * omega_per_unit_F(1).
#
# Therefore:
#
#   F_inf^corner(rho)
#       = remaining_margin / omega_per_unit_F(1).
# =============================================================================

def pure_corner_frontier(
    scenario_name,
    rho_values,
):

    p = make_scenario(
        scenario_name
    )

    d = derived_quantities(
        p
    )

    if scenario_name in {
        "S1",
        "S2",
    }:

        focal = "E"

        focal_payoff = (
            d["pi_E_B"]
            + p.S_E * d["q_E"]
        )

        competitors = {
            "H": (
                d["pi_H_B"]
                + p.S_H * d["q_H"]
            ),
            "D": (
                d["pi_D_B"]
                - p.T_D * d["q_D"]
            ),
        }

        cap_base = (
            d["cap_E"]
        )

    else:

        focal = "H"

        focal_payoff = (
            d["pi_H_B"]
            + p.S_H * d["q_H"]
        )

        competitors = {
            "E": (
                d["pi_E_B"]
                + p.S_E * d["q_E"]
            ),
            "D": (
                d["pi_D_B"]
                - p.T_D * d["q_D"]
            ),
        }

        cap_base = (
            d["cap_H"]
        )

    closest_name = max(
        competitors,
        key=competitors.get,
    )

    closest_payoff = (
        competitors[
            closest_name
        ]
    )

    baseline_gap = (
        focal_payoff
        - closest_payoff
    )

    shape_at_one = (
        omega_per_unit_F(
            1.0
        )
    )

    F_values = (
        baseline_gap
        - (
            rho_values
            - 1.0
        )
        * cap_base
    ) / shape_at_one

    return (
        F_values,
        focal,
        closest_name,
    )


# =============================================================================
# 28. RUN ONE SCENARIO FRONTIER
# =============================================================================

def run_frontier(
    scenario_name,
    config,
):

    base_p = make_scenario(
        scenario_name
    )

    rho_values = np.asarray(
        config[
            "rho_values"
        ],
        dtype=float,
    )

    F_values = np.asarray(
        config[
            "F_values"
        ],
        dtype=float,
    )

    detail_rows = []
    consensus_rows = []

    outcome_matrix = np.full(
        (
            len(F_values),
            len(rho_values),
        ),
        CLASS_TO_CODE[
            "Persistent/slow"
        ],
        dtype=int,
    )

    total_points = (
        len(rho_values)
        * len(F_values)
    )

    print(
        f"\nRunning {scenario_name}: "
        f"{len(rho_values)} x {len(F_values)} "
        f"= {total_points} grid points, "
        f"{N_IC} ICs per point"
    )

    for iy, F_inf in enumerate(
        F_values
    ):

        for ix, rho_value in enumerate(
            rho_values
        ):

            p = replace(
                base_p,
                **{
                    config[
                        "rho_param"
                    ]: float(
                        rho_value
                    )
                },
            )

            if config["focal"] == "E":

                F_H_inf = 0.0
                F_E_inf = float(
                    F_inf
                )

            else:

                F_H_inf = float(
                    F_inf
                )
                F_E_inf = 0.0

            (
                X_final,
                results,
                effective_tau,
            ) = solve_adaptive_24IC(
                p=p,
                F_H_inf=F_H_inf,
                F_E_inf=F_E_inf,
            )

            point_rows = []

            for i, ic_name in enumerate(
                IC_NAMES
            ):

                meta = (
                    IC_DF[
                        IC_DF["IC"]
                        == ic_name
                    ]
                    .iloc[0]
                )

                row = {
                    "Scenario": scenario_name,

                    "Grid_ix": ix,
                    "Grid_iy": iy,

                    "Focal_technology": config["focal"],

                    "rho_param": config["rho_param"],
                    "rho_value": float(rho_value),

                    "F_inf_value_CAD_per_RVK": float(F_inf),

                    "F_H_inf": F_H_inf,
                    "F_E_inf": F_E_inf,

                    "IC": ic_name,

                    "z0_H": meta["z0_H"],
                    "w0_E": meta["w0_E"],
                    "D0": meta["D0"],
                    "y0": meta["y0"],

                    "Effective_tau": effective_tau,

                    **results[i],
                }

                detail_rows.append(
                    row
                )

                point_rows.append(
                    row
                )

            point_df = pd.DataFrame(
                point_rows
            )

            consensus = consensus_classification(
                point_df
            )

            consensus_row = {
                "Scenario": scenario_name,

                "Grid_ix": ix,
                "Grid_iy": iy,

                "Focal_technology": config["focal"],

                "rho_param": config["rho_param"],
                "rho_value": float(rho_value),

                "F_inf_value_CAD_per_RVK": float(F_inf),

                "Effective_tau": effective_tau,

                **consensus,
            }

            consensus_rows.append(
                consensus_row
            )

            outcome_matrix[
                iy,
                ix,
            ] = CLASS_TO_CODE[
                consensus[
                    "Consensus"
                ]
            ]

        print(
            f"  completed row "
            f"{iy + 1}/"
            f"{len(F_values)}"
        )

    return (
        pd.DataFrame(
            detail_rows
        ),
        pd.DataFrame(
            consensus_rows
        ),
        outcome_matrix,
    )


# =============================================================================
# 29. CLEAN FRONTIER PLOT
# =============================================================================

def plot_frontier(
    scenario_name,
    config,
    consensus_df,
    matrix,
):

    from matplotlib.colors import (
        ListedColormap,
        BoundaryNorm,
    )

    from matplotlib.patches import (
        Patch,
    )

    from matplotlib.lines import (
        Line2D,
    )

    rho_values = np.asarray(
        config[
            "rho_values"
        ],
        dtype=float,
    )

    F_values = np.asarray(
        config[
            "F_values"
        ],
        dtype=float,
    )

    colors = [
        CLASS_COLORS[
            label
        ]
        for label in CLASS_ORDER
    ]

    cmap = ListedColormap(
        colors
    )

    bounds = np.arange(
        -0.5,
        len(CLASS_ORDER) + 0.5,
        1.0,
    )

    norm = BoundaryNorm(
        bounds,
        cmap.N,
    )

    fig, ax = plt.subplots(
        figsize=(6.8, 5.5)
    )

    ax.pcolormesh(
        rho_values,
        F_values,
        matrix,
        cmap=cmap,
        norm=norm,
        shading="nearest",
        edgecolors="none",
        antialiased=False,
    )

    # Thin white regime boundaries.
    present_codes = sorted(
        int(v)
        for v in np.unique(
            matrix
        )
    )

    if len(
        present_codes
    ) > 1:

        levels = (
            np.array(
                present_codes[:-1],
                dtype=float,
            )
            + 0.5
        )

        ax.contour(
            rho_values,
            F_values,
            matrix,
            levels=levels,
            colors="white",
            linewidths=0.7,
        )

    # -------------------------------------------------------------------------
    # Pure-corner analytical stability guide
    # -------------------------------------------------------------------------

    F_corner, focal, closest = (
        pure_corner_frontier(
            scenario_name,
            rho_values,
        )
    )

    valid = (
        (F_corner >= F_values.min())
        & (F_corner <= F_values.max())
    )

    if np.any(
        valid
    ):

        ax.plot(
            rho_values[
                valid
            ],
            F_corner[
                valid
            ],
            linestyle="--",
            linewidth=1.1,
            color="#222222",
            label=(
                f"Local {focal}-corner "
                f"stability vs {closest}"
            ),
        )

    # Benchmark is always rho=1, F=0.
    ax.scatter(
        [1.0],
        [0.0],
        marker="*",
        s=85,
        facecolor="white",
        edgecolor="black",
        linewidth=0.9,
        zorder=6,
    )

    ax.annotate(
        "Benchmark",
        xy=(
            1.0,
            0.0,
        ),
        xytext=(
            8,
            8,
        ),
        textcoords="offset points",
        fontsize=8.6,
        va="bottom",
    )

    ax.set_xlabel(
        config[
            "x_label"
        ]
    )

    ax.set_ylabel(
        config[
            "y_label"
        ]
    )

    ax.set_title(
        config["title"]
        + "\nOperational non-equivalence and nonlinear infrastructure",
        fontweight="semibold",
        pad=8,
    )

    ax.set_xlim(
        rho_values.min(),
        rho_values.max(),
    )

    ax.set_ylim(
        F_values.min(),
        F_values.max(),
    )

    ax.grid(
        False
    )

    for spine in ax.spines.values():

        spine.set_linewidth(
            0.85
        )

    handles = []

    for code in present_codes:

        label = CODE_TO_CLASS[
            code
        ]

        handles.append(
            Patch(
                facecolor=CLASS_COLORS[label],
                edgecolor="black",
                linewidth=0.45,
                label=label,
            )
        )

    if np.any(
        valid
    ):

        handles.append(
            Line2D(
                [0],
                [0],
                linestyle="--",
                linewidth=1.1,
                color="#222222",
                label=(
                    f"Local {focal}-corner "
                    f"stability vs {closest}"
                ),
            )
        )

    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(
            0.5,
            -0.15,
        ),
        ncol=min(
            3,
            len(handles),
        ),
        frameon=False,
        fontsize=8.5,
    )

    fig.tight_layout()

    fig.savefig(
        FIG_D1B_DIR
        / f"{scenario_name}_operational_infrastructure_frontier.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )

    fig.savefig(
        FIG_D1B_DIR
        / f"{scenario_name}_operational_infrastructure_frontier.pdf",
        bbox_inches="tight",
        pad_inches=0.04,
    )

    plt.show()
    plt.close(
        fig
    )


# =============================================================================
# 30. RUN S1 / S2 / S3
# =============================================================================

map_summary_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    config = FRONTIER_CONFIGS[
        scenario_name
    ]

    (
        detail_df,
        consensus_df,
        matrix,
    ) = run_frontier(
        scenario_name,
        config,
    )

    detail_df.to_csv(
        DETAIL_DIR
        / f"{scenario_name}_operational_infrastructure_IC_level.csv",
        index=False,
    )

    consensus_df.to_csv(
        CONSENSUS_DIR
        / f"{scenario_name}_operational_infrastructure_consensus.csv",
        index=False,
    )

    matrix_df = pd.DataFrame(
        matrix,
        index=config["F_values"],
        columns=config["rho_values"],
    )

    matrix_df.index.name = (
        "F_inf_CAD_per_RVK"
    )

    matrix_df.columns.name = (
        config[
            "rho_param"
        ]
    )

    matrix_df.to_csv(
        MATRIX_DIR
        / f"{scenario_name}_operational_infrastructure_outcome_matrix.csv"
    )

    plot_frontier(
        scenario_name=scenario_name,
        config=config,
        consensus_df=consensus_df,
        matrix=matrix,
    )

    counts = (
        consensus_df[
            "Consensus"
        ]
        .value_counts()
        .to_dict()
    )

    row = {
        "Scenario": scenario_name,
        "Grid_points": len(
            consensus_df
        ),
    }

    for label in CLASS_ORDER:

        row[
            label
        ] = int(
            counts.get(
                label,
                0,
            )
        )

    map_summary_rows.append(
        row
    )


# =============================================================================
# 31. SAVE SUMMARY / CONFIGURATION
# =============================================================================

map_summary_df = pd.DataFrame(
    map_summary_rows
)

map_summary_df.to_csv(
    CSV_D1B_DIR
    / "map_level_outcome_summary.csv",
    index=False,
)

config_rows = []

for scenario_name, config in FRONTIER_CONFIGS.items():

    config_rows.append({
        "Scenario": scenario_name,
        "Focal_technology": config["focal"],

        "rho_param": config["rho_param"],
        "rho_min": float(
            np.min(
                config[
                    "rho_values"
                ]
            )
        ),
        "rho_max": float(
            np.max(
                config[
                    "rho_values"
                ]
            )
        ),

        "F_inf_min": float(
            np.min(
                config[
                    "F_values"
                ]
            )
        ),
        "F_inf_max": float(
            np.max(
                config[
                    "F_values"
                ]
            )
        ),

        "Grid_N": GRID_N,
        "N_initial_conditions": N_IC,

        "lambda_inf": LAMBDA_INF,
        "a_eta": A_ETA,
        "a_zeta": A_ZETA,
        "xbar_inf": XBAR_INF,

        "Pure_share_tolerance": PURE_SHARE_TOL,
        "RHS_stationarity_tolerance": RHS_STATIONARITY_TOL,

        "Adaptive_horizons": " | ".join(
            str(v)
            for v in ADAPTIVE_HORIZONS
        ),
    })

config_df = pd.DataFrame(
    config_rows
)

config_df.to_csv(
    CSV_D1B_DIR
    / "run_configuration.csv",
    index=False,
)


# =============================================================================
# 32. FINAL PRINT
# =============================================================================

print("\n")
print("=" * 108)
print("PHASE 4D-1B — OPERATIONAL / INFRASTRUCTURE FRONTIER COMPLETED")
print("=" * 108)

print(
    f"\nInitial conditions per grid point: "
    f"{N_IC}"
)

print(
    f"Grid resolution: "
    f"{GRID_N} x {GRID_N}"
)

print(
    "Adaptive horizons: "
    + ", ".join(
        str(v)
        for v in ADAPTIVE_HORIZONS
    )
)

print("\nMAP-LEVEL OUTCOME COUNTS")

for _, row in map_summary_df.iterrows():

    print(
        f"\n{row['Scenario']}"
    )

    for label in CLASS_ORDER:

        count = int(
            row[
                label
            ]
        )

        if count > 0:

            print(
                f"  {label}: "
                f"{count}"
            )


print("\nFiles saved under:")
print(
    f"  {PHASE4D1B_DIR.resolve()}"
)

print("\nCSV RESULTS")
print("  initial_conditions_24.csv")
print("  benchmark_24IC_extension_nesting_check.csv")
print("  grid_IC_level_results/*.csv")
print("  grid_consensus_results/*.csv")
print("  plotting_matrices/*.csv")
print("  map_level_outcome_summary.csv")
print("  run_configuration.csv")
print("  outcome_codebook.csv")

print("\nPhase 4D-1B completed.")
