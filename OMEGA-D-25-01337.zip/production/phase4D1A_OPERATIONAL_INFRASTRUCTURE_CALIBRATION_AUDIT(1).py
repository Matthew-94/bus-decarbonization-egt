# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================
# 12. OUTPUT FOLDERS
# =============================================================================

PHASE4D1A_DIR = Path("Phase4D1A_infrastructure_calibration_audit")
PHASE4D1A_DIR.mkdir(parents=True, exist_ok=True)

CSV_D1A_DIR = PHASE4D1A_DIR / "csv_results"
CSV_D1A_DIR.mkdir(parents=True, exist_ok=True)

FIG_D1A_DIR = PHASE4D1A_DIR / "figures"
FIG_D1A_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. CLEAN FIGURE STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.8,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. INFRASTRUCTURE SHAPE FAMILIES
#
# All families nest the baseline exactly because eta_i and zeta_i are tied
# proportionally to F_inf. Therefore when F_inf=0:
#
#     Omega_i(x) = 0 for every x.
#
# This avoids the undesirable situation in which a "zero entry cost" case
# still contains positive marginal/capacity costs.
# =============================================================================

INFRA_SHAPES = {

    "Entry-only": {
        "lambda_inf": 4.0,
        "a_eta": 0.00,
        "a_zeta": 0.00,
        "xbar": 0.70,
    },

    "Mild nonlinear": {
        "lambda_inf": 4.0,
        "a_eta": 0.05,
        "a_zeta": 0.25,
        "xbar": 0.70,
    },

    "Moderate nonlinear": {
        "lambda_inf": 4.0,
        "a_eta": 0.10,
        "a_zeta": 0.50,
        "xbar": 0.70,
    },
}


# =============================================================================
# 15. INFRASTRUCTURE BURDEN
# =============================================================================

def omega_infrastructure(
    x: np.ndarray | float,
    F_inf: float,
    lambda_inf: float,
    a_eta: float,
    a_zeta: float,
    xbar: float,
):
    """
    Reduced-form infrastructure burden in CAD/RVK.

    eta  = a_eta  * F_inf
    zeta = a_zeta * F_inf

    This preserves the original theoretical form while nesting the baseline
    exactly at F_inf = 0.
    """

    x = np.asarray(
        x,
        dtype=float,
    )

    eta = (
        a_eta
        * F_inf
    )

    zeta = (
        a_zeta
        * F_inf
    )

    return (
        F_inf * np.exp(
            -lambda_inf * x
        )
        + eta * x
        + zeta * np.maximum(
            0.0,
            x - xbar,
        ) ** 2
    )


def omega_shape_factor(
    x: float,
    shape: Dict[str, float],
) -> float:
    """
    Omega(x) / F_inf under the nested parameterization.
    """

    return float(
        np.exp(
            -shape["lambda_inf"] * x
        )
        + shape["a_eta"] * x
        + shape["a_zeta"] * max(
            0.0,
            x - shape["xbar"],
        ) ** 2
    )


# =============================================================================
# 16. BASELINE ACTIVE-POLICY PAYOFF MARGINS
#
# The infrastructure and rho_i audit is anchored to the active-policy corner
# because all three frozen benchmark scenarios have y -> 1.
# =============================================================================

scenario_margin_rows = []

for scenario_name in ["S1", "S2", "S3"]:

    p = make_scenario(
        scenario_name
    )

    d = derived_quantities(
        p
    )

    Pi_H_1 = (
        d["pi_H_B"]
        + p.S_H * d["q_H"]
    )

    Pi_E_1 = (
        d["pi_E_B"]
        + p.S_E * d["q_E"]
    )

    Pi_D_1 = (
        d["pi_D_B"]
        - p.T_D * d["q_D"]
    )

    payoff_dict = {
        "H": Pi_H_1,
        "E": Pi_E_1,
        "D": Pi_D_1,
    }

    ranking = sorted(
        payoff_dict.items(),
        key=lambda item: item[1],
        reverse=True,
    )

    dominant_tech = ranking[0][0]
    second_tech = ranking[1][0]

    dominant_payoff = ranking[0][1]
    second_payoff = ranking[1][1]

    closest_margin = (
        dominant_payoff
        - second_payoff
    )

    scenario_margin_rows.append({
        "Scenario": scenario_name,

        "Pi_H_y1": Pi_H_1,
        "Pi_E_y1": Pi_E_1,
        "Pi_D_y1": Pi_D_1,

        "Dominant_technology": dominant_tech,
        "Closest_competitor": second_tech,

        "Closest_active_payoff_margin_CAD_per_RVK": closest_margin,

        "cap_H_at_rho1": d["cap_H"],
        "cap_E_at_rho1": d["cap_E"],
        "cap_D_at_rho1": d["cap_D"],
    })


scenario_margin_df = pd.DataFrame(
    scenario_margin_rows
)

scenario_margin_df.to_csv(
    CSV_D1A_DIR
    / "baseline_active_policy_payoff_margins.csv",
    index=False,
)


# =============================================================================
# 17. EXACT rho BREAK-EVEN AUDIT
#
# rho_i ONLY changes annualized fleet-dependent acquisition cost.
#
# It does NOT multiply:
#   - fare revenue,
#   - q_i,
#   - delivered-RVK operating cost,
#   - emissions.
#
# For the benchmark dominant zero-emission technology:
#
#   Pi_i(rho_i)
#      = Pi_i(rho_i=1)
#        - (rho_i-1) c_i_cap(rho_i=1).
#
# Therefore its pairwise break-even rho is analytical.
# =============================================================================

rho_break_rows = []

for scenario_name in ["S1", "S2", "S3"]:

    p = make_scenario(
        scenario_name
    )

    d = derived_quantities(
        p
    )

    Pi = {
        "H": (
            d["pi_H_B"]
            + p.S_H * d["q_H"]
        ),
        "E": (
            d["pi_E_B"]
            + p.S_E * d["q_E"]
        ),
        "D": (
            d["pi_D_B"]
            - p.T_D * d["q_D"]
        ),
    }

    # S1/S2 benchmark winner = E.
    # S3 benchmark winner = H.
    focal = (
        "E"
        if scenario_name in {"S1", "S2"}
        else "H"
    )

    cap_base = (
        d["cap_E"]
        if focal == "E"
        else d["cap_H"]
    )

    for competitor in [
        tech
        for tech in ["H", "E", "D"]
        if tech != focal
    ]:

        gap = (
            Pi[focal]
            - Pi[competitor]
        )

        rho_star = (
            1.0
            + gap / cap_base
        )

        rho_break_rows.append({
            "Scenario": scenario_name,
            "Focal_technology": focal,
            "Competitor": competitor,

            "Focal_payoff_y1_rho1": Pi[focal],
            "Competitor_payoff_y1": Pi[competitor],

            "Pairwise_payoff_margin_CAD_per_RVK": gap,
            "Focal_capital_cost_at_rho1_CAD_per_RVK": cap_base,

            "rho_break_even": rho_star,
        })


rho_break_df = pd.DataFrame(
    rho_break_rows
)

rho_break_df.to_csv(
    CSV_D1A_DIR
    / "rho_pairwise_break_even_thresholds.csv",
    index=False,
)


# =============================================================================
# 18. rho STRESS TABLE
# =============================================================================

RHO_TEST_VALUES = [
    1.00,
    1.05,
    1.10,
    1.20,
    1.30,
    1.50,
    1.80,
    2.00,
    2.50,
    3.00,
]

rho_stress_rows = []

for scenario_name in ["S1", "S2", "S3"]:

    p = make_scenario(
        scenario_name
    )

    d = derived_quantities(
        p
    )

    focal = (
        "E"
        if scenario_name in {"S1", "S2"}
        else "H"
    )

    if focal == "E":

        focal_base = (
            d["pi_E_B"]
            + p.S_E * d["q_E"]
        )

        cap_base = d["cap_E"]

        competitors = {
            "H": (
                d["pi_H_B"]
                + p.S_H * d["q_H"]
            ),
            "D": (
                d["pi_D_B"]
                - p.T_D * d["q_D"]
            ),
        }

    else:

        focal_base = (
            d["pi_H_B"]
            + p.S_H * d["q_H"]
        )

        cap_base = d["cap_H"]

        competitors = {
            "E": (
                d["pi_E_B"]
                + p.S_E * d["q_E"]
            ),
            "D": (
                d["pi_D_B"]
                - p.T_D * d["q_D"]
            ),
        }

    for rho_value in RHO_TEST_VALUES:

        focal_payoff = (
            focal_base
            - (
                rho_value
                - 1.0
            )
            * cap_base
        )

        closest_competitor_name = max(
            competitors,
            key=competitors.get,
        )

        closest_competitor_payoff = (
            competitors[
                closest_competitor_name
            ]
        )

        remaining_margin = (
            focal_payoff
            - closest_competitor_payoff
        )

        rho_stress_rows.append({
            "Scenario": scenario_name,
            "Focal_technology": focal,
            "rho": rho_value,

            "Focal_payoff_y1_after_rho": focal_payoff,

            "Closest_competitor": closest_competitor_name,
            "Closest_competitor_payoff_y1": closest_competitor_payoff,

            "Remaining_margin_before_infrastructure_CAD_per_RVK":
                remaining_margin,
        })


rho_stress_df = pd.DataFrame(
    rho_stress_rows
)

rho_stress_df.to_csv(
    CSV_D1A_DIR
    / "rho_stress_remaining_payoff_margins.csv",
    index=False,
)


# =============================================================================
# 19. INFRASTRUCTURE SHAPE PROFILES
# =============================================================================

F_INF_TEST_VALUES = [
    0.00,
    0.10,
    0.25,
    0.50,
    1.00,
    1.50,
    2.00,
]

X_PROFILE = np.linspace(
    0.0,
    1.0,
    201,
)

profile_rows = []

for shape_name, shape in INFRA_SHAPES.items():

    for F_inf in F_INF_TEST_VALUES:

        omega_values = omega_infrastructure(
            X_PROFILE,
            F_inf=F_inf,
            **shape,
        )

        for x, omega_value in zip(
            X_PROFILE,
            omega_values,
        ):

            profile_rows.append({
                "Shape": shape_name,
                "F_inf_CAD_per_RVK": F_inf,

                "lambda_inf": shape["lambda_inf"],
                "a_eta": shape["a_eta"],
                "a_zeta": shape["a_zeta"],
                "xbar": shape["xbar"],

                "Service_share_x": x,

                "eta_CAD_per_RVK": (
                    shape["a_eta"]
                    * F_inf
                ),

                "zeta_CAD_per_RVK": (
                    shape["a_zeta"]
                    * F_inf
                ),

                "Omega_CAD_per_RVK": float(
                    omega_value
                ),
            })


profile_df = pd.DataFrame(
    profile_rows
)

profile_df.to_csv(
    CSV_D1A_DIR
    / "infrastructure_shape_profiles.csv",
    index=False,
)


# =============================================================================
# 20. COMBINED rho + INFRASTRUCTURE BREAK-EVEN AUDIT
#
# For a focal technology at a given service share x:
#
# Remaining margin after rho
#     - Omega_i(x)
#
# gives its pairwise margin against the strongest unchanged competitor.
#
# Because Omega_i(x) = F_inf * shape_factor(x),
#
# the local F_inf break-even value is:
#
#     F_inf* = remaining_margin / shape_factor(x).
#
# We report this at:
#   x = 0.05  rare/early H-type share
#   x = 0.15  early E-type share
#   x = 0.25
#   x = 0.50
#   x = 0.70
#   x = 1.00  local pure-corner stability
# =============================================================================

X_AUDIT_VALUES = [
    0.05,
    0.15,
    0.25,
    0.50,
    0.70,
    1.00,
]

combined_rows = []

for _, rho_row in rho_stress_df.iterrows():

    scenario_name = rho_row["Scenario"]
    focal = rho_row["Focal_technology"]
    rho_value = float(
        rho_row["rho"]
    )

    remaining_margin = float(
        rho_row[
            "Remaining_margin_before_infrastructure_CAD_per_RVK"
        ]
    )

    for shape_name, shape in INFRA_SHAPES.items():

        for x in X_AUDIT_VALUES:

            shape_factor = omega_shape_factor(
                x,
                shape,
            )

            if (
                remaining_margin > 0.0
                and shape_factor > 0.0
            ):

                F_break = (
                    remaining_margin
                    / shape_factor
                )

            elif remaining_margin == 0.0:

                F_break = 0.0

            else:

                F_break = np.nan

            combined_rows.append({
                "Scenario": scenario_name,
                "Focal_technology": focal,

                "rho": rho_value,
                "Shape": shape_name,
                "Service_share_x": x,

                "Remaining_margin_before_infrastructure_CAD_per_RVK":
                    remaining_margin,

                "Omega_per_unit_Finf_at_x":
                    shape_factor,

                "F_inf_local_break_even_CAD_per_RVK":
                    F_break,
            })


combined_df = pd.DataFrame(
    combined_rows
)

combined_df.to_csv(
    CSV_D1A_DIR
    / "combined_rho_infrastructure_local_break_even.csv",
    index=False,
)


# =============================================================================
# 21. COMPACT CANDIDATE-SHAPE SUMMARY
# =============================================================================

shape_summary_rows = []

for shape_name, shape in INFRA_SHAPES.items():

    row = {
        "Shape": shape_name,

        "lambda_inf": shape["lambda_inf"],
        "a_eta": shape["a_eta"],
        "a_zeta": shape["a_zeta"],
        "xbar": shape["xbar"],

        "Omega_over_F_at_x0": omega_shape_factor(
            0.0,
            shape,
        ),

        "Omega_over_F_at_x005": omega_shape_factor(
            0.05,
            shape,
        ),

        "Omega_over_F_at_x015": omega_shape_factor(
            0.15,
            shape,
        ),

        "Omega_over_F_at_x050": omega_shape_factor(
            0.50,
            shape,
        ),

        "Omega_over_F_at_x070": omega_shape_factor(
            0.70,
            shape,
        ),

        "Omega_over_F_at_x100": omega_shape_factor(
            1.00,
            shape,
        ),
    }

    shape_summary_rows.append(
        row
    )


shape_summary_df = pd.DataFrame(
    shape_summary_rows
)

shape_summary_df.to_csv(
    CSV_D1A_DIR
    / "candidate_infrastructure_shape_summary.csv",
    index=False,
)


# =============================================================================
# 22. FIGURE 1 — INFRASTRUCTURE SHAPE COMPARISON
#
# Show Omega/F rather than an arbitrary F so the shape itself is transparent.
# =============================================================================

fig, ax = plt.subplots(
    figsize=(6.6, 4.8)
)

for shape_name, shape in INFRA_SHAPES.items():

    factor = np.array(
        [
            omega_shape_factor(
                x,
                shape,
            )
            for x in X_PROFILE
        ]
    )

    ax.plot(
        X_PROFILE,
        factor,
        linewidth=1.7,
        label=shape_name,
    )

ax.axvline(
    0.70,
    linestyle="--",
    linewidth=0.9,
    color="0.35",
)

ax.set_xlabel(
    r"Technology service share, $x_i$"
)

ax.set_ylabel(
    r"Normalized infrastructure burden, $\Omega_i/F_i^{\mathrm{inf}}$"
)

ax.set_title(
    "Candidate nonlinear infrastructure-burden shapes",
    fontweight="semibold",
)

ax.grid(
    False
)

ax.legend(
    frameon=False
)

fig.tight_layout()

fig.savefig(
    FIG_D1A_DIR
    / "candidate_infrastructure_shapes.png",
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    FIG_D1A_DIR
    / "candidate_infrastructure_shapes.pdf",
    bbox_inches="tight",
)

plt.show()
plt.close(fig)


# =============================================================================
# 23. FIGURE 2 — REMAINING DOMINANCE MARGIN VS rho
# =============================================================================

fig, ax = plt.subplots(
    figsize=(6.6, 4.8)
)

for scenario_name in ["S1", "S2", "S3"]:

    sub = rho_stress_df[
        rho_stress_df["Scenario"]
        == scenario_name
    ]

    ax.plot(
        sub["rho"],
        sub[
            "Remaining_margin_before_infrastructure_CAD_per_RVK"
        ],
        marker="o",
        markersize=3.5,
        linewidth=1.5,
        label=scenario_name,
    )

ax.axhline(
    0.0,
    linestyle="--",
    linewidth=0.9,
    color="0.25",
)

ax.set_xlabel(
    r"Service-equivalency factor, $\rho_i$"
)

ax.set_ylabel(
    "Remaining active-policy payoff margin (CAD/RVK)"
)

ax.set_title(
    "Operational non-equivalence before infrastructure burden",
    fontweight="semibold",
)

ax.grid(
    False
)

ax.legend(
    frameon=False
)

fig.tight_layout()

fig.savefig(
    FIG_D1A_DIR
    / "rho_remaining_payoff_margin.png",
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    FIG_D1A_DIR
    / "rho_remaining_payoff_margin.pdf",
    bbox_inches="tight",
)

plt.show()
plt.close(fig)


# =============================================================================
# 24. PRINT AUDIT
# =============================================================================

print("=" * 104)
print("PHASE 4D-1A — OPERATIONAL / INFRASTRUCTURE CALIBRATION AUDIT")
print("=" * 104)

print("\nA. ACTIVE-POLICY BENCHMARK PAYOFF MARGINS")
print("-" * 104)

for _, row in scenario_margin_df.iterrows():

    print(
        f"\n{row['Scenario']}: "
        f"winner={row['Dominant_technology']}, "
        f"closest competitor={row['Closest_competitor']}"
    )

    print(
        f"  Pi_H(1)={row['Pi_H_y1']:.6f}, "
        f"Pi_E(1)={row['Pi_E_y1']:.6f}, "
        f"Pi_D(1)={row['Pi_D_y1']:.6f}"
    )

    print(
        "  closest active-policy payoff margin = "
        f"{row['Closest_active_payoff_margin_CAD_per_RVK']:.6f} CAD/RVK"
    )


print("\nB. EXACT SERVICE-NON-EQUIVALENCE BREAK-EVEN THRESHOLDS")
print("-" * 104)

for _, row in rho_break_df.iterrows():

    print(
        f"{row['Scenario']} | "
        f"{row['Focal_technology']} vs {row['Competitor']}: "
        f"rho* = {row['rho_break_even']:.6f}"
    )


print("\nC. CANDIDATE INFRASTRUCTURE SHAPES")
print("-" * 104)

for _, row in shape_summary_df.iterrows():

    print(
        f"\n{row['Shape']}"
    )

    print(
        "  Omega/F at x=0.05, 0.15, 0.50, 0.70, 1.00 = "
        f"{row['Omega_over_F_at_x005']:.4f}, "
        f"{row['Omega_over_F_at_x015']:.4f}, "
        f"{row['Omega_over_F_at_x050']:.4f}, "
        f"{row['Omega_over_F_at_x070']:.4f}, "
        f"{row['Omega_over_F_at_x100']:.4f}"
    )


print("\nD. MODERATE-NONLINEAR LOCAL F_inf BREAK-EVEN EXAMPLES")
print("-" * 104)

for scenario_name in ["S1", "S2", "S3"]:

    focal = (
        "E"
        if scenario_name in {"S1", "S2"}
        else "H"
    )

    print(
        f"\n{scenario_name} | focal={focal}"
    )

    # Show rho=1 and a modest non-equivalence point.
    for rho_value in [1.00, 1.20, 1.50]:

        sub = combined_df[
            (combined_df["Scenario"] == scenario_name)
            & (combined_df["Shape"] == "Moderate nonlinear")
            & (np.isclose(combined_df["rho"], rho_value))
            & (
                combined_df["Service_share_x"].isin(
                    [0.05, 0.15, 0.50, 1.00]
                )
            )
        ]

        print(
            f"  rho={rho_value:.2f}:"
        )

        for _, row in sub.iterrows():

            F_star = row[
                "F_inf_local_break_even_CAD_per_RVK"
            ]

            if np.isnan(F_star):

                F_text = (
                    "already below closest competitor before infrastructure"
                )

            else:

                F_text = (
                    f"{F_star:.4f} CAD/RVK"
                )

            print(
                f"    x={row['Service_share_x']:.2f}: "
                f"F_inf* = {F_text}"
            )


print("\nE. DIMENSIONAL RULES CONFIRMED")
print("-" * 104)
print("  rho_i modifies fleet-dependent annualized acquisition cost only.")
print("  C_i remains delivered-RVK operating cost and is NOT multiplied by rho_i.")
print("  q_i, fare revenue, and e_i are NOT multiplied by rho_i.")
print("  Omega_i(x_i) is a reduced-form monetary burden in CAD/RVK.")
print("  Under the nested shape parameterization, F_inf=0 gives Omega_i(x)=0 exactly.")

print("\nFiles saved under:")
print(
    f"  {PHASE4D1A_DIR.resolve()}"
)

print("\nCSV RESULTS")
print("  baseline_active_policy_payoff_margins.csv")
print("  rho_pairwise_break_even_thresholds.csv")
print("  rho_stress_remaining_payoff_margins.csv")
print("  candidate_infrastructure_shape_summary.csv")
print("  infrastructure_shape_profiles.csv")
print("  combined_rho_infrastructure_local_break_even.csv")

print("\nPhase 4D-1A audit completed.")
