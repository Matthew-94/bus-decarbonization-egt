# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1C
# ANALYTICAL BIFURCATION AUDIT FOR OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE
#
# WHY THIS STEP IS NEEDED
# -----------------------
# The 24-IC maps in Phase 4D-1B revealed broad path-dependent regions.
# Because the audited infrastructure burden depends on the technology's own
# service share, the extension creates positive frequency dependence at low
# penetration:
#
#   Omega_i(x_i) is high when x_i is rare,
#   falls with deployment,
#   and rises mildly again at high penetration.
#
# Under the frozen policy block, Delta_H, Delta_E, Delta_D > 0 in S1-S3,
# therefore y -> 1 for all interior policy starts.
#
# Diesel is also strictly dominated by the non-focal clean competitor at y=1
# in all three scenarios. Hence the long-run extension reduces to an H-E edge
# problem with one state-dependent focal payoff:
#
#   g(x) = M(rho) - F_inf s(x)
#
# where
#
#   s(x) = exp(-4x) + 0.10 x + 0.50 max(0,x-0.70)^2.
#
# This script classifies the exact attractor structure analytically and
# separates:
#
#   1. unique focal-technology attraction,
#   2. pure H-E bistability,
#   3. pure-competitor + stable mixed H/E coexistence,
#   4. unique competitor attraction,
#   5. critical bifurcation boundaries.
#
# No ODE grid is needed. All outputs are saved to CSV.
# =============================================================================

from scipy.optimize import minimize_scalar, brentq
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================

# =============================================================================
# PHASE 4D-2A
# BOUNDED PASSENGER-UTILIZATION SPECIFICATION
# CALIBRATION + ANALYTICAL REGIME AUDIT
#
# PURPOSE
# -------
# Test whether replacing the baseline linear passenger-utilization equation
#
#   q_i = alpha_0 + gamma_1 U_i - gamma_2 U_O
#
# with the bounded outside-option Logit form
#
#   q_i^L = qbar / [1 + exp(-beta (U_i-U_O))]
#
# changes the strategic transition regimes.
#
# IMPORTANT
# ---------
# 1. Passengers still do NOT choose propulsion technologies directly.
#    q_i is utilization of transit service under configuration i relative to
#    the outside option.
#
# 2. The benchmark Logit calibration matches diesel utilization exactly:
#
#       U_D = 0, U_O = 1, q_D = 1.20.
#
#    Choosing qbar = 3 gives
#
#       beta_match = ln(1.5) ≈ 0.405465.
#
# 3. During the beta sensitivity sweep, qbar(beta) is re-anchored so that
#    q_D remains exactly 1.20 boardings/RVK. This isolates the SHAPE /
#    responsiveness of the bounded utilization function instead of changing
#    the overall transit-utilization scale at the same time.
#
# 4. The linear-demand consumer-surplus formula is NOT reused under Logit.
#    It is not required for the replicator dynamics because the PA update uses
#    only the incremental policy payoff Delta_i.
#
# ALL tables and sensitivity results are saved to CSV.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-2B
# 24-INITIAL-CONDITION CERTIFICATION OF BOUNDED PASSENGER UTILIZATION
#
# PURPOSE
# -------
# Numerically certify that the bounded outside-option Logit utilization model
# preserves the strategic transition regimes across:
#
#   beta = 0.15             (low sensitivity)
#   beta = ln(1.5)          (matched benchmark)
#   beta = 1.20             (high sensitivity)
#
# For every beta and scenario, qbar(beta) is chosen so that diesel utilization
# remains exactly q_D = 1.20 boardings/RVK. This isolates the curvature /
# responsiveness of the passenger-utilization specification.
#
# Each case is tested from 24 widely separated initial conditions.
#
# ALL trajectories and summaries are saved to CSV independently of figures.
# =============================================================================

from scipy.integrate import solve_ivp


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

OUT_DIR = Path("Phase4D2B_passenger_logit_24IC_certification")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CSV_DIR = OUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJ_DIR = CSV_DIR / "trajectories"
TRAJ_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_DIR = CSV_DIR / "summaries"
SUMMARY_DIR.mkdir(parents=True, exist_ok=True)

FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION FIGURE STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.4,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. 24 STRUCTURED INITIAL CONDITIONS
# =============================================================================

TECH_COMPOSITIONS = [
    ("D-heavy, slight E tilt",   0.05, 0.10),
    ("D-heavy, slight H tilt",   0.10, 0.05),
    ("E-heavy",                  0.05, 0.75),
    ("H-heavy",                  0.75, 0.05),
    ("E-leaning mixed",          0.20, 0.55),
    ("H-leaning mixed",          0.55, 0.20),
    ("Three-way balanced",       0.30, 0.30),
    ("Green-heavy H/E balanced", 0.45, 0.45),
]

POLICY_START_LEVELS = [
    ("Low policy",    0.10),
    ("Medium policy", 0.50),
    ("High policy",   0.90),
]

IC_ROWS = []
IC_ARRAY = []

counter = 1

for comp_label, z0, w0 in TECH_COMPOSITIONS:
    D0 = 1.0 - z0 - w0

    for policy_label, y0 in POLICY_START_LEVELS:
        name = f"IC{counter:02d}"

        IC_ROWS.append({
            "IC": name,
            "Composition_group": comp_label,
            "Policy_group": policy_label,
            "z0_H": z0,
            "w0_E": w0,
            "D0": D0,
            "y0": y0,
        })

        IC_ARRAY.append(
            [z0, w0, y0]
        )

        counter += 1

IC_DF = pd.DataFrame(IC_ROWS)
IC_ARRAY = np.asarray(IC_ARRAY, dtype=float)
IC_NAMES = list(IC_DF["IC"])
N_IC = len(IC_NAMES)

assert N_IC == 24

IC_DF.to_csv(
    CSV_DIR / "initial_conditions_24.csv",
    index=False,
)


# =============================================================================
# 15. BOUNDED LOGIT UTILIZATION
# =============================================================================

Q_D_TARGET = 1.20
BETA_MATCH = float(np.log(1.5))

BETA_CASES = {
    "Low_beta": 0.15,
    "Matched_beta": BETA_MATCH,
    "High_beta": 1.20,
}


def qbar_to_anchor_diesel(
    beta,
    U_D,
    U_O,
    q_D_target=Q_D_TARGET,
):
    return float(
        q_D_target
        * (
            1.0
            + np.exp(
                -beta * (U_D - U_O)
            )
        )
    )


def bounded_q(
    U,
    U_O,
    beta,
    qbar,
):
    return float(
        qbar
        / (
            1.0
            + np.exp(
                -beta * (U - U_O)
            )
        )
    )


def derived_logit(
    p,
    beta,
):
    """
    Rebuild every q-dependent quantity consistently.
    """

    base = derived_quantities(p)

    qbar = qbar_to_anchor_diesel(
        beta=beta,
        U_D=base["U_D"],
        U_O=p.U_O,
    )

    q_H = bounded_q(
        base["U_H"],
        p.U_O,
        beta,
        qbar,
    )

    q_E = bounded_q(
        base["U_E"],
        p.U_O,
        beta,
        qbar,
    )

    q_D = bounded_q(
        base["U_D"],
        p.U_O,
        beta,
        qbar,
    )

    pi_H_B = (
        p.fare_t * q_H
        - base["C_H"]
        - base["cap_H"]
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - base["C_E"]
        - base["cap_E"]
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - base["C_D"]
        - base["cap_D"]
    )

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_E0 = pi_E_B - pi_D_B

    Gamma_H1 = (
        p.S_H * q_H
        + p.T_D * q_D
    )

    Gamma_E1 = (
        p.S_E * q_E
        + p.T_D * q_D
    )

    denom_HE = Gamma_H1 - Gamma_E1

    if abs(denom_HE) > 1e-12:
        y_HE = (
            pi_E_B - pi_H_B
        ) / denom_HE
    else:
        y_HE = np.nan

    return {
        "beta": beta,
        "qbar": qbar,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_E0": Gamma_E0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E1": Gamma_E1,

        "y_HE_star": y_HE,
    }


# =============================================================================
# 16. REPLICATOR DYNAMICS UNDER LOGIT UTILIZATION
# =============================================================================

def batch_rhs_logit(
    tau,
    flat_state,
    p,
    beta,
    n_ic,
):
    X = np.asarray(
        flat_state,
        dtype=float,
    ).reshape(
        n_ic,
        3,
    )

    z = X[:, 0]
    w = X[:, 1]
    y = X[:, 2]

    D = 1.0 - z - w

    d = derived_logit(
        p,
        beta,
    )

    Pi_H = (
        d["pi_H_B"]
        + y * p.S_H * d["q_H"]
    )

    Pi_E = (
        d["pi_E_B"]
        + y * p.S_E * d["q_E"]
    )

    Pi_D = (
        d["pi_D_B"]
        - y * p.T_D * d["q_D"]
    )

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + D * Pi_D
    )

    P = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    dz = (
        p.eta_TO
        * z
        * (Pi_H - Pi_bar)
    )

    dw = (
        p.eta_TO
        * w
        * (Pi_E - Pi_bar)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.column_stack(
        [dz, dw, dy]
    ).reshape(-1)


# =============================================================================
# 17. NUMERICAL SETTINGS
# =============================================================================

ADAPTIVE_HORIZONS = [
    120.0,
    300.0,
    800.0,
]

PURE_TOL = 0.999
SIMPLEX_TOL = 1e-5


def sanitize_state(state):
    z, w, y = map(float, state)

    if (
        z < -SIMPLEX_TOL
        or w < -SIMPLEX_TOL
        or z + w > 1.0 + SIMPLEX_TOL
    ):
        raise RuntimeError(
            "Material simplex violation: "
            f"z={z:.12f}, w={w:.12f}, z+w={z+w:.12f}"
        )

    z = max(0.0, z)
    w = max(0.0, w)

    if z + w > 1.0:
        total = z + w
        z /= total
        w /= total

    D = max(
        0.0,
        1.0 - z - w,
    )

    y = float(
        np.clip(
            y,
            0.0,
            1.0,
        )
    )

    return z, w, D, y


def classify_state(state):
    z, w, D, y = sanitize_state(state)

    if z >= PURE_TOL:
        label = "H"
    elif w >= PURE_TOL:
        label = "E"
    elif D >= PURE_TOL:
        label = "D"
    else:
        label = "Not_pure"

    return {
        "Final_H": z,
        "Final_E": w,
        "Final_D": D,
        "Final_y": y,
        "Final_class": label,
    }


# =============================================================================
# 18. SOLVE ONE CASE FROM ALL 24 INITIAL CONDITIONS
# =============================================================================

def solve_case(
    scenario_name,
    beta_label,
    beta,
):
    p = make_scenario(
        scenario_name
    )

    X_current = np.array(
        IC_ARRAY,
        copy=True,
    )

    current_tau = 0.0
    effective_tau = ADAPTIVE_HORIZONS[-1]

    for target_tau in ADAPTIVE_HORIZONS:

        sol = solve_ivp(
            fun=lambda tau, state: batch_rhs_logit(
                tau=tau,
                flat_state=state,
                p=p,
                beta=beta,
                n_ic=N_IC,
            ),
            t_span=(
                current_tau,
                target_tau,
            ),
            y0=X_current.reshape(-1),
            t_eval=[target_tau],
            method="DOP853",
            rtol=1e-9,
            atol=1e-11,
        )

        if not sol.success:
            raise RuntimeError(
                sol.message
            )

        X_current = (
            sol.y[:, -1]
            .reshape(
                N_IC,
                3,
            )
        )

        current_tau = target_tau

        labels = [
            classify_state(
                X_current[i]
            )["Final_class"]
            for i in range(N_IC)
        ]

        if all(
            label != "Not_pure"
            for label in labels
        ):
            effective_tau = target_tau
            break

    rows = []

    for i, ic_name in enumerate(IC_NAMES):

        meta = IC_DF[
            IC_DF["IC"] == ic_name
        ].iloc[0]

        final = classify_state(
            X_current[i]
        )

        rows.append({
            "Scenario": scenario_name,
            "Beta_case": beta_label,
            "beta": beta,

            "IC": ic_name,

            "z0_H": meta["z0_H"],
            "w0_E": meta["w0_E"],
            "D0": meta["D0"],
            "y0": meta["y0"],

            "Effective_tau": effective_tau,

            **final,
        })

    return pd.DataFrame(rows)


# =============================================================================
# 19. FULL TRAJECTORIES FOR A COMMON REFERENCE INITIAL CONDITION
#
# This is for timing/mechanism comparison only.
# The 24-IC endpoint certification remains the robustness check.
# =============================================================================

REFERENCE_IC = np.array(
    [0.05, 0.15, 0.20],
    dtype=float,
)

TAU_END_REFERENCE = 120.0
TAU_EVAL_REFERENCE = np.linspace(
    0.0,
    TAU_END_REFERENCE,
    2401,
)


def solve_reference_trajectory(
    scenario_name,
    beta_label,
    beta,
):
    p = make_scenario(
        scenario_name
    )

    sol = solve_ivp(
        fun=lambda tau, state: batch_rhs_logit(
            tau=tau,
            flat_state=state,
            p=p,
            beta=beta,
            n_ic=1,
        ),
        t_span=(
            0.0,
            TAU_END_REFERENCE,
        ),
        y0=REFERENCE_IC,
        t_eval=TAU_EVAL_REFERENCE,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(
            sol.message
        )

    z = sol.y[0]
    w = sol.y[1]
    y = sol.y[2]
    D = 1.0 - z - w

    return pd.DataFrame({
        "Scenario": scenario_name,
        "Beta_case": beta_label,
        "beta": beta,
        "tau": sol.t,
        "Hydrogen_z": z,
        "Electric_w": w,
        "Diesel_D": D,
        "Policy_y": y,
    })


# =============================================================================
# 20. RUN ALL CASES
# =============================================================================

endpoint_frames = []
trajectory_frames = []
summary_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:
    p = make_scenario(
        scenario_name
    )

    for beta_label, beta in BETA_CASES.items():

        endpoint_df = solve_case(
            scenario_name,
            beta_label,
            beta,
        )

        endpoint_frames.append(
            endpoint_df
        )

        endpoint_df.to_csv(
            SUMMARY_DIR
            / f"{scenario_name}_{beta_label}_24IC_final_states.csv",
            index=False,
        )

        traj_df = solve_reference_trajectory(
            scenario_name,
            beta_label,
            beta,
        )

        trajectory_frames.append(
            traj_df
        )

        traj_df.to_csv(
            TRAJ_DIR
            / f"{scenario_name}_{beta_label}_reference_trajectory.csv",
            index=False,
        )

        d = derived_logit(
            p,
            beta,
        )

        counts = (
            endpoint_df[
                "Final_class"
            ]
            .value_counts()
            .to_dict()
        )

        final_classes = set(
            endpoint_df[
                "Final_class"
            ]
        )

        consensus = (
            next(iter(final_classes))
            if len(final_classes) == 1
            else "Multiple"
        )

        summary_rows.append({
            "Scenario": scenario_name,
            "Beta_case": beta_label,
            "beta": beta,

            "qbar": d["qbar"],
            "q_H": d["q_H"],
            "q_E": d["q_E"],
            "q_D": d["q_D"],

            "y_HE_star": d["y_HE_star"],

            "Consensus_final_class": consensus,

            "N_H": int(counts.get("H", 0)),
            "N_E": int(counts.get("E", 0)),
            "N_D": int(counts.get("D", 0)),
            "N_not_pure": int(counts.get("Not_pure", 0)),

            "Mean_final_H": float(
                endpoint_df[
                    "Final_H"
                ].mean()
            ),

            "Mean_final_E": float(
                endpoint_df[
                    "Final_E"
                ].mean()
            ),

            "Mean_final_D": float(
                endpoint_df[
                    "Final_D"
                ].mean()
            ),

            "Mean_final_y": float(
                endpoint_df[
                    "Final_y"
                ].mean()
            ),

            "Max_effective_tau": float(
                endpoint_df[
                    "Effective_tau"
                ].max()
            ),
        })


all_endpoints_df = pd.concat(
    endpoint_frames,
    ignore_index=True,
)

all_endpoints_df.to_csv(
    CSV_DIR
    / "ALL_cases_24IC_final_states.csv",
    index=False,
)

all_trajectories_df = pd.concat(
    trajectory_frames,
    ignore_index=True,
)

all_trajectories_df.to_csv(
    CSV_DIR
    / "ALL_reference_trajectories.csv",
    index=False,
)

summary_df = pd.DataFrame(
    summary_rows
)

summary_df.to_csv(
    CSV_DIR
    / "24IC_certification_summary.csv",
    index=False,
)


# =============================================================================
# 21. REFERENCE-TRAJECTORY MILESTONES
# =============================================================================

milestone_rows = []


def first_crossing_time(
    tau,
    values,
    threshold,
    direction="up",
):
    tau = np.asarray(tau)
    values = np.asarray(values)

    if direction == "up":
        idx = np.where(
            values >= threshold
        )[0]
    else:
        idx = np.where(
            values <= threshold
        )[0]

    if len(idx) == 0:
        return np.nan

    return float(
        tau[
            idx[0]
        ]
    )


for (
    scenario_name,
    beta_label,
), sub in all_trajectories_df.groupby(
    [
        "Scenario",
        "Beta_case",
    ]
):
    sub = sub.sort_values(
        "tau"
    )

    tau = sub["tau"].to_numpy()

    milestone_rows.append({
        "Scenario": scenario_name,
        "Beta_case": beta_label,
        "beta": float(
            sub[
                "beta"
            ].iloc[0]
        ),

        "tau_D_le_0p10": first_crossing_time(
            tau,
            sub["Diesel_D"],
            0.10,
            direction="down",
        ),

        "tau_E_ge_0p90": first_crossing_time(
            tau,
            sub["Electric_w"],
            0.90,
            direction="up",
        ),

        "tau_H_ge_0p90": first_crossing_time(
            tau,
            sub["Hydrogen_z"],
            0.90,
            direction="up",
        ),

        "tau_y_ge_0p90": first_crossing_time(
            tau,
            sub["Policy_y"],
            0.90,
            direction="up",
        ),

        "max_H": float(
            sub["Hydrogen_z"].max()
        ),

        "max_E": float(
            sub["Electric_w"].max()
        ),

        "min_D": float(
            sub["Diesel_D"].min()
        ),
    })


milestone_df = pd.DataFrame(
    milestone_rows
)

milestone_df.to_csv(
    CSV_DIR
    / "reference_trajectory_milestones.csv",
    index=False,
)


# =============================================================================
# 22. CLEAN FIGURES — ONE PER SCENARIO
# =============================================================================

LINESTYLES = {
    "Low_beta": "--",
    "Matched_beta": "-",
    "High_beta": ":",
}

LABELS = {
    "Low_beta": r"Low $\beta=0.15$",
    "Matched_beta": r"Matched $\beta=\ln(1.5)$",
    "High_beta": r"High $\beta=1.20$",
}

scenario_titles = {
    "S1": "Baseline conditions",
    "S2": "Intermediate conditions",
    "S3": "Advanced conditions",
}

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub_s = all_trajectories_df[
        all_trajectories_df[
            "Scenario"
        ]
        == scenario_name
    ]

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(10.3, 4.2),
    )

    # Dominant zero-emission technology.
    dominant_col = (
        "Electric_w"
        if scenario_name in {"S1", "S2"}
        else "Hydrogen_z"
    )

    dominant_label = (
        r"Electric share, $w$"
        if scenario_name in {"S1", "S2"}
        else r"Hydrogen share, $z$"
    )

    for beta_label in [
        "Low_beta",
        "Matched_beta",
        "High_beta",
    ]:

        ss = sub_s[
            sub_s[
                "Beta_case"
            ]
            == beta_label
        ]

        axes[0].plot(
            ss["tau"],
            ss[dominant_col],
            linestyle=LINESTYLES[
                beta_label
            ],
            linewidth=1.5,
            label=LABELS[
                beta_label
            ],
        )

        axes[1].plot(
            ss["tau"],
            ss["Policy_y"],
            linestyle=LINESTYLES[
                beta_label
            ],
            linewidth=1.5,
            label=LABELS[
                beta_label
            ],
        )

    axes[0].set_xlabel(
        r"Normalized evolutionary time, $\tau$"
    )

    axes[0].set_ylabel(
        dominant_label
    )

    axes[0].set_title(
        "Dominant clean-technology trajectory"
    )

    axes[1].set_xlabel(
        r"Normalized evolutionary time, $\tau$"
    )

    axes[1].set_ylabel(
        r"Active-policy weight, $y$"
    )

    axes[1].set_title(
        "Policy trajectory"
    )

    for ax in axes:
        ax.set_ylim(
            -0.02,
            1.02,
        )
        ax.grid(False)

    axes[1].legend(
        frameon=False,
        loc="best",
    )

    fig.suptitle(
        scenario_titles[
            scenario_name
        ]
        + "\nBounded passenger-utilization robustness",
        fontweight="semibold",
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR
        / f"{scenario_name}_bounded_utilization_trajectory_robustness.png",
        dpi=600,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / f"{scenario_name}_bounded_utilization_trajectory_robustness.pdf",
        bbox_inches="tight",
    )

    plt.show()
    plt.close(fig)


# =============================================================================
# 23. PRINT FINAL CERTIFICATION
# =============================================================================

print("=" * 108)
print("PHASE 4D-2B — 24-IC BOUNDED UTILIZATION CERTIFICATION")
print("=" * 108)

print(
    f"\nInitial conditions per case: {N_IC}"
)

print(
    "Beta cases: "
    + ", ".join(
        f"{name}={value:.6f}"
        for name, value in BETA_CASES.items()
    )
)

print("\n24-IC ENDPOINT CERTIFICATION")
print("-" * 108)

for _, row in summary_df.iterrows():

    print(
        f"{row['Scenario']} | "
        f"{row['Beta_case']} "
        f"(beta={row['beta']:.6f})"
    )

    print(
        f"  consensus = "
        f"{row['Consensus_final_class']}"
    )

    print(
        f"  H/E/D/not-pure counts = "
        f"{int(row['N_H'])}/"
        f"{int(row['N_E'])}/"
        f"{int(row['N_D'])}/"
        f"{int(row['N_not_pure'])}"
    )

    print(
        f"  mean final "
        f"H={row['Mean_final_H']:.6f}, "
        f"E={row['Mean_final_E']:.6f}, "
        f"D={row['Mean_final_D']:.6f}, "
        f"y={row['Mean_final_y']:.6f}"
    )


print("\nREFERENCE-TRAJECTORY MILESTONES")
print("-" * 108)

for _, row in milestone_df.iterrows():

    print(
        f"{row['Scenario']} | "
        f"{row['Beta_case']}: "
        f"tau(D<=0.10)={row['tau_D_le_0p10']:.3f}, "
        f"tau(E>=0.90)={row['tau_E_ge_0p90']:.3f}, "
        f"tau(H>=0.90)={row['tau_H_ge_0p90']:.3f}, "
        f"tau(y>=0.90)={row['tau_y_ge_0p90']:.3f}"
    )


print("\nFiles saved under:")
print(
    f"  {OUT_DIR.resolve()}"
)

print("\nCSV RESULTS")
print("  initial_conditions_24.csv")
print("  ALL_cases_24IC_final_states.csv")
print("  ALL_reference_trajectories.csv")
print("  24IC_certification_summary.csv")
print("  reference_trajectory_milestones.csv")
print("  summaries/*.csv")
print("  trajectories/*.csv")

print("\nPhase 4D-2B completed.")
