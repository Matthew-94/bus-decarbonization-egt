# =============================================================================
# PHASE 4C-5C
# TARGETED HIGH-PRECISION CERTIFICATION OF S2 EIC23
#
# PURPOSE
# -------
# The original state-space integration of S2 EIC23 showed a clear persistent
# H-E cycle but failed the numerical first-integral tolerance because z comes
# extremely close to 1. The logarithmic first integral contains ln(1-z), so
# tiny absolute state errors are magnified near the boundary.
#
# This script integrates the SAME H-E edge system in logit coordinates:
#
#     u = log(z/(1-z))
#     v = log(y/(1-y))
#
# which removes the z(1-z) and y(1-y) factors from the differential equations
# and greatly improves numerical accuracy near 0/1 boundaries.
#
# It saves:
#   - complete high-precision trajectory CSV
#   - certification summary CSV
#   - diagnostic figure PNG/PDF
#
# It does NOT change the model.
# =============================================================================

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.integrate import solve_ivp
from scipy.signal import find_peaks


# =============================================================================
# 1. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path(
    "Phase4C5_analytical_classification"
) / "cycle_failure_diagnostics" / "S2_EIC23_logit_certification"

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# =============================================================================
# 2. S2 MODEL PARAMETERS — SAME CERTIFIED MODEL
# =============================================================================

# Passenger/service block
F_H = F_E = F_D = 3.0
A_H = A_E = A_D = 25.0

l = 10.0
fare_t = 3.0

beta_t = 0.50
lambda_time = 1.0

U_O = 1.0
U_0 = 2.0666666666666664

alpha_0 = 1.30
gamma_1 = 0.30
gamma_2 = 0.10

delta = 0.10

theta = 0.30
phi = 0.30

mu = 1.0

# Fleet / capital
K_D = 60_000.0

R_H = 900_000.0
R_E = 675_000.0
R_D = 510_000.0

L_H = L_E = L_D = 16

discount_r = 0.05

# Non-energy operating costs
C_hat_H = 1.20
C_hat_E = 0.7404427083
C_hat_D = 1.1953854167

# Energy consumption
omega_H = 0.088767
omega_E = 1.34
omega_D = 0.560035

# S2 energy prices
fuel_H = 7.00
fuel_E = 0.13
fuel_D = 1.90

# Emissions
nu_H = 0.015046166666666668
nu_E = 0.04944816666666666
nu_D = 0.218488

p_CO2 = 0.328213
e_target = 0.0

# Representative S2 H-E cycling policy point
S_H = 1.40
S_E = 0.20
T_D = 0.50

lambda_F = 0.05

eta_TO = 1.0
eta_PA = 1.0


# =============================================================================
# 3. DERIVED QUANTITIES
# =============================================================================

def capital_recovery_factor(r, L):

    return (
        r * (1.0 + r) ** L
        / ((1.0 + r) ** L - 1.0)
    )


U_H = (
    U_0
    - beta_t * fare_t
    - lambda_time * (
        1.0 / (2.0 * F_H)
        + l / A_H
    )
    + (1.0 + delta) * theta
)

U_E = (
    U_0
    - beta_t * fare_t
    - lambda_time * (
        1.0 / (2.0 * F_E)
        + l / A_E
    )
    + (1.0 + delta) * phi
)

U_D = (
    U_0
    - beta_t * fare_t
    - lambda_time * (
        1.0 / (2.0 * F_D)
        + l / A_D
    )
)

q_H = (
    alpha_0
    + gamma_1 * U_H
    - gamma_2 * U_O
)

q_E = (
    alpha_0
    + gamma_1 * U_E
    - gamma_2 * U_O
)

q_D = (
    alpha_0
    + gamma_1 * U_D
    - gamma_2 * U_O
)

C_H = (
    C_hat_H
    + omega_H * fuel_H
)

C_E = (
    C_hat_E
    + omega_E * fuel_E
)

C_D = (
    C_hat_D
    + omega_D * fuel_D
)

crf_H = capital_recovery_factor(
    discount_r,
    L_H,
)

crf_E = capital_recovery_factor(
    discount_r,
    L_E,
)

crf_D = capital_recovery_factor(
    discount_r,
    L_D,
)

cap_H = (
    R_H / K_D * crf_H
)

cap_E = (
    R_E / K_D * crf_E
)

cap_D = (
    R_D / K_D * crf_D
)

pi_H_B = (
    fare_t * q_H
    - C_H
    - cap_H
    - mu * theta**2 / 2.0
)

pi_E_B = (
    fare_t * q_E
    - C_E
    - cap_E
    - mu * phi**2 / 2.0
)

pi_D_B = (
    fare_t * q_D
    - C_D
    - cap_D
)

e_H = (
    l * q_H * nu_H
)

e_E = (
    l * q_E * nu_E
)

e_D = (
    l * q_D * nu_D
)

Delta_H = (
    p_CO2 * (e_H - e_target)
    - lambda_F * S_H * q_H
)

Delta_E = (
    p_CO2 * (e_E - e_target)
    - lambda_F * S_E * q_E
)

Delta_D = (
    p_CO2 * (e_D - e_target)
    + lambda_F * T_D * q_D
)

A_HE = (
    pi_H_B
    - pi_E_B
)

B_HE = (
    S_H * q_H
    - S_E * q_E
)


# =============================================================================
# 4. E9 COORDINATES
# =============================================================================

z_star = (
    Delta_E
    / (Delta_E - Delta_H)
)

w_star = (
    1.0
    - z_star
)

y_star = (
    (pi_E_B - pi_H_B)
    / B_HE
)

K_HE = (
    eta_TO
    * eta_PA
    * z_star
    * w_star
    * y_star
    * (1.0 - y_star)
    * B_HE
    * (Delta_H - Delta_E)
)

linearized_period = (
    2.0 * np.pi
    / np.sqrt(-K_HE)
)


# =============================================================================
# 5. RECONSTRUCT EIC23
#
# Original edge-initial-condition design:
#     radii = [0.40, 0.80, 1.20]
#     8 angles per radius
#
# EIC23 = radius 1.20, angular position 7/8:
#     angle = 3*pi/2
# =============================================================================

def logit(x):

    return np.log(
        x / (1.0 - x)
    )


def logistic(u):

    return (
        1.0
        / (1.0 + np.exp(-u))
    )


radius = 1.20
angle = 3.0 * np.pi / 2.0

u_star = logit(
    z_star
)

v_star = logit(
    y_star
)

u0 = (
    u_star
    + radius * np.cos(angle)
)

v0 = (
    v_star
    + radius * np.sin(angle)
)

z0 = logistic(
    u0
)

y0 = logistic(
    v0
)

w0 = (
    1.0
    - z0
)


# =============================================================================
# 6. LOGIT-COORDINATE H-E EDGE DYNAMICS
#
# Original edge dynamics:
#
# z_dot = eta_TO z(1-z) [A_HE + B_HE y]
#
# y_dot = eta_PA y(1-y)
#         [Delta_E + z(Delta_H-Delta_E)]
#
# Therefore:
#
# u_dot = z_dot/[z(1-z)]
#       = eta_TO [A_HE + B_HE y]
#
# v_dot = y_dot/[y(1-y)]
#       = eta_PA [Delta_E + z(Delta_H-Delta_E)]
# =============================================================================

def logit_rhs(
    tau,
    state,
):

    u, v = state

    z = logistic(
        u
    )

    y = logistic(
        v
    )

    du = (
        eta_TO
        * (
            A_HE
            + B_HE * y
        )
    )

    dv = (
        eta_PA
        * (
            Delta_E
            + z * (
                Delta_H
                - Delta_E
            )
        )
    )

    return np.array(
        [du, dv],
        dtype=float,
    )


# =============================================================================
# 7. EXACT H-E FIRST INTEGRAL
# =============================================================================

def HE_first_integral(
    z,
    y,
):

    z = np.asarray(
        z,
        dtype=float,
    )

    y = np.asarray(
        y,
        dtype=float,
    )

    return (
        Delta_E * np.log(z)
        - Delta_H * np.log1p(-z)
        - (
            eta_TO
            / eta_PA
        )
        * (
            A_HE * np.log(y)
            - (
                A_HE
                + B_HE
            )
            * np.log1p(-y)
        )
    )


# =============================================================================
# 8. HIGH-PRECISION SOLVE
# =============================================================================

TAU_END = 2000.0
N_POINTS = 8001

tau_eval = np.linspace(
    0.0,
    TAU_END,
    N_POINTS,
)

sol = solve_ivp(
    fun=logit_rhs,
    t_span=(
        0.0,
        TAU_END,
    ),
    y0=np.array(
        [u0, v0],
        dtype=float,
    ),
    t_eval=tau_eval,
    method="DOP853",
    rtol=1e-12,
    atol=1e-14,
)

if not sol.success:

    raise RuntimeError(
        sol.message
    )


# =============================================================================
# 9. RECONSTRUCT ORIGINAL VARIABLES
# =============================================================================

u = sol.y[0]
v = sol.y[1]

z = logistic(
    u
)

y = logistic(
    v
)

w = (
    1.0
    - z
)

D = np.zeros_like(
    z
)

invariant = HE_first_integral(
    z,
    y,
)


# =============================================================================
# 10. NUMERICAL CERTIFICATION
# =============================================================================

tail_mask = (
    tau_eval
    >= 0.50 * TAU_END
)

z_tail = z[
    tail_mask
]

y_tail = y[
    tail_mask
]

tau_tail = tau_eval[
    tail_mask
]

z_amplitude = float(
    np.max(z_tail)
    - np.min(z_tail)
)

y_amplitude = float(
    np.max(y_tail)
    - np.min(y_tail)
)

prominence = max(
    1e-5,
    0.05 * z_amplitude,
)

peaks, _ = find_peaks(
    z_tail,
    prominence=prominence,
)

peak_times = (
    tau_tail[
        peaks
    ]
)

if len(peak_times) >= 2:

    periods = np.diff(
        peak_times
    )

    mean_period = float(
        np.mean(periods)
    )

    period_cv = float(
        np.std(periods)
        / np.mean(periods)
    )

else:

    mean_period = np.nan
    period_cv = np.nan

invariant_range = float(
    np.max(invariant)
    - np.min(invariant)
)

cycle_certified = (
    z_amplitude > 1e-4
    and y_amplitude > 1e-4
    and invariant_range < 1e-8
    and len(peak_times) >= 3
)


# =============================================================================
# 11. SAVE COMPLETE TRAJECTORY CSV
# =============================================================================

trajectory_df = pd.DataFrame(
    {
        "tau": tau_eval,
        "u_logit_H": u,
        "v_logit_policy": v,
        "Hydrogen_z": z,
        "Electric_w": w,
        "Diesel_D": D,
        "Policy_y": y,
        "HE_first_integral": invariant,
    }
)

trajectory_df.to_csv(
    OUTPUT_DIR
    / "S2_EIC23_logit_high_precision_trajectory.csv",
    index=False,
)


# =============================================================================
# 12. SAVE CERTIFICATION SUMMARY CSV
# =============================================================================

summary_df = pd.DataFrame(
    [
        {
            "Scenario": "S2",
            "Edge_IC": "EIC23",
            "S_H": S_H,
            "S_E": S_E,

            "E9_z_H": z_star,
            "E9_w_E": w_star,
            "E9_y": y_star,

            "K_HE": K_HE,
            "Linearized_period": linearized_period,

            "Initial_z": z0,
            "Initial_w": w0,
            "Initial_y": y0,

            "Tail_H_amplitude": z_amplitude,
            "Tail_y_amplitude": y_amplitude,

            "Tail_peak_count": len(
                peak_times
            ),

            "Mean_period_tail": mean_period,
            "Period_CV_tail": period_cv,

            "First_integral_range": invariant_range,

            "Cycle_certified": cycle_certified,

            "Integrator": "DOP853 in logit coordinates",
            "rtol": 1e-12,
            "atol": 1e-14,
            "Tau_end": TAU_END,
        }
    ]
)

summary_df.to_csv(
    OUTPUT_DIR
    / "S2_EIC23_logit_high_precision_certification.csv",
    index=False,
)


# =============================================================================
# 13. DIAGNOSTIC FIGURE
# =============================================================================

fig, axes = plt.subplots(
    1,
    2,
    figsize=(10.5, 4.2),
)

axes[0].plot(
    tau_eval,
    z,
    linewidth=1.15,
    label=r"Hydrogen share, $z$",
)

axes[0].plot(
    tau_eval,
    y,
    linewidth=1.15,
    label=r"Policy weight, $y$",
)

axes[0].set_xlabel(
    r"Normalized evolutionary time, $\tau$"
)

axes[0].set_ylabel(
    "State value"
)

axes[0].set_title(
    "S2 EIC23 — high-precision time series"
)

axes[0].legend(
    frameon=False
)

axes[1].plot(
    z,
    y,
    linewidth=1.0,
)

axes[1].scatter(
    [z_star],
    [y_star],
    marker="*",
    s=80,
    facecolor="white",
    edgecolor="black",
    linewidth=0.9,
    zorder=5,
    label=r"$E_9$",
)

axes[1].set_xlabel(
    r"Hydrogen service share, $z$"
)

axes[1].set_ylabel(
    r"Active-policy weight, $y$"
)

axes[1].set_title(
    "S2 EIC23 — high-precision phase portrait"
)

axes[1].legend(
    frameon=False
)

for ax in axes:

    ax.grid(
        False
    )

fig.tight_layout()

fig.savefig(
    OUTPUT_DIR
    / "S2_EIC23_logit_high_precision_diagnostic.png",
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    OUTPUT_DIR
    / "S2_EIC23_logit_high_precision_diagnostic.pdf",
    bbox_inches="tight",
)

plt.show()
plt.close(fig)


# =============================================================================
# 14. PRINT
# =============================================================================

print("=" * 100)
print("PHASE 4C-5C — S2 EIC23 LOGIT HIGH-PRECISION CERTIFICATION")
print("=" * 100)

print(
    f"\nE9 = "
    f"(z={z_star:.9f}, "
    f"w={w_star:.9f}, "
    f"y={y_star:.9f})"
)

print(
    f"K_HE = {K_HE:.10f}"
)

print(
    f"Linearized period = "
    f"{linearized_period:.6f}"
)

print(
    f"\nEIC23 initial state = "
    f"(z={z0:.9f}, "
    f"w={w0:.9f}, "
    f"y={y0:.9f})"
)

print(
    f"\nTail hydrogen amplitude = "
    f"{z_amplitude:.9f}"
)

print(
    f"Tail policy amplitude = "
    f"{y_amplitude:.9f}"
)

print(
    f"Tail peak count = "
    f"{len(peak_times)}"
)

print(
    f"Mean observed period = "
    f"{mean_period:.6f}"
)

print(
    f"Observed period CV = "
    f"{period_cv:.6e}"
)

print(
    f"First-integral range = "
    f"{invariant_range:.6e}"
)

print(
    f"\nCycle certified = "
    f"{cycle_certified}"
)

print(
    f"\nFiles saved under:\n"
    f"{OUTPUT_DIR.resolve()}"
)
