# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1C
# ANALYTICAL BIFURCATION AUDIT FOR OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE
#
# WHY THIS STEP IS NEEDED
# -----------------------
# The 24-IC maps in Phase 4D-1B revealed broad path-dependent regions.
# Because the audited infrastructure burden depends on the technology's own
# service share, the extension creates positive frequency dependence at low
# penetration:
#
#   Omega_i(x_i) is high when x_i is rare,
#   falls with deployment,
#   and rises mildly again at high penetration.
#
# Under the frozen policy block, Delta_H, Delta_E, Delta_D > 0 in S1-S3,
# therefore y -> 1 for all interior policy starts.
#
# Diesel is also strictly dominated by the non-focal clean competitor at y=1
# in all three scenarios. Hence the long-run extension reduces to an H-E edge
# problem with one state-dependent focal payoff:
#
#   g(x) = M(rho) - F_inf s(x)
#
# where
#
#   s(x) = exp(-4x) + 0.10 x + 0.50 max(0,x-0.70)^2.
#
# This script classifies the exact attractor structure analytically and
# separates:
#
#   1. unique focal-technology attraction,
#   2. pure H-E bistability,
#   3. pure-competitor + stable mixed H/E coexistence,
#   4. unique competitor attraction,
#   5. critical bifurcation boundaries.
#
# No ODE grid is needed. All outputs are saved to CSV.
# =============================================================================

from scipy.optimize import minimize_scalar, brentq
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

OUT_DIR = Path("Phase4D1C_analytical_infrastructure_bifurcation")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CSV_DIR = OUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

MAP_DIR = CSV_DIR / "analytical_maps"
MAP_DIR.mkdir(parents=True, exist_ok=True)

FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.5,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. AUDITED MODERATE-NONLINEAR INFRASTRUCTURE SHAPE
# =============================================================================

LAMBDA_INF = 4.0
A_ETA = 0.10
A_ZETA = 0.50
XBAR = 0.70


def shape_s(x):
    """Normalized infrastructure burden Omega/F."""
    x = np.asarray(x, dtype=float)
    return (
        np.exp(-LAMBDA_INF * x)
        + A_ETA * x
        + A_ZETA * np.maximum(0.0, x - XBAR)**2
    )


# Exact minimum of the normalized burden on [0,1].
min_result = minimize_scalar(
    lambda xx: float(shape_s(xx)),
    bounds=(0.0, 1.0),
    method="bounded",
    options={"xatol": 1e-14},
)

X_MIN = float(min_result.x)
S_MIN = float(min_result.fun)
S_0 = float(shape_s(0.0))
S_1 = float(shape_s(1.0))


# =============================================================================
# 15. SCENARIO CONFIGURATION
# =============================================================================

GRID_N = 401

CONFIGS = {
    "S1": {
        "focal": "E",
        "competitor": "H",
        "rho_param": "rho_E",
        "rho_values": np.linspace(1.0, 3.0, GRID_N),
        "F_values": np.linspace(0.0, 3.0, GRID_N),
        "x_label": r"Electric service-equivalency factor, $\rho_E$",
        "y_label": r"Electric infrastructure-entry scale, $F_E^{\mathrm{inf}}$ (CAD/RVK)",
        "title": "Baseline conditions",
    },

    "S2": {
        "focal": "E",
        "competitor": "H",
        "rho_param": "rho_E",
        "rho_values": np.linspace(1.0, 2.5, GRID_N),
        "F_values": np.linspace(0.0, 2.0, GRID_N),
        "x_label": r"Electric service-equivalency factor, $\rho_E$",
        "y_label": r"Electric infrastructure-entry scale, $F_E^{\mathrm{inf}}$ (CAD/RVK)",
        "title": "Intermediate conditions",
    },

    "S3": {
        "focal": "H",
        "competitor": "E",
        "rho_param": "rho_H",
        "rho_values": np.linspace(1.0, 1.35, GRID_N),
        "F_values": np.linspace(0.0, 0.80, GRID_N),
        "x_label": r"Hydrogen service-equivalency factor, $\rho_H$",
        "y_label": r"Hydrogen infrastructure-entry scale, $F_H^{\mathrm{inf}}$ (CAD/RVK)",
        "title": "Advanced conditions",
    },
}


# =============================================================================
# 16. ACTIVE-POLICY PAYOFF MARGIN M(rho)
# =============================================================================

def active_policy_payoffs(p):
    d = derived_quantities(p)
    return {
        "H": d["pi_H_B"] + p.S_H * d["q_H"],
        "E": d["pi_E_B"] + p.S_E * d["q_E"],
        "D": d["pi_D_B"] - p.T_D * d["q_D"],
    }


def focal_margin(scenario_name, rho_value):
    """
    M(rho) = Pi_focal(y=1) - Pi_competitor(y=1)
    before the nonlinear infrastructure burden is applied.
    """

    cfg = CONFIGS[scenario_name]
    p0 = make_scenario(scenario_name)

    p = replace(
        p0,
        **{cfg["rho_param"]: float(rho_value)},
    )

    Pi = active_policy_payoffs(p)

    return (
        float(Pi[cfg["focal"]] - Pi[cfg["competitor"]]),
        Pi,
        p,
    )


# =============================================================================
# 17. ROOTS OF g(x) = M - F s(x)
# =============================================================================

def g_value(x, M, F_inf):
    return M - F_inf * float(shape_s(x))


def find_interior_roots(M, F_inf):
    """
    Find all roots of g(x)=0 in (0,1), then classify local stability
    for the one-dimensional focal-share equation:

        x_dot = x(1-x) g(x).

    An interior root is stable if g'(x*) < 0.
    """

    if F_inf <= 0.0:
        return []

    xs = np.linspace(0.0, 1.0, 4001)
    vals = M - F_inf * shape_s(xs)

    roots = []

    for i in range(len(xs) - 1):
        a = xs[i]
        b = xs[i + 1]
        fa = vals[i]
        fb = vals[i + 1]

        if fa == 0.0:
            root = a
        elif fa * fb < 0.0:
            root = brentq(
                lambda xx: g_value(xx, M, F_inf),
                a,
                b,
                xtol=1e-14,
                rtol=1e-14,
            )
        else:
            continue

        if 1e-9 < root < 1.0 - 1e-9:
            if not roots or abs(root - roots[-1]["x"]) > 1e-7:
                h = 1e-6
                gp = (
                    g_value(min(1.0, root + h), M, F_inf)
                    - g_value(max(0.0, root - h), M, F_inf)
                ) / (2.0 * h)

                roots.append({
                    "x": float(root),
                    "g_prime": float(gp),
                    "stability": "stable" if gp < 0.0 else "unstable",
                })

    return roots


# =============================================================================
# 18. EXACT ATTRACTOR-STRUCTURE CLASSIFICATION
# =============================================================================

TOL = 1e-10

CLASS_ORDER = [
    "Unique focal",
    "Pure H-E bistability",
    "Pure-competitor + stable mixed",
    "Unique competitor",
    "Critical boundary",
]

CLASS_TO_CODE = {label: i for i, label in enumerate(CLASS_ORDER)}
CODE_TO_CLASS = {i: label for label, i in CLASS_TO_CODE.items()}

CLASS_COLORS = {
    "Unique focal": "#6F8FA6",                  # blue
    "Pure H-E bistability": "#B58A7B",          # clay
    "Pure-competitor + stable mixed": "#D4C7B5",# light tan
    "Unique competitor": "#566B5C",             # green
    "Critical boundary": "#EFEDE8",              # light neutral
}


def classify_structure(M, F_inf):
    """
    Generic focal-share classification.

    s0 = 1
    s1 = s(1)
    smin = min s(x)

    Let r = M/F.

    If M <= 0:
        focal is already privately inferior before infrastructure,
        so the competitor is unique.

    If F = 0 and M > 0:
        focal is unique.

    For F > 0, the exact thresholds are:
        F1 = M/s0   = M
        F2 = M/s1
        F3 = M/smin

    Regimes:
        F < F1:       unique focal
        F1<F<F2:      both pure endpoints stable
        F2<F<F3:      competitor pure + stable interior mixed coexist
        F > F3:       unique competitor
    """

    if M < -TOL:
        return "Unique competitor"

    if abs(M) <= TOL:
        return "Critical boundary"

    if F_inf <= TOL:
        return "Unique focal"

    F1 = M / S_0
    F2 = M / S_1
    F3 = M / S_MIN

    if (
        abs(F_inf - F1) <= 1e-8
        or abs(F_inf - F2) <= 1e-8
        or abs(F_inf - F3) <= 1e-8
    ):
        return "Critical boundary"

    if F_inf < F1:
        return "Unique focal"

    if F_inf < F2:
        return "Pure H-E bistability"

    if F_inf < F3:
        return "Pure-competitor + stable mixed"

    return "Unique competitor"


# =============================================================================
# 19. BUILD ANALYTICAL MAPS
# =============================================================================

summary_rows = []
threshold_rows = []

for scenario_name, cfg in CONFIGS.items():

    rho_values = np.asarray(cfg["rho_values"], dtype=float)
    F_values = np.asarray(cfg["F_values"], dtype=float)

    matrix = np.empty(
        (len(F_values), len(rho_values)),
        dtype=int,
    )

    map_rows = []

    # Threshold curves as functions of rho.
    F1_curve = []
    F2_curve = []
    F3_curve = []
    M_curve = []

    for rho in rho_values:
        M, Pi, p = focal_margin(scenario_name, rho)

        M_curve.append(M)

        if M > 0.0:
            F1_curve.append(M / S_0)
            F2_curve.append(M / S_1)
            F3_curve.append(M / S_MIN)
        else:
            F1_curve.append(np.nan)
            F2_curve.append(np.nan)
            F3_curve.append(np.nan)

    threshold_df = pd.DataFrame({
        "Scenario": scenario_name,
        "rho": rho_values,
        "M_rho_CAD_per_RVK": M_curve,
        "F1_invasion_threshold_M_over_s0": F1_curve,
        "F2_focal_corner_loss_M_over_s1": F2_curve,
        "F3_saddle_node_M_over_smin": F3_curve,
    })

    threshold_df.to_csv(
        MAP_DIR / f"{scenario_name}_analytical_threshold_curves.csv",
        index=False,
    )

    for iy, F_inf in enumerate(F_values):
        for ix, rho in enumerate(rho_values):

            M, Pi, p = focal_margin(scenario_name, rho)

            label = classify_structure(M, float(F_inf))
            matrix[iy, ix] = CLASS_TO_CODE[label]

            roots = find_interior_roots(M, float(F_inf))

            stable_roots = [r for r in roots if r["stability"] == "stable"]
            unstable_roots = [r for r in roots if r["stability"] == "unstable"]

            map_rows.append({
                "Scenario": scenario_name,
                "Focal": cfg["focal"],
                "Competitor": cfg["competitor"],
                "rho": float(rho),
                "F_inf_CAD_per_RVK": float(F_inf),
                "M_rho_CAD_per_RVK": float(M),
                "Analytical_class": label,

                "F1": (M / S_0) if M > 0 else np.nan,
                "F2": (M / S_1) if M > 0 else np.nan,
                "F3": (M / S_MIN) if M > 0 else np.nan,

                "Interior_root_count": len(roots),
                "Stable_interior_root_count": len(stable_roots),
                "Unstable_interior_root_count": len(unstable_roots),

                "Stable_mixed_focal_share_x":
                    stable_roots[0]["x"] if stable_roots else np.nan,

                "Unstable_threshold_focal_share_x":
                    unstable_roots[0]["x"] if unstable_roots else np.nan,
            })

    map_df = pd.DataFrame(map_rows)

    map_df.to_csv(
        MAP_DIR / f"{scenario_name}_analytical_bifurcation_map.csv",
        index=False,
    )

    # Save plotting matrix.
    pd.DataFrame(
        matrix,
        index=F_values,
        columns=rho_values,
    ).to_csv(
        MAP_DIR / f"{scenario_name}_analytical_outcome_matrix.csv"
    )

    counts = map_df["Analytical_class"].value_counts().to_dict()

    row = {
        "Scenario": scenario_name,
        "Grid_points": len(map_df),
    }

    for label in CLASS_ORDER:
        row[label] = int(counts.get(label, 0))

    summary_rows.append(row)

    # -------------------------------------------------------------------------
    # Figure
    # -------------------------------------------------------------------------

    colors = [CLASS_COLORS[label] for label in CLASS_ORDER]
    cmap = ListedColormap(colors)
    bounds = np.arange(-0.5, len(CLASS_ORDER) + 0.5, 1.0)
    norm = BoundaryNorm(bounds, cmap.N)

    fig, ax = plt.subplots(figsize=(6.9, 5.6))

    ax.pcolormesh(
        rho_values,
        F_values,
        matrix,
        cmap=cmap,
        norm=norm,
        shading="nearest",
        edgecolors="none",
        antialiased=False,
    )

    # Exact analytical threshold curves.
    M_arr = np.asarray(M_curve)
    F1_arr = np.asarray(F1_curve)
    F2_arr = np.asarray(F2_curve)
    F3_arr = np.asarray(F3_curve)

    valid1 = np.isfinite(F1_arr) & (F1_arr >= F_values.min()) & (F1_arr <= F_values.max())
    valid2 = np.isfinite(F2_arr) & (F2_arr >= F_values.min()) & (F2_arr <= F_values.max())
    valid3 = np.isfinite(F3_arr) & (F3_arr >= F_values.min()) & (F3_arr <= F_values.max())

    if np.any(valid1):
        ax.plot(
            rho_values[valid1],
            F1_arr[valid1],
            color="#222222",
            linestyle=":",
            linewidth=1.15,
            label=r"$F_1$: competitor-corner invasion threshold",
        )

    if np.any(valid2):
        ax.plot(
            rho_values[valid2],
            F2_arr[valid2],
            color="#222222",
            linestyle="--",
            linewidth=1.15,
            label=r"$F_2$: focal pure-corner stability loss",
        )

    if np.any(valid3):
        ax.plot(
            rho_values[valid3],
            F3_arr[valid3],
            color="#222222",
            linestyle="-.",
            linewidth=1.15,
            label=r"$F_3$: mixed-attractor saddle-node",
        )

    ax.scatter(
        [1.0],
        [0.0],
        marker="*",
        s=85,
        facecolor="white",
        edgecolor="black",
        linewidth=0.9,
        zorder=6,
    )

    ax.annotate(
        "Benchmark",
        xy=(1.0, 0.0),
        xytext=(8, 8),
        textcoords="offset points",
        fontsize=8.6,
        va="bottom",
    )

    ax.set_xlabel(cfg["x_label"])
    ax.set_ylabel(cfg["y_label"])
    ax.set_title(
        cfg["title"] + "\nAnalytical nonlinear-infrastructure bifurcation structure",
        fontweight="semibold",
        pad=8,
    )

    ax.set_xlim(rho_values.min(), rho_values.max())
    ax.set_ylim(F_values.min(), F_values.max())
    ax.grid(False)

    handles = [
        Patch(
            facecolor=CLASS_COLORS[label],
            edgecolor="black",
            linewidth=0.45,
            label=label,
        )
        for label in CLASS_ORDER
        if label in set(map_df["Analytical_class"])
    ]

    handles.extend([
        Line2D([0], [0], color="#222222", linestyle=":", linewidth=1.15,
               label=r"$F_1=M/s(0)$"),
        Line2D([0], [0], color="#222222", linestyle="--", linewidth=1.15,
               label=r"$F_2=M/s(1)$"),
        Line2D([0], [0], color="#222222", linestyle="-.", linewidth=1.15,
               label=r"$F_3=M/s_{\min}$"),
    ])

    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.15),
        ncol=2,
        frameon=False,
        fontsize=8.2,
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR / f"{scenario_name}_analytical_infrastructure_bifurcation.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )

    fig.savefig(
        FIG_DIR / f"{scenario_name}_analytical_infrastructure_bifurcation.pdf",
        bbox_inches="tight",
        pad_inches=0.04,
    )

    plt.show()
    plt.close(fig)


# =============================================================================
# 20. SAVE GLOBAL SUMMARY
# =============================================================================

summary_df = pd.DataFrame(summary_rows)

summary_df.to_csv(
    CSV_DIR / "analytical_map_outcome_summary.csv",
    index=False,
)

shape_summary_df = pd.DataFrame([{
    "lambda_inf": LAMBDA_INF,
    "a_eta": A_ETA,
    "a_zeta": A_ZETA,
    "xbar": XBAR,
    "x_min": X_MIN,
    "s0": S_0,
    "s1": S_1,
    "s_min": S_MIN,
    "F2_over_F1": S_0 / S_1,
    "F3_over_F1": S_0 / S_MIN,
}])

shape_summary_df.to_csv(
    CSV_DIR / "exact_infrastructure_shape_bifurcation_constants.csv",
    index=False,
)


# =============================================================================
# 21. EXACT rho=1 THRESHOLD TABLE
# =============================================================================

rho1_rows = []

for scenario_name, cfg in CONFIGS.items():

    M, Pi, p = focal_margin(scenario_name, 1.0)

    rho1_rows.append({
        "Scenario": scenario_name,
        "Focal": cfg["focal"],
        "Competitor": cfg["competitor"],
        "M_at_rho1": M,
        "F1_at_rho1": M / S_0,
        "F2_at_rho1": M / S_1,
        "F3_at_rho1": M / S_MIN,
    })

rho1_df = pd.DataFrame(rho1_rows)

rho1_df.to_csv(
    CSV_DIR / "rho1_exact_bifurcation_thresholds.csv",
    index=False,
)


# =============================================================================
# 22. PRINT
# =============================================================================

print("=" * 110)
print("PHASE 4D-1C — ANALYTICAL INFRASTRUCTURE BIFURCATION AUDIT")
print("=" * 110)

print("\nNORMALIZED INFRASTRUCTURE SHAPE")
print("-" * 110)

print(f"s(0)   = {S_0:.9f}")
print(f"s(1)   = {S_1:.9f}")
print(f"s_min  = {S_MIN:.9f}")
print(f"x_min  = {X_MIN:.9f}")

print(
    f"F2/F1  = {S_0/S_1:.6f}"
)

print(
    f"F3/F1  = {S_0/S_MIN:.6f}"
)

print("\nEXACT rho=1 BIFURCATION THRESHOLDS")
print("-" * 110)

for _, row in rho1_df.iterrows():

    print(
        f"\n{row['Scenario']} | "
        f"focal={row['Focal']} vs {row['Competitor']}"
    )

    print(
        f"  M(rho=1) = {row['M_at_rho1']:.6f} CAD/RVK"
    )

    print(
        f"  F1 = {row['F1_at_rho1']:.6f} "
        "(loss of unique focal attraction / competitor becomes locally stable)"
    )

    print(
        f"  F2 = {row['F2_at_rho1']:.6f} "
        "(focal pure corner loses local stability)"
    )

    print(
        f"  F3 = {row['F3_at_rho1']:.6f} "
        "(stable mixed attractor disappears in saddle-node)"
    )


print("\nANALYTICAL MAP COUNTS")
print("-" * 110)

for _, row in summary_df.iterrows():

    print(f"\n{row['Scenario']}")

    for label in CLASS_ORDER:

        count = int(row[label])

        if count > 0:

            print(
                f"  {label}: {count}"
            )


print("\nINTERPRETATION")
print("-" * 110)

print(
    "  F < F1: focal clean technology is the unique H-E attractor."
)
print(
    "  F1 < F < F2: both pure H and pure E endpoints are locally stable "
    "(true pure H-E bistability)."
)
print(
    "  F2 < F < F3: the competitor pure endpoint coexists with a stable "
    "interior H-E mix; the focal pure corner is no longer stable."
)
print(
    "  F > F3: the competitor is the unique H-E attractor."
)

print("\nFiles saved under:")
print(f"  {OUT_DIR.resolve()}")

print("\nCSV RESULTS")
print("  exact_infrastructure_shape_bifurcation_constants.csv")
print("  rho1_exact_bifurcation_thresholds.csv")
print("  analytical_map_outcome_summary.csv")
print("  analytical_maps/*_analytical_threshold_curves.csv")
print("  analytical_maps/*_analytical_bifurcation_map.csv")
print("  analytical_maps/*_analytical_outcome_matrix.csv")

print("\nPhase 4D-1C completed.")
