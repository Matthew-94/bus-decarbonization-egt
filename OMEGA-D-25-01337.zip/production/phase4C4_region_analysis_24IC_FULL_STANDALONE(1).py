# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================
# 12. STRUCTURED 24-POINT INITIAL-CONDITION DESIGN
# =============================================================================

TECH_COMPOSITIONS = [
    # label, z0(H), w0(E); D0 = 1-z0-w0

    ("D-heavy, slight E tilt",        0.05, 0.10),  # D=0.85
    ("D-heavy, slight H tilt",        0.10, 0.05),  # D=0.85

    ("E-heavy",                       0.05, 0.75),  # D=0.20
    ("H-heavy",                       0.75, 0.05),  # D=0.20

    ("E-leaning mixed",               0.20, 0.55),  # D=0.25
    ("H-leaning mixed",               0.55, 0.20),  # D=0.25

    ("Three-way balanced",            0.30, 0.30),  # D=0.40
    ("Green-heavy H/E balanced",      0.45, 0.45),  # D=0.10
]

POLICY_START_LEVELS = [
    ("Low policy",    0.10),
    ("Medium policy", 0.50),
    ("High policy",   0.90),
]

INITIAL_CONDITIONS_24 = {}
INITIAL_CONDITION_METADATA = []

ic_counter = 1

for composition_label, z0, w0 in TECH_COMPOSITIONS:

    D0 = 1.0 - z0 - w0

    for policy_label, y0 in POLICY_START_LEVELS:

        ic_name = f"IC{ic_counter:02d}"

        INITIAL_CONDITIONS_24[ic_name] = (
            z0,
            w0,
            y0,
        )

        INITIAL_CONDITION_METADATA.append(
            {
                "IC": ic_name,
                "Composition_group": composition_label,
                "Policy_group": policy_label,
                "z0_H": z0,
                "w0_E": w0,
                "D0": D0,
                "y0": y0,
            }
        )

        ic_counter += 1


IC_NAMES = list(INITIAL_CONDITIONS_24.keys())

IC_ARRAY = np.array(
    list(INITIAL_CONDITIONS_24.values()),
    dtype=float,
)

N_IC = len(IC_NAMES)

assert N_IC == 24


# =============================================================================
# 13. REGION-ANALYSIS OUTPUT FOLDERS
# =============================================================================

REGION_OUTPUT_DIR = Path("Phase4C4_region_analysis_24IC")
REGION_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

REGION_CSV_DIR = REGION_OUTPUT_DIR / "csv_results"
REGION_CSV_DIR.mkdir(parents=True, exist_ok=True)

GRID_DETAIL_DIR = REGION_CSV_DIR / "grid_IC_level_results"
GRID_DETAIL_DIR.mkdir(parents=True, exist_ok=True)

GRID_CONSENSUS_DIR = REGION_CSV_DIR / "grid_consensus_results"
GRID_CONSENSUS_DIR.mkdir(parents=True, exist_ok=True)

GRID_MATRIX_DIR = REGION_CSV_DIR / "plotting_matrices"
GRID_MATRIX_DIR.mkdir(parents=True, exist_ok=True)

BENCHMARK_DIR = REGION_CSV_DIR / "benchmark_24IC"
BENCHMARK_DIR.mkdir(parents=True, exist_ok=True)

FIGURE_DIR = REGION_OUTPUT_DIR / "figures"
FIGURE_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 14. SAVE INITIAL-CONDITION DESIGN
# =============================================================================

initial_condition_df = pd.DataFrame(
    INITIAL_CONDITION_METADATA
)

initial_condition_df.to_csv(
    REGION_CSV_DIR / "initial_conditions_24.csv",
    index=False,
)


# =============================================================================
# 15. NUMERICAL SETTINGS
# =============================================================================

SCENARIOS = ["S1", "S2", "S3"]

# Certification grid. If the resulting boundaries are clean and selected for
# the paper, this can later be increased to 31 or 41 without changing the model.
GRID_N = 31

# Long horizon because some S3 paths approach H_A relatively slowly.
BASE_TAU_END = 220.0
ADAPTIVE_TAU_HORIZONS = (500.0, 1000.0, 2000.0)
TAU_END = BASE_TAU_END  # retained for reporting compatibility

# Classification tolerances
PURE_SHARE_TOL = 0.98
POLICY_BOUNDARY_TOL = 0.98
RHS_STATIONARITY_TOL = 1e-7

# Numerical simplex projection tolerance. The exact replicator system preserves
# H+E+D=1; violations below this level are treated as solver roundoff only.
SIMPLEX_NUMERICAL_TOL = 1e-5

# Visual-only boundary smoothing. CSV/grid classifications remain exact.
SMOOTH_PLOT_BOUNDARIES = True
SMOOTHING_SIGMA = 0.65
DISPLAY_ZOOM = 6


# =============================================================================
# 16. SENSITIVITY MAP DEFINITIONS
# =============================================================================

MAP_CONFIGS = {

    # -------------------------------------------------------------------------
    # A) Three-way capital competition.
    # Wide stress-test range intentionally allows H, E, and potentially D
    # regions to emerge without altering the baseline model structure.
    # -------------------------------------------------------------------------

    "capital_competition": {
        "x_param": "R_H",
        "x_values": np.linspace(
            400_000.0,
            2_500_000.0,
            GRID_N,
        ),
        "y_param": "R_E",
        "y_values": np.linspace(
            400_000.0,
            2_500_000.0,
            GRID_N,
        ),
        "x_label": r"Hydrogen bus acquisition cost, $R_H$ (million CAD/bus)",
        "y_label": r"Electric bus acquisition cost, $R_E$ (million CAD/bus)",
        "x_scale_for_plot": 1e6,
        "y_scale_for_plot": 1e6,
        "title_stub": "Capital-cost competition",
    },

    # -------------------------------------------------------------------------
    # B) Direct test of the hydrogen technology-learning assumption.
    # -------------------------------------------------------------------------

    "hydrogen_learning": {
        "x_param": "fuel_H",
        "x_values": np.linspace(
            1.0,
            15.0,
            GRID_N,
        ),
        "y_param": "C_hat_H",
        "y_values": np.linspace(
            0.40,
            2.40,
            GRID_N,
        ),
        "x_label": r"Hydrogen price, $f_H$ (CAD/kg)",
        "y_label": r"Hydrogen non-energy operating cost, $\hat C_H$ (CAD/RVK)",
        "x_scale_for_plot": 1.0,
        "y_scale_for_plot": 1.0,
        "title_stub": "Hydrogen operating-learning frontier",
    },

    # -------------------------------------------------------------------------
    # C) Policy-differentiation map.
    #
    # 0--2 CAD/boarding is intentionally wider than the benchmark. It is a
    # stress-test range, not a claim about a specific subsidy program.
    # -------------------------------------------------------------------------

    "policy_support": {
        "x_param": "S_H",
        "x_values": np.linspace(
            0.0,
            2.0,
            GRID_N,
        ),
        "y_param": "S_E",
        "y_values": np.linspace(
            0.0,
            2.0,
            GRID_N,
        ),
        "x_label": r"Hydrogen support intensity, $S_H$ (CAD/boarding)",
        "y_label": r"Electric support intensity, $S_E$ (CAD/boarding)",
        "x_scale_for_plot": 1.0,
        "y_scale_for_plot": 1.0,
        "title_stub": "Environmental-policy support frontier",
    },
}


# =============================================================================
# 17. BATCHED REPLICATOR DYNAMICS FOR 24 INITIAL CONDITIONS
# =============================================================================

def batch_replicator_rhs(
    tau: float,
    flat_state: np.ndarray,
    p: Parameters,
    n_ic: int,
) -> np.ndarray:
    """
    Integrate n_ic independent replicator systems simultaneously.

    flat_state is reshaped to:
        [n_ic, 3]

    with columns:
        z, w, y
    """

    X = np.asarray(
        flat_state,
        dtype=float,
    ).reshape(n_ic, 3)

    z = X[:, 0]
    w = X[:, 1]
    y = X[:, 2]

    D = 1.0 - z - w

    d = derived_quantities(p)

    Pi_H = (
        d["pi_H_B"]
        + y * p.S_H * d["q_H"]
    )

    Pi_E = (
        d["pi_E_B"]
        + y * p.S_E * d["q_E"]
    )

    Pi_D = (
        d["pi_D_B"]
        - y * p.T_D * d["q_D"]
    )

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + D * Pi_D
    )

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    dz = (
        p.eta_TO
        * z
        * (Pi_H - Pi_bar)
    )

    dw = (
        p.eta_TO
        * w
        * (Pi_E - Pi_bar)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * policy_advantage
    )

    return np.column_stack(
        [dz, dw, dy]
    ).reshape(-1)


def _state_resolution_mask(
    final_matrix: np.ndarray,
    p: Parameters,
) -> np.ndarray:
    """
    True where an IC is already resolved as either:
      - near a pure technology corner, or
      - near a stationary mixed state.
    """

    final_matrix = np.asarray(final_matrix, dtype=float)

    z = np.clip(final_matrix[:, 0], 0.0, 1.0)
    w = np.clip(final_matrix[:, 1], 0.0, 1.0)
    y = np.clip(final_matrix[:, 2], 0.0, 1.0)

    total_green = z + w
    over = total_green > 1.0

    # Project only tiny numerical overshoot back to the exact simplex.
    z_proj = z.copy()
    w_proj = w.copy()

    if np.any(over):
        excess = total_green[over] - 1.0
        if np.any(excess > SIMPLEX_NUMERICAL_TOL):
            raise RuntimeError(
                "Material simplex violation during adaptive solve: "
                f"max excess={float(np.max(excess)):.3e}."
            )
        z_proj[over] = z[over] / total_green[over]
        w_proj[over] = w[over] / total_green[over]

    D = np.maximum(0.0, 1.0 - z_proj - w_proj)

    pure = (
        (z_proj >= PURE_SHARE_TOL)
        | (w_proj >= PURE_SHARE_TOL)
        | (D >= PURE_SHARE_TOL)
    )

    rhs_norms = np.empty(len(final_matrix), dtype=float)

    for i in range(len(final_matrix)):
        rhs = replicator_rhs(
            0.0,
            np.array([z_proj[i], w_proj[i], y[i]], dtype=float),
            p,
        )
        rhs_norms[i] = np.max(np.abs(rhs))

    stationary = rhs_norms <= RHS_STATIONARITY_TOL

    return pure | stationary


def _solve_batch_to_horizon(
    p: Parameters,
    initial_matrix: np.ndarray,
    start_tau: float,
    end_tau: float,
) -> np.ndarray:
    """Solve a batch of independent ICs from start_tau to end_tau."""

    initial_matrix = np.asarray(initial_matrix, dtype=float)
    n_ic = initial_matrix.shape[0]

    sol = solve_ivp(
        fun=lambda tau, state: batch_replicator_rhs(
            tau, state, p, n_ic
        ),
        t_span=(start_tau, end_tau),
        y0=initial_matrix.reshape(-1),
        t_eval=[end_tau],
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
        max_step=5.0,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol.y[:, -1].reshape(n_ic, 3)


def solve_24_initial_conditions(
    p: Parameters,
    initial_matrix: np.ndarray = IC_ARRAY,
    tau_end: float = BASE_TAU_END,
):
    """
    Adaptive multi-start solve.

    First integrates all ICs to tau=220. Any IC that is neither near a
    technology corner nor near a stationary mixed state is then extended only
    as needed to tau=500, 1000, and finally 2000.

    Returns
    -------
    final_matrix : [N_IC, 3]
        Final [z,w,y] states.
    effective_tau : [N_IC]
        Horizon actually required by each IC.
    resolution_status : [N_IC] object array
        'Resolved by tau=...' or 'Persistent/very-slow at tau=2000'.
    """

    initial_matrix = np.asarray(initial_matrix, dtype=float)

    final_matrix = _solve_batch_to_horizon(
        p=p,
        initial_matrix=initial_matrix,
        start_tau=0.0,
        end_tau=float(tau_end),
    )

    n_ic = final_matrix.shape[0]
    effective_tau = np.full(n_ic, float(tau_end), dtype=float)
    resolution_status = np.array(
        [f"Resolved by tau={tau_end:g}"] * n_ic,
        dtype=object,
    )

    resolved = _state_resolution_mask(final_matrix, p)

    current_tau = float(tau_end)

    for target_tau in ADAPTIVE_TAU_HORIZONS:

        unresolved_idx = np.where(~resolved)[0]

        if len(unresolved_idx) == 0:
            break

        subset_final = _solve_batch_to_horizon(
            p=p,
            initial_matrix=final_matrix[unresolved_idx],
            start_tau=current_tau,
            end_tau=float(target_tau),
        )

        final_matrix[unresolved_idx] = subset_final
        effective_tau[unresolved_idx] = float(target_tau)

        subset_resolved = _state_resolution_mask(subset_final, p)

        newly_resolved_idx = unresolved_idx[subset_resolved]
        resolution_status[newly_resolved_idx] = (
            f"Resolved by tau={target_tau:g}"
        )

        resolved[unresolved_idx] = subset_resolved
        current_tau = float(target_tau)

    still_unresolved = np.where(~resolved)[0]

    if len(still_unresolved) > 0:
        resolution_status[still_unresolved] = (
            f"Persistent/very-slow at tau={ADAPTIVE_TAU_HORIZONS[-1]:g}"
        )

    return final_matrix, effective_tau, resolution_status


# =============================================================================
# 18. FINAL-STATE SANITIZATION / CLASSIFICATION
# =============================================================================

def sanitize_final_state(
    state: Iterable[float],
) -> Tuple[float, float, float, float]:
    """
    Project only tiny numerical solver drift back to the exact technology
    simplex. This does not alter the mathematical model; the exact replicator
    dynamics preserve z+w+D=1.
    """

    z, w, y = map(float, state)

    z = float(np.clip(z, 0.0, 1.0))
    w = float(np.clip(w, 0.0, 1.0))
    y = float(np.clip(y, 0.0, 1.0))

    total_green = z + w

    if total_green > 1.0:
        excess = total_green - 1.0

        if excess > SIMPLEX_NUMERICAL_TOL:
            raise RuntimeError(
                "Material fleet/service-share simplex violation: "
                f"H+E exceeds 1 by {excess:.3e}."
            )

        # Exact projection of tiny numerical overshoot.
        z = z / total_green
        w = w / total_green

    D = 1.0 - z - w

    # Avoid negative signed-zero / tiny roundoff in exported files.
    if abs(D) < 1e-12:
        D = 0.0

    D = float(np.clip(D, 0.0, 1.0))

    return z, w, D, y


def classify_one_final_state(
    final_state: Iterable[float],
    p: Parameters,
) -> Dict[str, object]:

    z, w, D, y = sanitize_final_state(
        final_state
    )

    rhs = replicator_rhs(
        0.0,
        np.array(
            [z, w, y],
            dtype=float,
        ),
        p,
    )

    rhs_norm = float(
        np.max(
            np.abs(rhs)
        )
    )

    # -------------------------------------------------------------------------
    # Technology classification
    # -------------------------------------------------------------------------

    if z >= PURE_SHARE_TOL:
        tech_class = "H"

    elif w >= PURE_SHARE_TOL:
        tech_class = "E"

    elif D >= PURE_SHARE_TOL:
        tech_class = "D"

    else:

        if rhs_norm <= RHS_STATIONARITY_TOL:
            tech_class = "Mixed"

        else:
            tech_class = "Persistent"

    # -------------------------------------------------------------------------
    # Policy classification
    # -------------------------------------------------------------------------

    if y >= POLICY_BOUNDARY_TOL:
        policy_class = "A"

    elif y <= (1.0 - POLICY_BOUNDARY_TOL):
        policy_class = "B"

    else:
        policy_class = "I"

    # -------------------------------------------------------------------------
    # Full regime label
    # -------------------------------------------------------------------------

    if tech_class in {"H", "E", "D"}:
        full_regime = f"{tech_class}_{policy_class}"

    elif tech_class == "Mixed":
        full_regime = "Mixed"

    else:
        full_regime = "Persistent"

    simplex_sum = z + w + D

    if not np.isfinite(simplex_sum) or abs(simplex_sum - 1.0) > 1e-10:
        raise RuntimeError(
            f"Invalid fleet/service-share simplex: H+E+D={simplex_sum:.12f}."
        )

    return {
        "Final_H": z,
        "Final_E": w,
        "Final_D": D,
        "Final_y": y,
        "Fleet_share_sum": simplex_sum,
        "RHS_norm": rhs_norm,
        "Technology_class": tech_class,
        "Policy_class": policy_class,
        "Full_regime": full_regime,
    }


# =============================================================================
# 19. CONSENSUS CLASSIFICATION ACROSS ALL 24 INITIAL CONDITIONS
# =============================================================================

def consensus_from_IC_results(
    ic_result_df: pd.DataFrame,
) -> Dict[str, object]:

    tech_classes = list(
        ic_result_df["Technology_class"]
    )

    full_regimes = list(
        ic_result_df["Full_regime"]
    )

    unique_tech = sorted(
        set(tech_classes)
    )

    unique_full = sorted(
        set(full_regimes)
    )

    frac_H = float(
        np.mean(
            ic_result_df["Technology_class"] == "H"
        )
    )

    frac_E = float(
        np.mean(
            ic_result_df["Technology_class"] == "E"
        )
    )

    frac_D = float(
        np.mean(
            ic_result_df["Technology_class"] == "D"
        )
    )

    frac_Mixed = float(
        np.mean(
            ic_result_df["Technology_class"] == "Mixed"
        )
    )

    frac_Persistent = float(
        np.mean(
            ic_result_df["Technology_class"] == "Persistent"
        )
    )

    # -------------------------------------------------------------------------
    # Technology-level consensus used for the principal region map
    # -------------------------------------------------------------------------

    if frac_Persistent > 0.0:

        technology_consensus = "Persistent/very-slow"

    elif len(unique_tech) == 1:

        only = unique_tech[0]

        if only == "H":
            technology_consensus = "Robust H"

        elif only == "E":
            technology_consensus = "Robust E"

        elif only == "D":
            technology_consensus = "Robust D"

        elif only == "Mixed":
            technology_consensus = "Robust Mixed"

        else:
            technology_consensus = only

    else:

        technology_consensus = "Path-dependent"

    # -------------------------------------------------------------------------
    # Full equilibrium/policy consensus
    # -------------------------------------------------------------------------

    if len(unique_full) == 1:
        full_regime_consensus = unique_full[0]

    else:
        full_regime_consensus = "Multiple regimes"

    return {
        "Technology_consensus": technology_consensus,
        "Full_regime_consensus": full_regime_consensus,

        "Fraction_H": frac_H,
        "Fraction_E": frac_E,
        "Fraction_D": frac_D,
        "Fraction_Mixed": frac_Mixed,
        "Fraction_Persistent": frac_Persistent,

        "Mean_final_H": float(
            ic_result_df["Final_H"].mean()
        ),

        "Mean_final_E": float(
            ic_result_df["Final_E"].mean()
        ),

        "Mean_final_D": float(
            ic_result_df["Final_D"].mean()
        ),

        "Mean_final_y": float(
            ic_result_df["Final_y"].mean()
        ),

        "Max_RHS_norm": float(
            ic_result_df["RHS_norm"].max()
        ),
    }


# =============================================================================
# 20. REGION-MAP CODEBOOK
# =============================================================================

MAP_CLASS_TO_CODE = {
    "Robust D": 0,
    "Robust E": 1,
    "Robust H": 2,
    "Robust Mixed": 3,
    "Path-dependent": 4,
    "Persistent/very-slow": 5,
}

MAP_CODE_TO_CLASS = {
    value: key
    for key, value in MAP_CLASS_TO_CODE.items()
}

codebook_df = pd.DataFrame(
    [
        {
            "Outcome_code": code,
            "Outcome_class": label,
        }
        for label, code in MAP_CLASS_TO_CODE.items()
    ]
)

codebook_df.to_csv(
    REGION_CSV_DIR / "outcome_codebook.csv",
    index=False,
)


# =============================================================================
# 21. BENCHMARK 24-INITIAL-CONDITION CERTIFICATION
# =============================================================================

benchmark_rows = []

print("=" * 110)
print("PHASE 4C-4 — 24-INITIAL-CONDITION BENCHMARK CERTIFICATION")
print("=" * 110)

for scenario_name in SCENARIOS:

    p = make_scenario(
        scenario_name
    )

    final_matrix, effective_tau, resolution_status = solve_24_initial_conditions(
        p
    )

    scenario_rows = []

    for ic_index, ic_name in enumerate(
        IC_NAMES
    ):

        result = classify_one_final_state(
            final_matrix[ic_index],
            p,
        )

        meta = initial_condition_df.loc[
            initial_condition_df["IC"] == ic_name
        ].iloc[0]

        row = {
            "Scenario": scenario_name,
            "IC": ic_name,
            "z0_H": meta["z0_H"],
            "w0_E": meta["w0_E"],
            "D0": meta["D0"],
            "y0": meta["y0"],
            "Effective_tau": effective_tau[ic_index],
            "Resolution_status": resolution_status[ic_index],
            **result,
        }

        benchmark_rows.append(row)
        scenario_rows.append(row)

    scenario_df = pd.DataFrame(
        scenario_rows
    )

    consensus = consensus_from_IC_results(
        scenario_df
    )

    print(f"\n{scenario_name}")
    print("-" * 80)

    print(
        f"Technology consensus across 24 ICs: "
        f"{consensus['Technology_consensus']}"
    )

    print(
        f"Full-regime consensus: "
        f"{consensus['Full_regime_consensus']}"
    )

    print(
        f"Fractions: "
        f"H={consensus['Fraction_H']:.3f}, "
        f"E={consensus['Fraction_E']:.3f}, "
        f"D={consensus['Fraction_D']:.3f}, "
        f"Mixed={consensus['Fraction_Mixed']:.3f}, "
        f"Persistent={consensus['Fraction_Persistent']:.3f}"
    )


benchmark_df = pd.DataFrame(
    benchmark_rows
)

benchmark_df.to_csv(
    BENCHMARK_DIR
    / "benchmark_24IC_final_states.csv",
    index=False,
)


# =============================================================================
# 22. RUN ONE COMPLETE MAP
# =============================================================================

def run_region_map(
    scenario_name: str,
    map_name: str,
    config: Dict[str, object],
) -> Tuple[pd.DataFrame, pd.DataFrame]:

    base_p = make_scenario(
        scenario_name
    )

    x_param = config["x_param"]
    y_param = config["y_param"]

    x_values = np.asarray(
        config["x_values"],
        dtype=float,
    )

    y_values = np.asarray(
        config["y_values"],
        dtype=float,
    )

    detail_rows = []
    consensus_rows = []

    total_points = (
        len(x_values)
        * len(y_values)
    )

    point_counter = 0

    print(
        f"\nRunning {scenario_name} | {map_name} "
        f"({len(x_values)} x {len(y_values)} = {total_points} grid points; "
        f"24 ICs per point)"
    )

    for iy, y_value in enumerate(
        y_values
    ):

        for ix, x_value in enumerate(
            x_values
        ):

            point_counter += 1

            p = replace(
                base_p,
                **{
                    x_param: float(x_value),
                    y_param: float(y_value),
                },
            )

            final_matrix, effective_tau, resolution_status = solve_24_initial_conditions(
                p
            )

            point_ic_rows = []

            for ic_index, ic_name in enumerate(
                IC_NAMES
            ):

                result = classify_one_final_state(
                    final_matrix[ic_index],
                    p,
                )

                row = {
                    "Scenario": scenario_name,
                    "Map": map_name,

                    "Grid_ix": ix,
                    "Grid_iy": iy,

                    "x_param": x_param,
                    "y_param": y_param,

                    "x_value": float(x_value),
                    "y_value": float(y_value),

                    "IC": ic_name,
                    "Effective_tau": effective_tau[ic_index],
                    "Resolution_status": resolution_status[ic_index],

                    **result,
                }

                detail_rows.append(row)
                point_ic_rows.append(row)

            point_ic_df = pd.DataFrame(
                point_ic_rows
            )

            consensus = consensus_from_IC_results(
                point_ic_df
            )

            thresholds = policy_thresholds(
                p
            )

            consensus_row = {
                "Scenario": scenario_name,
                "Map": map_name,

                "Grid_ix": ix,
                "Grid_iy": iy,

                "x_param": x_param,
                "y_param": y_param,

                "x_value": float(x_value),
                "y_value": float(y_value),

                **consensus,

                "y_HE_star": thresholds["y_HE"],
                "y_HD_star": thresholds["y_HD"],
                "y_ED_star": thresholds["y_ED"],
            }

            consensus_rows.append(
                consensus_row
            )

        print(
            f"  completed row {iy + 1}/{len(y_values)}"
        )

    detail_df = pd.DataFrame(
        detail_rows
    )

    consensus_df = pd.DataFrame(
        consensus_rows
    )

    return detail_df, consensus_df


# =============================================================================
# 23. SAVE PLOTTING MATRIX
# =============================================================================

def save_outcome_matrix(
    consensus_df: pd.DataFrame,
    scenario_name: str,
    map_name: str,
    config: Dict[str, object],
) -> np.ndarray:

    x_values = np.asarray(
        config["x_values"],
        dtype=float,
    )

    y_values = np.asarray(
        config["y_values"],
        dtype=float,
    )

    matrix = np.full(
        (
            len(y_values),
            len(x_values),
        ),
        -1,
        dtype=int,
    )

    for _, row in consensus_df.iterrows():

        iy = int(
            row["Grid_iy"]
        )

        ix = int(
            row["Grid_ix"]
        )

        matrix[iy, ix] = MAP_CLASS_TO_CODE[
            row["Technology_consensus"]
        ]

    matrix_df = pd.DataFrame(
        matrix,
        index=y_values,
        columns=x_values,
    )

    matrix_df.index.name = config["y_param"]
    matrix_df.columns.name = config["x_param"]

    matrix_df.to_csv(
        GRID_MATRIX_DIR
        / f"{scenario_name}_{map_name}_outcome_code_matrix.csv"
    )

    if np.any(matrix < 0):
        missing = int(np.sum(matrix < 0))
        raise RuntimeError(
            f"Outcome matrix contains {missing} unfilled grid cells for "
            f"{scenario_name} | {map_name}."
        )

    return matrix



# =============================================================================
# 23B. PUBLICATION-QUALITY FIGURE STYLE
#
# This block changes ONLY figure appearance. It does not alter the model,
# numerical solver, parameter grid, initial conditions, classifications, or CSVs.
# =============================================================================

PUBLICATION_STYLE = {
    "font_family": "DejaVu Sans",
    "font_size": 10.0,
    "axes_label_size": 10.5,
    "axes_title_size": 11.0,
    "tick_label_size": 9.5,
    "legend_font_size": 8.8,
    "axes_linewidth": 0.85,
    "tick_width": 0.75,
    "tick_length": 4.0,
    "figure_width": 6.6,
    "figure_height": 5.35,
}

plt.rcParams.update({
    "font.family": PUBLICATION_STYLE["font_family"],
    "font.size": PUBLICATION_STYLE["font_size"],
    "axes.labelsize": PUBLICATION_STYLE["axes_label_size"],
    "axes.titlesize": PUBLICATION_STYLE["axes_title_size"],
    "xtick.labelsize": PUBLICATION_STYLE["tick_label_size"],
    "ytick.labelsize": PUBLICATION_STYLE["tick_label_size"],
    "legend.fontsize": PUBLICATION_STYLE["legend_font_size"],
    "axes.linewidth": PUBLICATION_STYLE["axes_linewidth"],
    "xtick.major.width": PUBLICATION_STYLE["tick_width"],
    "ytick.major.width": PUBLICATION_STYLE["tick_width"],
    "xtick.major.size": PUBLICATION_STYLE["tick_length"],
    "ytick.major.size": PUBLICATION_STYLE["tick_length"],
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def _cell_edges(values: np.ndarray) -> np.ndarray:
    """
    Convert grid-point centers to pcolormesh cell edges.

    Works for evenly or unevenly spaced 1D grids.
    """

    values = np.asarray(values, dtype=float)

    if len(values) < 2:
        raise ValueError("At least two grid values are required.")

    midpoints = 0.5 * (values[:-1] + values[1:])

    first_edge = values[0] - 0.5 * (values[1] - values[0])
    last_edge = values[-1] + 0.5 * (values[-1] - values[-2])

    return np.concatenate(
        [[first_edge], midpoints, [last_edge]]
    )


# =============================================================================
# 24. PLOT REGION MAP
# =============================================================================

def _smooth_categorical_display(
    outcome_matrix: np.ndarray,
    zoom_factor: int = DISPLAY_ZOOM,
    sigma: float = SMOOTHING_SIGMA,
):
    """
    Produce a VISUAL-ONLY smooth categorical field from exact grid classes.

    The underlying CSV and classification matrix are never modified. Each class
    is converted to a one-hot mask, mildly Gaussian-smoothed, interpolated to a
    denser display grid, and the largest class score is selected. This removes
    staircase-looking boundaries without changing the numerical analysis.
    """

    from scipy.ndimage import gaussian_filter, zoom

    present_codes = sorted(int(v) for v in np.unique(outcome_matrix))

    score_fields = []

    for code in present_codes:
        mask = (outcome_matrix == code).astype(float)
        smooth_mask = gaussian_filter(mask, sigma=sigma, mode="nearest")
        dense_mask = zoom(smooth_mask, zoom_factor, order=3)
        score_fields.append(dense_mask)

    scores = np.stack(score_fields, axis=0)
    winner = np.argmax(scores, axis=0)

    dense_codes = np.empty_like(winner, dtype=int)

    for idx, code in enumerate(present_codes):
        dense_codes[winner == idx] = code

    return dense_codes


def plot_region_map(
    scenario_name: str,
    map_name: str,
    config: Dict[str, object],
    consensus_df: pd.DataFrame,
    outcome_matrix: np.ndarray,
):
    """
    Clean journal-style region map with optional visual boundary smoothing.

    IMPORTANT: smoothing affects only the displayed figure. Exact classifications
    remain in the saved CSVs and outcome-code matrices.
    """

    from matplotlib.colors import ListedColormap, BoundaryNorm
    from matplotlib.patches import Patch
    from matplotlib.ticker import MaxNLocator

    x_values_raw = np.asarray(config["x_values"], dtype=float)
    y_values_raw = np.asarray(config["y_values"], dtype=float)

    x_scale = float(config["x_scale_for_plot"])
    y_scale = float(config["y_scale_for_plot"])

    x_values = x_values_raw / x_scale
    y_values = y_values_raw / y_scale

    CATEGORY_COLORS = {
        "Robust D": "#A9A9A9",
        "Robust E": "#6F8FA6",
        "Robust H": "#566B5C",
        "Robust Mixed": "#D4D0C8",
        "Path-dependent": "#B58A7B",
        "Persistent/very-slow": "#EFEDE8",
    }

    ordered_labels = [
        "Robust D",
        "Robust E",
        "Robust H",
        "Robust Mixed",
        "Path-dependent",
        "Persistent/very-slow",
    ]

    cmap = ListedColormap([CATEGORY_COLORS[x] for x in ordered_labels])
    bounds = np.arange(-0.5, len(ordered_labels) + 0.5, 1.0)
    norm = BoundaryNorm(bounds, cmap.N)

    fig, ax = plt.subplots(
        figsize=(
            PUBLICATION_STYLE["figure_width"],
            PUBLICATION_STYLE["figure_height"],
        ),
        constrained_layout=True,
    )

    if SMOOTH_PLOT_BOUNDARIES:
        display_matrix = _smooth_categorical_display(outcome_matrix)
        x_dense = np.linspace(x_values.min(), x_values.max(), display_matrix.shape[1])
        y_dense = np.linspace(y_values.min(), y_values.max(), display_matrix.shape[0])

        levels = np.arange(-0.5, len(ordered_labels) + 0.5, 1.0)

        ax.contourf(
            x_dense,
            y_dense,
            display_matrix,
            levels=levels,
            cmap=cmap,
            norm=norm,
            antialiased=True,
        )

        # Smooth, continuous region boundaries.
        if len(np.unique(display_matrix)) > 1:
            ax.contour(
                x_dense,
                y_dense,
                display_matrix,
                levels=np.arange(0.5, len(ordered_labels) - 0.4, 1.0),
                colors="white",
                linewidths=1.15,
                linestyles="solid",
                alpha=0.95,
            )

    else:
        x_edges = _cell_edges(x_values)
        y_edges = _cell_edges(y_values)
        ax.pcolormesh(
            x_edges,
            y_edges,
            outcome_matrix,
            cmap=cmap,
            norm=norm,
            shading="flat",
            edgecolors="none",
        )

    base_p = make_scenario(scenario_name)

    benchmark_x = getattr(base_p, config["x_param"]) / x_scale
    benchmark_y = getattr(base_p, config["y_param"]) / y_scale

    ax.scatter(
        [benchmark_x], [benchmark_y],
        s=82, marker="*",
        facecolor="white", edgecolor="black",
        linewidth=0.9, zorder=6,
    )

    ax.annotate(
        "Benchmark",
        xy=(benchmark_x, benchmark_y),
        xytext=(7, 5),
        textcoords="offset points",
        fontsize=8.6,
        ha="left", va="bottom",
        color="black", zorder=7,
    )

    ax.set_xlabel(config["x_label"], labelpad=7)
    ax.set_ylabel(config["y_label"], labelpad=7)

    scenario_title = {
        "S1": "Baseline conditions",
        "S2": "Intermediate conditions",
        "S3": "Advanced conditions",
    }[scenario_name]

    ax.set_title(
        f"{scenario_title}\n{config['title_stub']}",
        fontweight="semibold",
        pad=9,
    )

    ax.set_xlim(x_values.min(), x_values.max())
    ax.set_ylim(y_values.min(), y_values.max())

    ax.xaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))

    ax.tick_params(
        axis="both", which="major",
        direction="in", top=False, right=False, pad=4,
    )

    ax.grid(False)

    for spine in ax.spines.values():
        spine.set_color("black")
        spine.set_linewidth(PUBLICATION_STYLE["axes_linewidth"])

    present_codes = sorted(
        int(code) for code in np.unique(outcome_matrix)
        if int(code) in MAP_CODE_TO_CLASS
    )

    legend_handles = [
        Patch(
            facecolor=CATEGORY_COLORS[MAP_CODE_TO_CLASS[code]],
            edgecolor="black",
            linewidth=0.45,
            label=MAP_CODE_TO_CLASS[code],
        )
        for code in present_codes
    ]

    if legend_handles:
        ax.legend(
            handles=legend_handles,
            loc="upper center",
            bbox_to_anchor=(0.5, -0.16),
            ncol=min(3, len(legend_handles)),
            frameon=False,
            handlelength=1.8,
            columnspacing=1.6,
            borderaxespad=0.0,
        )

    fig.savefig(
        FIGURE_DIR / f"{scenario_name}_{map_name}_smooth.png",
        dpi=600, bbox_inches="tight", pad_inches=0.04,
    )

    fig.savefig(
        FIGURE_DIR / f"{scenario_name}_{map_name}_smooth.pdf",
        bbox_inches="tight", pad_inches=0.04,
    )

    plt.show()
    plt.close(fig)


# =============================================================================
# 25. RUN ALL SCENARIOS x ALL MAPS
# =============================================================================

map_summary_rows = []

for scenario_name in SCENARIOS:

    for map_name, config in MAP_CONFIGS.items():

        detail_df, consensus_df = run_region_map(
            scenario_name=scenario_name,
            map_name=map_name,
            config=config,
        )

        detail_df.to_csv(
            GRID_DETAIL_DIR
            / f"{scenario_name}_{map_name}_IC_level_results.csv",
            index=False,
        )

        consensus_df.to_csv(
            GRID_CONSENSUS_DIR
            / f"{scenario_name}_{map_name}_consensus.csv",
            index=False,
        )

        outcome_matrix = save_outcome_matrix(
            consensus_df=consensus_df,
            scenario_name=scenario_name,
            map_name=map_name,
            config=config,
        )

        plot_region_map(
            scenario_name=scenario_name,
            map_name=map_name,
            config=config,
            consensus_df=consensus_df,
            outcome_matrix=outcome_matrix,
        )

        # ---------------------------------------------------------------------
        # Map-level summary
        # ---------------------------------------------------------------------

        counts = (
            consensus_df[
                "Technology_consensus"
            ]
            .value_counts()
            .to_dict()
        )

        row = {
            "Scenario": scenario_name,
            "Map": map_name,
            "Grid_points": len(
                consensus_df
            ),
        }

        for outcome_label in MAP_CLASS_TO_CODE:

            row[
                outcome_label
            ] = int(
                counts.get(
                    outcome_label,
                    0,
                )
            )

        map_summary_rows.append(
            row
        )


# =============================================================================
# 26. SAVE MAP-LEVEL SUMMARY
# =============================================================================

map_summary_df = pd.DataFrame(
    map_summary_rows
)

map_summary_df.to_csv(
    REGION_CSV_DIR
    / "map_level_outcome_summary.csv",
    index=False,
)


# =============================================================================
# 27. SAVE RUN CONFIGURATION
# =============================================================================

run_config_rows = []

for map_name, config in MAP_CONFIGS.items():

    run_config_rows.append(
        {
            "Map": map_name,
            "x_param": config["x_param"],
            "x_min": float(
                np.min(
                    config["x_values"]
                )
            ),
            "x_max": float(
                np.max(
                    config["x_values"]
                )
            ),
            "y_param": config["y_param"],
            "y_min": float(
                np.min(
                    config["y_values"]
                )
            ),
            "y_max": float(
                np.max(
                    config["y_values"]
                )
            ),
            "Grid_N": GRID_N,
            "N_initial_conditions": N_IC,
            "Base_tau_end": BASE_TAU_END,
            "Adaptive_tau_max": ADAPTIVE_TAU_HORIZONS[-1],
            "Pure_share_tolerance": PURE_SHARE_TOL,
            "Policy_boundary_tolerance": POLICY_BOUNDARY_TOL,
            "RHS_stationarity_tolerance": RHS_STATIONARITY_TOL,
        }
    )

run_config_df = pd.DataFrame(
    run_config_rows
)

run_config_df.to_csv(
    REGION_CSV_DIR
    / "run_configuration.csv",
    index=False,
)


# =============================================================================
# 28. FINAL PRINTED SUMMARY
# =============================================================================

print("\n")
print("=" * 110)
print("PHASE 4C-4 — REGION ANALYSIS COMPLETED")
print("=" * 110)

print(
    f"\nInitial conditions per grid point: {N_IC}"
)

print(
    f"Grid resolution per map: {GRID_N} x {GRID_N}"
)

print(
    f"Base integration horizon: tau = {BASE_TAU_END}; adaptive maximum = {ADAPTIVE_TAU_HORIZONS[-1]}"
)

print(
    f"\nOutput folder:\n  {REGION_OUTPUT_DIR.resolve()}"
)

print("\nMAP-LEVEL OUTCOME COUNTS")

for _, row in map_summary_df.iterrows():

    print(
        f"\n{row['Scenario']} | {row['Map']}"
    )

    for outcome_label in MAP_CLASS_TO_CODE:

        print(
            f"  {outcome_label}: "
            f"{int(row[outcome_label])}"
        )

print("\nCSV files include:")
print("  initial_conditions_24.csv")
print("  benchmark_24IC/benchmark_24IC_final_states.csv")
print("  grid_IC_level_results/*.csv")
print("  grid_consensus_results/*.csv")
print("  plotting_matrices/*.csv")
print("  map_level_outcome_summary.csv")
print("  run_configuration.csv")
print("  outcome_codebook.csv")

print("\nAll sensitivity results are saved independently from the figures.")
print("Smooth journal-style region maps are saved with the suffix: _smooth.png / _smooth.pdf")
