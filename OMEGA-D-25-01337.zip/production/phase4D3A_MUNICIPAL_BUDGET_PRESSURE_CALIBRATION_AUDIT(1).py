# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1C
# ANALYTICAL BIFURCATION AUDIT FOR OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE
#
# WHY THIS STEP IS NEEDED
# -----------------------
# The 24-IC maps in Phase 4D-1B revealed broad path-dependent regions.
# Because the audited infrastructure burden depends on the technology's own
# service share, the extension creates positive frequency dependence at low
# penetration:
#
#   Omega_i(x_i) is high when x_i is rare,
#   falls with deployment,
#   and rises mildly again at high penetration.
#
# Under the frozen policy block, Delta_H, Delta_E, Delta_D > 0 in S1-S3,
# therefore y -> 1 for all interior policy starts.
#
# Diesel is also strictly dominated by the non-focal clean competitor at y=1
# in all three scenarios. Hence the long-run extension reduces to an H-E edge
# problem with one state-dependent focal payoff:
#
#   g(x) = M(rho) - F_inf s(x)
#
# where
#
#   s(x) = exp(-4x) + 0.10 x + 0.50 max(0,x-0.70)^2.
#
# This script classifies the exact attractor structure analytically and
# separates:
#
#   1. unique focal-technology attraction,
#   2. pure H-E bistability,
#   3. pure-competitor + stable mixed H/E coexistence,
#   4. unique competitor attraction,
#   5. critical bifurcation boundaries.
#
# No ODE grid is needed. All outputs are saved to CSV.
# =============================================================================

from scipy.optimize import minimize_scalar, brentq
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================

# =============================================================================
# PHASE 4D-2A
# BOUNDED PASSENGER-UTILIZATION SPECIFICATION
# CALIBRATION + ANALYTICAL REGIME AUDIT
#
# PURPOSE
# -------
# Test whether replacing the baseline linear passenger-utilization equation
#
#   q_i = alpha_0 + gamma_1 U_i - gamma_2 U_O
#
# with the bounded outside-option Logit form
#
#   q_i^L = qbar / [1 + exp(-beta (U_i-U_O))]
#
# changes the strategic transition regimes.
#
# IMPORTANT
# ---------
# 1. Passengers still do NOT choose propulsion technologies directly.
#    q_i is utilization of transit service under configuration i relative to
#    the outside option.
#
# 2. The benchmark Logit calibration matches diesel utilization exactly:
#
#       U_D = 0, U_O = 1, q_D = 1.20.
#
#    Choosing qbar = 3 gives
#
#       beta_match = ln(1.5) ≈ 0.405465.
#
# 3. During the beta sensitivity sweep, qbar(beta) is re-anchored so that
#    q_D remains exactly 1.20 boardings/RVK. This isolates the SHAPE /
#    responsiveness of the bounded utilization function instead of changing
#    the overall transit-utilization scale at the same time.
#
# 4. The linear-demand consumer-surplus formula is NOT reused under Logit.
#    It is not required for the replicator dynamics because the PA update uses
#    only the incremental policy payoff Delta_i.
#
# ALL tables and sensitivity results are saved to CSV.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-2B
# 24-INITIAL-CONDITION CERTIFICATION OF BOUNDED PASSENGER UTILIZATION
#
# PURPOSE
# -------
# Numerically certify that the bounded outside-option Logit utilization model
# preserves the strategic transition regimes across:
#
#   beta = 0.15             (low sensitivity)
#   beta = ln(1.5)          (matched benchmark)
#   beta = 1.20             (high sensitivity)
#
# For every beta and scenario, qbar(beta) is chosen so that diesel utilization
# remains exactly q_D = 1.20 boardings/RVK. This isolates the curvature /
# responsiveness of the passenger-utilization specification.
#
# Each case is tested from 24 widely separated initial conditions.
#
# ALL trajectories and summaries are saved to CSV independently of figures.
# =============================================================================

from scipy.integrate import solve_ivp


# =============================================================================

# =============================================================================
# PHASE 4D-3A
# MUNICIPAL BUDGET-PRESSURE EXTENSION
# DIMENSIONAL + THRESHOLD CALIBRATION AUDIT
#
# PURPOSE
# -------
# Rebuild the fiscal-threshold robustness extension on the revised CAD/RVK
# payoff basis before running trajectories.
#
# Gross expected clean-technology subsidy exposure per delivered RVK:
#
#   B(z,w) = z S_H q_H + w S_E q_E
#
# Units: CAD/RVK.
#
# If total annual scheduled service is Q RVK/year, then annual subsidy exposure
# is simply Q * B(z,w), and the annual fiscal threshold is Q * B_bar.
# Therefore the dynamics can be analyzed cleanly in CAD/RVK without choosing
# an arbitrary numerical Q at this stage.
#
# IMPORTANT:
# Diesel environmental charges are NOT subtracted from B(z,w), because this
# extension measures GROSS subsidy-budget exposure. The core model already
# accounts for the fiscal effect of support/charges through lambda_F.
#
# DIMENSIONALLY NORMALIZED SOFT THRESHOLD:
#
#                    max(0, B - B_bar)^2
#   Psi_B = kappa_B -----------------------
#                           B_bar
#
# where:
#   B_bar   : fiscal tolerance threshold, CAD/RVK
#   kappa_B : dimensionless severity parameter
#   Psi_B   : CAD/RVK
#
# Revised PA dynamic:
#
#   y_dot = eta_PA y(1-y) [P(z,w) - Psi_B(z,w)]
#
# where:
#   P(z,w) = z Delta_H + w Delta_E + (1-z-w) Delta_D.
#
# This script DOES NOT yet run the full model. It calculates exact activation
# and policy-persistence thresholds so the final sensitivity domain is chosen
# from the model rather than guessed.
#
# ALL numerical outputs are saved to CSV.
# =============================================================================


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

OUT_DIR = Path("Phase4D3A_municipal_budget_pressure_calibration")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CSV_DIR = OUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION FIGURE STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.4,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. FISCAL FUNCTIONS
# =============================================================================

def gross_subsidy_burden(
    z,
    w,
    p,
    d=None,
):
    """
    Gross clean-technology subsidy exposure, CAD/RVK.
    """
    if d is None:
        d = derived_quantities(p)

    return (
        z * p.S_H * d["q_H"]
        + w * p.S_E * d["q_E"]
    )


def fiscal_penalty(
    z,
    w,
    p,
    B_bar,
    kappa_B,
    d=None,
):
    """
    Dimensionally normalized soft fiscal penalty, CAD/RVK.

    Psi_B = kappa_B * max(0, B-B_bar)^2 / B_bar

    kappa_B is dimensionless.
    """
    if B_bar <= 0.0:
        raise ValueError("B_bar must be strictly positive.")

    B = gross_subsidy_burden(
        z=z,
        w=w,
        p=p,
        d=d,
    )

    excess = max(
        0.0,
        B - B_bar,
    )

    return (
        kappa_B
        * excess**2
        / B_bar
    )


def PA_increment_with_budget(
    z,
    w,
    p,
    B_bar,
    kappa_B,
    d=None,
):
    """
    Revised active-policy incremental payoff, CAD/RVK.
    """
    if d is None:
        d = derived_quantities(p)

    D = 1.0 - z - w

    P_core = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + D * d["Delta_D"]
    )

    Psi = fiscal_penalty(
        z=z,
        w=w,
        p=p,
        B_bar=B_bar,
        kappa_B=kappa_B,
        d=d,
    )

    return (
        P_core - Psi
    )


# =============================================================================
# 15. EXACT PURE-TECHNOLOGY THRESHOLDS
# =============================================================================

def kappa_star_for_policy_persistence(
    Delta_i,
    b_i,
    B_bar,
):
    """
    Exact kappa_B at which the active-policy payoff under pure technology i
    becomes zero:

        Delta_i
        = kappa_B * (b_i-B_bar)^2 / B_bar.

    If B_bar >= b_i, the threshold is infinite because the fiscal penalty is
    inactive at the pure technology corner.
    """
    if B_bar <= 0.0:
        return np.nan

    if B_bar >= b_i:
        return np.inf

    return (
        Delta_i
        * B_bar
        / (b_i - B_bar)**2
    )


def Bbar_star_for_policy_persistence(
    Delta_i,
    b_i,
    kappa_B,
):
    """
    Exact B_bar threshold for fixed kappa_B.

    For B_bar > B_bar*, active policy remains locally attractive at the pure
    technology corner. For B_bar < B_bar*, the fiscal penalty overturns
    Delta_i.

    Solves:
        Delta_i = kappa_B * (b_i-B_bar)^2 / B_bar.
    """
    if kappa_B <= 0.0:
        return 0.0

    disc = (
        Delta_i**2
        + 4.0
        * kappa_B
        * b_i
        * Delta_i
    )

    root_small = (
        (
            2.0
            * kappa_B
            * b_i
            + Delta_i
        )
        - np.sqrt(
            disc
        )
    ) / (
        2.0
        * kappa_B
    )

    return float(
        root_small
    )


# =============================================================================
# 16. AUDIT GRIDS
# =============================================================================

B_BAR_GRID = np.linspace(
    0.05,
    0.75,
    141,
)

KAPPA_GRID = np.linspace(
    0.0,
    2.0,
    161,
)

KAPPA_EXAMPLES = [
    0.10,
    0.25,
    0.50,
    1.00,
    2.00,
]

B_BAR_EXAMPLES = [
    0.10,
    0.20,
    0.30,
    0.40,
    0.50,
    0.60,
]


# =============================================================================
# 17. PURE-ENDPOINT FISCAL EXPOSURE
# =============================================================================

endpoint_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:
    p = make_scenario(
        scenario_name
    )

    d = derived_quantities(
        p
    )

    b_H = (
        p.S_H
        * d["q_H"]
    )

    b_E = (
        p.S_E
        * d["q_E"]
    )

    endpoint_rows.extend([
        {
            "Scenario": scenario_name,
            "Technology": "H",
            "q_i": d["q_H"],
            "Support_CAD_per_boarding": p.S_H,
            "Pure_subsidy_burden_CAD_per_RVK": b_H,
            "Delta_i_CAD_per_RVK": d["Delta_H"],
        },
        {
            "Scenario": scenario_name,
            "Technology": "E",
            "q_i": d["q_E"],
            "Support_CAD_per_boarding": p.S_E,
            "Pure_subsidy_burden_CAD_per_RVK": b_E,
            "Delta_i_CAD_per_RVK": d["Delta_E"],
        },
        {
            "Scenario": scenario_name,
            "Technology": "D",
            "q_i": d["q_D"],
            "Support_CAD_per_boarding": 0.0,
            "Pure_subsidy_burden_CAD_per_RVK": 0.0,
            "Delta_i_CAD_per_RVK": d["Delta_D"],
        },
    ])


endpoint_df = pd.DataFrame(
    endpoint_rows
)

endpoint_df.to_csv(
    CSV_DIR
    / "pure_endpoint_fiscal_exposure.csv",
    index=False,
)


# =============================================================================
# 18. EXACT kappa*(B_bar) CURVES
# =============================================================================

kappa_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = endpoint_df[
        endpoint_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech in [
        "H",
        "E",
    ]:

        row = sub[
            sub[
                "Technology"
            ]
            == tech
        ].iloc[0]

        b_i = float(
            row[
                "Pure_subsidy_burden_CAD_per_RVK"
            ]
        )

        Delta_i = float(
            row[
                "Delta_i_CAD_per_RVK"
            ]
        )

        for B_bar in B_BAR_GRID:

            kstar = (
                kappa_star_for_policy_persistence(
                    Delta_i=Delta_i,
                    b_i=b_i,
                    B_bar=float(B_bar),
                )
            )

            kappa_rows.append({
                "Scenario": scenario_name,
                "Technology": tech,
                "B_bar_CAD_per_RVK": float(B_bar),
                "b_i_CAD_per_RVK": b_i,
                "Delta_i_CAD_per_RVK": Delta_i,
                "kappa_star": kstar,
            })


kappa_df = pd.DataFrame(
    kappa_rows
)

kappa_df.to_csv(
    CSV_DIR
    / "exact_kappa_star_by_Bbar.csv",
    index=False,
)


# =============================================================================
# 19. EXACT B_bar*(kappa) CURVES
# =============================================================================

Bstar_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = endpoint_df[
        endpoint_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech in [
        "H",
        "E",
    ]:

        row = sub[
            sub[
                "Technology"
            ]
            == tech
        ].iloc[0]

        b_i = float(
            row[
                "Pure_subsidy_burden_CAD_per_RVK"
            ]
        )

        Delta_i = float(
            row[
                "Delta_i_CAD_per_RVK"
            ]
        )

        for kappa_B in KAPPA_GRID:

            Bstar = (
                Bbar_star_for_policy_persistence(
                    Delta_i=Delta_i,
                    b_i=b_i,
                    kappa_B=float(kappa_B),
                )
            )

            Bstar_rows.append({
                "Scenario": scenario_name,
                "Technology": tech,
                "kappa_B": float(kappa_B),
                "b_i_CAD_per_RVK": b_i,
                "Delta_i_CAD_per_RVK": Delta_i,
                "B_bar_star_CAD_per_RVK": Bstar,
            })


Bstar_df = pd.DataFrame(
    Bstar_rows
)

Bstar_df.to_csv(
    CSV_DIR
    / "exact_Bbar_star_by_kappa.csv",
    index=False,
)


# =============================================================================
# 20. ACTIVATION-SHARE THRESHOLDS
#
# Along a pure clean-technology path:
#
#   B = x_i b_i.
#
# Fiscal pressure begins when:
#
#   x_i > B_bar / b_i.
# =============================================================================

activation_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = endpoint_df[
        endpoint_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech in [
        "H",
        "E",
    ]:

        row = sub[
            sub[
                "Technology"
            ]
            == tech
        ].iloc[0]

        b_i = float(
            row[
                "Pure_subsidy_burden_CAD_per_RVK"
            ]
        )

        for B_bar in B_BAR_EXAMPLES:

            x_activation = (
                B_bar / b_i
                if b_i > 0.0
                else np.inf
            )

            activation_rows.append({
                "Scenario": scenario_name,
                "Technology": tech,
                "B_bar_CAD_per_RVK": B_bar,
                "Pure_burden_b_i": b_i,
                "Activation_share_x": x_activation,
                "Activates_within_simplex": (
                    x_activation < 1.0
                ),
            })


activation_df = pd.DataFrame(
    activation_rows
)

activation_df.to_csv(
    CSV_DIR
    / "fiscal_penalty_activation_share_thresholds.csv",
    index=False,
)


# =============================================================================
# 21. EXAMPLE POLICY-PERSISTENCE TABLE
# =============================================================================

example_rows = []

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = endpoint_df[
        endpoint_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech in [
        "H",
        "E",
    ]:

        row = sub[
            sub[
                "Technology"
            ]
            == tech
        ].iloc[0]

        b_i = float(
            row[
                "Pure_subsidy_burden_CAD_per_RVK"
            ]
        )

        Delta_i = float(
            row[
                "Delta_i_CAD_per_RVK"
            ]
        )

        for kappa_B in KAPPA_EXAMPLES:

            Bstar = (
                Bbar_star_for_policy_persistence(
                    Delta_i=Delta_i,
                    b_i=b_i,
                    kappa_B=kappa_B,
                )
            )

            example_rows.append({
                "Scenario": scenario_name,
                "Technology": tech,
                "kappa_B": kappa_B,
                "B_bar_star_CAD_per_RVK": Bstar,
                "Interpretation": (
                    "active policy locally attractive if B_bar > B_bar_star"
                ),
            })


example_df = pd.DataFrame(
    example_rows
)

example_df.to_csv(
    CSV_DIR
    / "example_policy_persistence_thresholds.csv",
    index=False,
)


# =============================================================================
# 22. PENALTY PROFILES
# =============================================================================

profile_rows = []

B_values = np.linspace(
    0.0,
    0.75,
    301,
)

for B_bar in [
    0.10,
    0.20,
    0.30,
    0.40,
]:

    for kappa_B in [
        0.25,
        0.50,
        1.00,
    ]:

        for B in B_values:

            excess = max(
                0.0,
                B - B_bar,
            )

            Psi = (
                kappa_B
                * excess**2
                / B_bar
            )

            profile_rows.append({
                "B_CAD_per_RVK": float(B),
                "B_bar_CAD_per_RVK": B_bar,
                "kappa_B": kappa_B,
                "Psi_B_CAD_per_RVK": Psi,
            })


profile_df = pd.DataFrame(
    profile_rows
)

profile_df.to_csv(
    CSV_DIR
    / "fiscal_penalty_profiles.csv",
    index=False,
)


# =============================================================================
# 23. FIGURE — POLICY-PERSISTENCE FRONTIERS
# =============================================================================

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    fig, ax = plt.subplots(
        figsize=(6.6, 4.9)
    )

    sub_s = kappa_df[
        kappa_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech, linestyle in [
        ("H", "-"),
        ("E", "--"),
    ]:

        sub = sub_s[
            sub_s[
                "Technology"
            ]
            == tech
        ].copy()

        finite = np.isfinite(
            sub[
                "kappa_star"
            ]
        )

        ax.plot(
            sub.loc[
                finite,
                "B_bar_CAD_per_RVK",
            ],
            sub.loc[
                finite,
                "kappa_star",
            ],
            linestyle=linestyle,
            linewidth=1.6,
            label=(
                f"{tech}: "
                r"$\kappa_B^*(\bar B)$"
            ),
        )

    ax.set_xlabel(
        r"Fiscal tolerance threshold, $\bar B$ (CAD/RVK)"
    )

    ax.set_ylabel(
        r"Critical fiscal-severity parameter, $\kappa_B^*$"
    )

    ax.set_title(
        scenario_name
        + " — active-policy persistence threshold",
        fontweight="semibold",
    )

    ax.set_ylim(
        0.0,
        2.0,
    )

    ax.grid(
        False
    )

    ax.legend(
        frameon=False
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR
        / f"{scenario_name}_policy_persistence_thresholds.png",
        dpi=600,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / f"{scenario_name}_policy_persistence_thresholds.pdf",
        bbox_inches="tight",
    )

    plt.show()
    plt.close(
        fig
    )


# =============================================================================
# 24. PRINT AUDIT
# =============================================================================

print("=" * 112)
print("PHASE 4D-3A — MUNICIPAL BUDGET-PRESSURE CALIBRATION AUDIT")
print("=" * 112)

print("\nA. PURE-TECHNOLOGY GROSS SUBSIDY EXPOSURE")
print("-" * 112)

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    sub = endpoint_df[
        endpoint_df[
            "Scenario"
        ]
        == scenario_name
    ]

    print(
        f"\n{scenario_name}"
    )

    for tech in [
        "H",
        "E",
        "D",
    ]:

        row = sub[
            sub[
                "Technology"
            ]
            == tech
        ].iloc[0]

        print(
            f"  {tech}: "
            f"B_i={row['Pure_subsidy_burden_CAD_per_RVK']:.6f} CAD/RVK, "
            f"Delta_i={row['Delta_i_CAD_per_RVK']:.6f} CAD/RVK"
        )


print("\nB. EXACT B_bar* FOR SELECTED kappa_B VALUES")
print("-" * 112)

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    print(
        f"\n{scenario_name}"
    )

    sub_s = example_df[
        example_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech in [
        "H",
        "E",
    ]:

        print(
            f"  {tech}:"
        )

        sub_t = sub_s[
            sub_s[
                "Technology"
            ]
            == tech
        ]

        for _, row in sub_t.iterrows():

            print(
                f"    kappa_B={row['kappa_B']:.2f}: "
                f"B_bar*={row['B_bar_star_CAD_per_RVK']:.6f} CAD/RVK"
            )


print("\nC. PENALTY-ACTIVATION SHARES FOR SELECTED B_bar")
print("-" * 112)

for scenario_name in [
    "S1",
    "S2",
    "S3",
]:

    print(
        f"\n{scenario_name}"
    )

    sub_s = activation_df[
        activation_df[
            "Scenario"
        ]
        == scenario_name
    ]

    for tech in [
        "H",
        "E",
    ]:

        print(
            f"  {tech}:"
        )

        sub_t = sub_s[
            sub_s[
                "Technology"
            ]
            == tech
        ]

        for _, row in sub_t.iterrows():

            x = row[
                "Activation_share_x"
            ]

            if x < 1.0:
                message = (
                    f"activates when share > {x:.4f}"
                )
            else:
                message = (
                    "does not activate before full penetration"
                )

            print(
                f"    B_bar={row['B_bar_CAD_per_RVK']:.2f}: "
                f"{message}"
            )


print("\nD. DIMENSIONAL INTERPRETATION")
print("-" * 112)

print(
    "  B(z,w) is gross clean-technology subsidy expenditure per delivered RVK."
)
print(
    "  Q*B(z,w) is the corresponding annual expenditure if Q annual RVK are supplied."
)
print(
    "  B_bar is therefore a scale-normalized fiscal threshold in CAD/RVK; "
    "Q*B_bar is its annual-budget equivalent."
)
print(
    "  kappa_B is dimensionless under Psi_B = kappa_B*max(0,B-B_bar)^2/B_bar."
)
print(
    "  The fiscal-threshold penalty is additional to the core linear fiscal term "
    "lambda_F*Fcal and represents nonlinear excess-budget pressure only."
)


print("\nFiles saved under:")
print(
    f"  {OUT_DIR.resolve()}"
)

print("\nCSV RESULTS")
print("  pure_endpoint_fiscal_exposure.csv")
print("  exact_kappa_star_by_Bbar.csv")
print("  exact_Bbar_star_by_kappa.csv")
print("  fiscal_penalty_activation_share_thresholds.csv")
print("  example_policy_persistence_thresholds.csv")
print("  fiscal_penalty_profiles.csv")

print("\nPhase 4D-3A completed.")
