# =============================================================================
# PHASE 4C — FULL STANDALONE MULTI-INITIAL-CONDITION PRODUCTION MODEL
#
# IMPORTANT:
#   This is a SINGLE standalone file.
#   It does NOT import transit_model_phase4B.py.
#   Therefore, it avoids the circular-import error.
#
# It creates:
#   1) Fig_S1_multistart_dynamics.png / .pdf
#   2) Fig_S2_multistart_dynamics.png / .pdf
#   3) Fig_S3_multistart_dynamics.png / .pdf
#   4) Fig_S3_policy_payoff_reversal.png / .pdf
#   5) Phase4C_multistart_summary.csv
#
# State order everywhere:
#   x = [z, w, y]
#
#   z       = hydrogen share of annual scheduled RVK
#   w       = electric share of annual scheduled RVK
#   1-z-w   = diesel share of annual scheduled RVK
#   y       = public-authority active-policy weight
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =============================================================================
# 0. OUTPUT FOLDER
# =============================================================================

OUTPUT_DIR = Path("Phase4C_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# CSV export folders
#
# I will use this structure in future model/result codes as well so that
# numerical results are preserved independently from the plotting code.
# -------------------------------------------------------------------------

CSV_DIR = OUTPUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

TRAJECTORY_CSV_DIR = CSV_DIR / "trajectories_individual"
TRAJECTORY_CSV_DIR.mkdir(parents=True, exist_ok=True)

SCENARIO_CSV_DIR = CSV_DIR / "trajectories_by_scenario"
SCENARIO_CSV_DIR.mkdir(parents=True, exist_ok=True)

DIAGNOSTIC_CSV_DIR = CSV_DIR / "diagnostics"
DIAGNOSTIC_CSV_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 1. PARAMETERS
# =============================================================================

@dataclass(frozen=True)
class Parameters:

    # -------------------------------------------------------------------------
    # Passenger/service block
    # -------------------------------------------------------------------------

    F_H: float = 3.0
    F_E: float = 3.0
    F_D: float = 3.0

    A_H: float = 25.0
    A_E: float = 25.0
    A_D: float = 25.0

    l: float = 10.0
    fare_t: float = 3.0

    beta_t: float = 0.50
    lambda_time: float = 1.0

    U_O: float = 1.0

    # Chosen so baseline diesel utility is zero
    U_0: float = 2.0666666666666664

    alpha_0: float = 1.30
    gamma_1: float = 0.30
    gamma_2: float = 0.10

    delta: float = 0.10

    theta: float = 0.20
    phi: float = 0.20

    # CAD/RVK
    mu: float = 1.0

    # -------------------------------------------------------------------------
    # Fleet / annualization block
    # -------------------------------------------------------------------------

    K_D: float = 60_000.0

    rho_H: float = 1.0
    rho_E: float = 1.0
    rho_D: float = 1.0

    R_H: float = 1_200_000.0
    R_E: float = 750_000.0
    R_D: float = 510_000.0

    L_H: int = 16
    L_E: int = 16
    L_D: int = 16

    discount_r: float = 0.05

    # -------------------------------------------------------------------------
    # Non-energy operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_hat_H: float = 1.6041666667
    C_hat_E: float = 0.7404427083
    C_hat_D: float = 1.1953854167

    # -------------------------------------------------------------------------
    # Energy consumption per delivered RVK
    # -------------------------------------------------------------------------

    omega_H: float = 0.088767      # kg H2/RVK
    omega_E: float = 1.34          # kWh/RVK
    omega_D: float = 0.560035      # L/RVK

    # Energy prices
    fuel_H: float = 9.00           # CAD/kg H2
    fuel_E: float = 0.15           # CAD/kWh
    fuel_D: float = 1.80           # CAD/L

    # -------------------------------------------------------------------------
    # Halifax route-based lifecycle emissions
    # kg CO2e/passenger-km
    # -------------------------------------------------------------------------

    nu_H: float = 0.015046166666666668
    nu_E: float = 0.04944816666666666
    nu_D: float = 0.218488

    # CAD/kg CO2e
    p_CO2: float = 0.328213

    # Normalized net-zero benchmark, kg CO2e/RVK
    e_target: float = 0.0

    # -------------------------------------------------------------------------
    # Environmental-policy instruments, CAD/boarding
    # -------------------------------------------------------------------------

    S_H: float = 0.50
    S_E: float = 0.30
    T_D: float = 0.50

    # Fiscal weight in PA incremental payoff
    lambda_F: float = 0.05

    # -------------------------------------------------------------------------
    # Evolutionary adjustment coefficients
    # -------------------------------------------------------------------------

    eta_TO: float = 1.0
    eta_PA: float = 1.0


# =============================================================================
# 2. SCENARIOS
# =============================================================================

def make_scenario(name: str) -> Parameters:

    base = Parameters()

    name = name.upper().strip()

    if name == "S1":
        return base

    if name == "S2":
        return replace(
            base,
            theta=0.30,
            phi=0.30,
            R_H=900_000.0,
            R_E=675_000.0,
            C_hat_H=1.20,
            fuel_H=7.00,
            fuel_E=0.13,
            fuel_D=1.90,
        )

    if name == "S3":
        return replace(
            base,
            theta=0.40,
            phi=0.40,
            R_H=600_000.0,
            R_E=600_000.0,
            C_hat_H=0.80,
            fuel_H=3.00,
            fuel_E=0.11,
            fuel_D=2.00,
        )

    raise ValueError("Scenario must be 'S1', 'S2', or 'S3'.")


# =============================================================================
# 3. MODEL BUILDING BLOCKS
# =============================================================================

def capital_recovery_factor(r: float, L: int) -> float:
    return r * (1.0 + r) ** L / ((1.0 + r) ** L - 1.0)


def derived_quantities(p: Parameters) -> Dict[str, float]:

    # -------------------------------------------------------------------------
    # Passenger utilities
    # -------------------------------------------------------------------------

    U_H = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_H) + p.l / p.A_H)
        + (1.0 + p.delta) * p.theta
    )

    U_E = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_E) + p.l / p.A_E)
        + (1.0 + p.delta) * p.phi
    )

    U_D = (
        p.U_0
        - p.beta_t * p.fare_t
        - p.lambda_time * (1.0 / (2.0 * p.F_D) + p.l / p.A_D)
    )

    # -------------------------------------------------------------------------
    # Passenger utilization, boardings/RVK
    # -------------------------------------------------------------------------

    q_H = p.alpha_0 + p.gamma_1 * U_H - p.gamma_2 * p.U_O
    q_E = p.alpha_0 + p.gamma_1 * U_E - p.gamma_2 * p.U_O
    q_D = p.alpha_0 + p.gamma_1 * U_D - p.gamma_2 * p.U_O

    if min(q_H, q_E, q_D) < 0.0:
        raise ValueError("Negative utilization generated by linear specification.")

    # -------------------------------------------------------------------------
    # Operating costs, CAD/RVK
    # -------------------------------------------------------------------------

    C_H = p.C_hat_H + p.omega_H * p.fuel_H
    C_E = p.C_hat_E + p.omega_E * p.fuel_E
    C_D = p.C_hat_D + p.omega_D * p.fuel_D

    # -------------------------------------------------------------------------
    # Annualized vehicle acquisition costs, CAD/RVK
    # -------------------------------------------------------------------------

    cap_H = (
        p.rho_H
        * p.R_H
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_H)
    )

    cap_E = (
        p.rho_E
        * p.R_E
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_E)
    )

    cap_D = (
        p.rho_D
        * p.R_D
        / p.K_D
        * capital_recovery_factor(p.discount_r, p.L_D)
    )

    # -------------------------------------------------------------------------
    # Baseline-regime operator payoffs, CAD/RVK
    # -------------------------------------------------------------------------

    pi_H_B = (
        p.fare_t * q_H
        - C_H
        - cap_H
        - p.mu * p.theta**2 / 2.0
    )

    pi_E_B = (
        p.fare_t * q_E
        - C_E
        - cap_E
        - p.mu * p.phi**2 / 2.0
    )

    pi_D_B = (
        p.fare_t * q_D
        - C_D
        - cap_D
    )

    # -------------------------------------------------------------------------
    # Full-active-policy operator payoffs
    # -------------------------------------------------------------------------

    pi_H_A = pi_H_B + p.S_H * q_H
    pi_E_A = pi_E_B + p.S_E * q_E
    pi_D_A = pi_D_B - p.T_D * q_D

    # -------------------------------------------------------------------------
    # Emissions, kg CO2e/RVK
    # -------------------------------------------------------------------------

    e_H = p.l * q_H * p.nu_H
    e_E = p.l * q_E * p.nu_E
    e_D = p.l * q_D * p.nu_D

    # -------------------------------------------------------------------------
    # Consumer surplus, CAD/RVK
    # -------------------------------------------------------------------------

    CS_H = q_H**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_E = q_E**2 / (2.0 * p.gamma_1 * p.beta_t)
    CS_D = q_D**2 / (2.0 * p.gamma_1 * p.beta_t)

    # -------------------------------------------------------------------------
    # Baseline PA welfare values
    # -------------------------------------------------------------------------

    V_H = CS_H + pi_H_B - p.p_CO2 * e_H
    V_E = CS_E + pi_E_B - p.p_CO2 * e_E
    V_D = CS_D + pi_D_B - p.p_CO2 * e_D

    # -------------------------------------------------------------------------
    # PA incremental payoff of active policy relative to baseline
    # -------------------------------------------------------------------------

    Delta_H = (
        p.p_CO2 * (e_H - p.e_target)
        - p.lambda_F * p.S_H * q_H
    )

    Delta_E = (
        p.p_CO2 * (e_E - p.e_target)
        - p.lambda_F * p.S_E * q_E
    )

    Delta_D = (
        p.p_CO2 * (e_D - p.e_target)
        + p.lambda_F * p.T_D * q_D
    )

    # -------------------------------------------------------------------------
    # Gamma coefficients
    # -------------------------------------------------------------------------

    Gamma_H0 = pi_H_B - pi_D_B
    Gamma_H1 = p.S_H * q_H + p.T_D * q_D

    Gamma_E0 = pi_E_B - pi_D_B
    Gamma_E1 = p.S_E * q_E + p.T_D * q_D

    return {
        "U_H": U_H,
        "U_E": U_E,
        "U_D": U_D,

        "q_H": q_H,
        "q_E": q_E,
        "q_D": q_D,

        "C_H": C_H,
        "C_E": C_E,
        "C_D": C_D,

        "cap_H": cap_H,
        "cap_E": cap_E,
        "cap_D": cap_D,

        "pi_H_B": pi_H_B,
        "pi_E_B": pi_E_B,
        "pi_D_B": pi_D_B,

        "pi_H_A": pi_H_A,
        "pi_E_A": pi_E_A,
        "pi_D_A": pi_D_A,

        "e_H": e_H,
        "e_E": e_E,
        "e_D": e_D,

        "CS_H": CS_H,
        "CS_E": CS_E,
        "CS_D": CS_D,

        "V_H": V_H,
        "V_E": V_E,
        "V_D": V_D,

        "Delta_H": Delta_H,
        "Delta_E": Delta_E,
        "Delta_D": Delta_D,

        "Gamma_H0": Gamma_H0,
        "Gamma_H1": Gamma_H1,
        "Gamma_E0": Gamma_E0,
        "Gamma_E1": Gamma_E1,
    }


# =============================================================================
# 4. EXPECTED OPERATOR PAYOFFS
# =============================================================================

def expected_operator_payoffs(y: float, p: Parameters) -> Dict[str, float]:

    d = derived_quantities(p)

    Pi_H = d["pi_H_B"] + y * p.S_H * d["q_H"]
    Pi_E = d["pi_E_B"] + y * p.S_E * d["q_E"]
    Pi_D = d["pi_D_B"] - y * p.T_D * d["q_D"]

    return {
        "Pi_H": Pi_H,
        "Pi_E": Pi_E,
        "Pi_D": Pi_D,
    }


# =============================================================================
# 5. REPLICATOR DYNAMICS
# =============================================================================

def replicator_rhs(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    # State order = [z, w, y]
    z, w, y = map(float, state)

    diesel_share = 1.0 - z - w

    op = expected_operator_payoffs(y=y, p=p)

    Pi_H = op["Pi_H"]
    Pi_E = op["Pi_E"]
    Pi_D = op["Pi_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + diesel_share * Pi_D
    )

    d = derived_quantities(p)

    policy_advantage = (
        z * d["Delta_H"]
        + w * d["Delta_E"]
        + diesel_share * d["Delta_D"]
    )

    dz = p.eta_TO * z * (Pi_H - Pi_bar)
    dw = p.eta_TO * w * (Pi_E - Pi_bar)
    dy = p.eta_PA * y * (1.0 - y) * policy_advantage

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 6. GAMMA/DELTA FORM — CERTIFICATION ONLY
# =============================================================================

def replicator_rhs_gamma(
    tau: float,
    state: np.ndarray,
    p: Parameters,
) -> np.ndarray:

    z, w, y = map(float, state)

    d = derived_quantities(p)

    Gamma_H = d["Gamma_H0"] + y * d["Gamma_H1"]
    Gamma_E = d["Gamma_E0"] + y * d["Gamma_E1"]

    P = (
        d["Delta_D"]
        + z * (d["Delta_H"] - d["Delta_D"])
        + w * (d["Delta_E"] - d["Delta_D"])
    )

    dz = (
        p.eta_TO
        * z
        * ((1.0 - z) * Gamma_H - w * Gamma_E)
    )

    dw = (
        p.eta_TO
        * w
        * ((1.0 - w) * Gamma_E - z * Gamma_H)
    )

    dy = (
        p.eta_PA
        * y
        * (1.0 - y)
        * P
    )

    return np.array([dz, dw, dy], dtype=float)


# =============================================================================
# 7. INITIAL-STATE VALIDATION
# =============================================================================

def validate_initial_state(state: Iterable[float]) -> np.ndarray:

    z, w, y = map(float, state)

    if not (
        0.0 <= z <= 1.0
        and 0.0 <= w <= 1.0
        and 0.0 <= y <= 1.0
    ):
        raise ValueError("z, w, and y must all lie in [0,1].")

    if z + w > 1.0:
        raise ValueError("Initial condition violates z + w <= 1.")

    return np.array([z, w, y], dtype=float)


# =============================================================================
# 8. SOLVER
# =============================================================================

def solve_replicator(
    p: Parameters,
    initial_state: Iterable[float],
    tau_span: Tuple[float, float] = (0.0, 200.0),
    n_points: int = 4001,
):

    x0 = validate_initial_state(initial_state)

    tau_eval = np.linspace(
        tau_span[0],
        tau_span[1],
        n_points,
    )

    sol = solve_ivp(
        fun=lambda tau, x: replicator_rhs(tau, x, p),
        t_span=tau_span,
        y0=x0,
        t_eval=tau_eval,
        method="DOP853",
        rtol=1e-10,
        atol=1e-12,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    return sol


# =============================================================================
# 9. POLICY THRESHOLDS
# =============================================================================

def policy_thresholds(p: Parameters) -> Dict[str, float]:
    """
    Pairwise operator-indifference thresholds in policy space.

    A threshold is returned as np.nan when its denominator is numerically zero.
    This is essential for sensitivity grids such as S_H x S_E, where equal
    support slopes can make the H-E threshold undefined rather than finite.
    """

    d = derived_quantities(p)

    denominator_HE = (
        p.S_H * d["q_H"]
        - p.S_E * d["q_E"]
    )

    denominator_HD = (
        p.S_H * d["q_H"]
        + p.T_D * d["q_D"]
    )

    denominator_ED = (
        p.S_E * d["q_E"]
        + p.T_D * d["q_D"]
    )

    def safe_ratio(numerator: float, denominator: float) -> float:
        if abs(denominator) <= 1e-12:
            return np.nan
        return float(numerator / denominator)

    y_HE = safe_ratio(
        d["pi_E_B"] - d["pi_H_B"],
        denominator_HE,
    )

    y_HD = safe_ratio(
        d["pi_D_B"] - d["pi_H_B"],
        denominator_HD,
    )

    y_ED = safe_ratio(
        d["pi_D_B"] - d["pi_E_B"],
        denominator_ED,
    )

    return {
        "y_HE": y_HE,
        "y_HD": y_HD,
        "y_ED": y_ED,
    }


# =============================================================================
# 10. PURE-EQUILIBRIUM STABILITY REPORT
# =============================================================================

def pure_stability_report(p: Parameters) -> Dict[str, bool]:

    d = derived_quantities(p)

    GH0 = d["Gamma_H0"]
    GE0 = d["Gamma_E0"]

    GH1 = d["Gamma_H1"]
    GE1 = d["Gamma_E1"]

    DH = d["Delta_H"]
    DE = d["Delta_E"]
    DD = d["Delta_D"]

    GH_active = GH0 + GH1
    GE_active = GE0 + GE1

    return {
        "E1 = D_B": (
            GH0 < 0
            and GE0 < 0
            and DD < 0
        ),

        "E2 = H_B": (
            GH0 > 0
            and GH0 > GE0
            and DH < 0
        ),

        "E3 = E_B": (
            GE0 > 0
            and GE0 > GH0
            and DE < 0
        ),

        "E4 = D_A": (
            GH_active < 0
            and GE_active < 0
            and DD > 0
        ),

        "E5 = H_A": (
            GH_active > 0
            and GH_active > GE_active
            and DH > 0
        ),

        "E6 = E_A": (
            GE_active > 0
            and GE_active > GH_active
            and DE > 0
        ),
    }


# =============================================================================
# 11. CERTIFICATION
# =============================================================================

def certify_rhs_equivalence(p: Parameters) -> float:

    test_state = np.array([0.20, 0.40, 0.50], dtype=float)

    direct = replicator_rhs(
        0.0,
        test_state,
        p,
    )

    gamma = replicator_rhs_gamma(
        0.0,
        test_state,
        p,
    )

    return float(
        np.max(
            np.abs(direct - gamma)
        )
    )



# =============================================================================
# PHASE 4C-4
# 24-INITIAL-CONDITION MULTI-START REGION / SENSITIVITY ANALYSIS
#
# This script uses a structured 24-point initial-condition design:
#     8 widely separated technology compositions
#     x 3 policy starting levels (0.10, 0.50, 0.90)
#
# At EVERY grid point, all 24 initial conditions are integrated together in
# one batched solve_ivp call. This makes the robustness analysis much faster
# than solving each initial condition separately.
#
# Three maps are generated for EACH scenario:
#
#   A) Capital-cost competition:
#        R_H x R_E
#
#   B) Hydrogen operating-learning frontier:
#        fuel_H x C_hat_H
#
#   C) Policy-support frontier:
#        S_H x S_E
#
# The script saves:
#   - every IC-level final state at every grid point,
#   - consensus classification for every grid point,
#   - plotting matrices,
#   - benchmark 24-IC results,
#   - initial-condition definitions,
#   - map configuration / codebook,
#   - PNG and PDF maps.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4C-5
# ANALYTICAL REGION CLASSIFICATION + H-E CYCLING CERTIFICATION
#
# PURPOSE
# -------
# 1. Replace finite-horizon grid classifications with exact analytical
#    stability/candidate classification wherever possible.
# 2. Remove artificial "path-dependent" strips caused only by slow convergence
#    near payoff boundaries.
# 3. Identify genuine persistent H-E policy cycling using:
#       - feasibility of E9,
#       - K_HE < 0,
#       - negative transverse eigenvalue,
#       - long-run numerical phase portraits,
#       - the exact first integral on the H-E edge.
# 4. Save ALL analytical map data and cycle trajectories to CSV independently
#    from figure generation.
#
# IMPORTANT
# ---------
# This script does NOT alter the model or benchmark calibration.
# =============================================================================

from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# =============================================================================

# =============================================================================
# PHASE 4D-1A
# OPERATIONAL NON-EQUIVALENCE + NONLINEAR INFRASTRUCTURE
# DIMENSIONAL / CALIBRATION AUDIT
#
# PURPOSE
# -------
# Before running a large 24-initial-condition robustness grid, this script:
#
#   1. verifies the correct dimensional placement of rho_i;
#   2. quantifies how much service non-equivalence alone can be tolerated;
#   3. compares infrastructure-burden shapes on the same CAD/RVK payoff basis;
#   4. identifies sensible F_inf ranges for the later sensitivity maps;
#   5. uses a parsimonious nested parameterization in which
#
#          eta_i  = a_eta  * F_inf
#          zeta_i = a_zeta * F_inf
#
#      so F_inf = 0 EXACTLY recovers the frozen baseline model while still
#      preserving the full nonlinear Omega_i(x_i) structure:
#
#      Omega_i(x)
#        = F_inf exp(-lambda_i x)
#        + eta_i x
#        + zeta_i max(0, x-xbar_i)^2.
#
# IMPORTANT
# ---------
# This is a calibration / dimensional audit only.
# No benchmark model parameter is changed here.
# No large ODE sensitivity experiment is run here.
#
# ALL numerical tables are exported to CSV independently of the figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1B
# 24-INITIAL-CONDITION OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE FRONTIER
#
# FINAL EXTENSION DESIGN
# ----------------------
# S1 and S2:
#   focal zero-emission technology = Electric
#   map = rho_E x F_E_inf
#
# S3:
#   focal zero-emission technology = Hydrogen
#   map = rho_H x F_H_inf
#
# The nonlinear infrastructure burden is:
#
#   Omega_i(x_i)
#     = F_i_inf exp(-lambda_i x_i)
#     + eta_i x_i
#     + zeta_i max(0, x_i-xbar_i)^2
#
# with the audited "Moderate nonlinear" nested shape:
#
#   lambda_i = 4
#   eta_i     = 0.10 F_i_inf
#   zeta_i    = 0.50 F_i_inf
#   xbar_i    = 0.70
#
# Therefore F_i_inf = 0 exactly recovers the frozen core model.
#
# At EVERY grid point, 24 widely separated initial conditions are tested.
#
# ALL numerical results are exported to CSV independently from figures.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-1C
# ANALYTICAL BIFURCATION AUDIT FOR OPERATIONAL NON-EQUIVALENCE +
# NONLINEAR INFRASTRUCTURE
#
# WHY THIS STEP IS NEEDED
# -----------------------
# The 24-IC maps in Phase 4D-1B revealed broad path-dependent regions.
# Because the audited infrastructure burden depends on the technology's own
# service share, the extension creates positive frequency dependence at low
# penetration:
#
#   Omega_i(x_i) is high when x_i is rare,
#   falls with deployment,
#   and rises mildly again at high penetration.
#
# Under the frozen policy block, Delta_H, Delta_E, Delta_D > 0 in S1-S3,
# therefore y -> 1 for all interior policy starts.
#
# Diesel is also strictly dominated by the non-focal clean competitor at y=1
# in all three scenarios. Hence the long-run extension reduces to an H-E edge
# problem with one state-dependent focal payoff:
#
#   g(x) = M(rho) - F_inf s(x)
#
# where
#
#   s(x) = exp(-4x) + 0.10 x + 0.50 max(0,x-0.70)^2.
#
# This script classifies the exact attractor structure analytically and
# separates:
#
#   1. unique focal-technology attraction,
#   2. pure H-E bistability,
#   3. pure-competitor + stable mixed H/E coexistence,
#   4. unique competitor attraction,
#   5. critical bifurcation boundaries.
#
# No ODE grid is needed. All outputs are saved to CSV.
# =============================================================================

from scipy.optimize import minimize_scalar, brentq
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================

# =============================================================================
# PHASE 4D-2A
# BOUNDED PASSENGER-UTILIZATION SPECIFICATION
# CALIBRATION + ANALYTICAL REGIME AUDIT
#
# PURPOSE
# -------
# Test whether replacing the baseline linear passenger-utilization equation
#
#   q_i = alpha_0 + gamma_1 U_i - gamma_2 U_O
#
# with the bounded outside-option Logit form
#
#   q_i^L = qbar / [1 + exp(-beta (U_i-U_O))]
#
# changes the strategic transition regimes.
#
# IMPORTANT
# ---------
# 1. Passengers still do NOT choose propulsion technologies directly.
#    q_i is utilization of transit service under configuration i relative to
#    the outside option.
#
# 2. The benchmark Logit calibration matches diesel utilization exactly:
#
#       U_D = 0, U_O = 1, q_D = 1.20.
#
#    Choosing qbar = 3 gives
#
#       beta_match = ln(1.5) ≈ 0.405465.
#
# 3. During the beta sensitivity sweep, qbar(beta) is re-anchored so that
#    q_D remains exactly 1.20 boardings/RVK. This isolates the SHAPE /
#    responsiveness of the bounded utilization function instead of changing
#    the overall transit-utilization scale at the same time.
#
# 4. The linear-demand consumer-surplus formula is NOT reused under Logit.
#    It is not required for the replicator dynamics because the PA update uses
#    only the incremental policy payoff Delta_i.
#
# ALL tables and sensitivity results are saved to CSV.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-2B
# 24-INITIAL-CONDITION CERTIFICATION OF BOUNDED PASSENGER UTILIZATION
#
# PURPOSE
# -------
# Numerically certify that the bounded outside-option Logit utilization model
# preserves the strategic transition regimes across:
#
#   beta = 0.15             (low sensitivity)
#   beta = ln(1.5)          (matched benchmark)
#   beta = 1.20             (high sensitivity)
#
# For every beta and scenario, qbar(beta) is chosen so that diesel utilization
# remains exactly q_D = 1.20 boardings/RVK. This isolates the curvature /
# responsiveness of the passenger-utilization specification.
#
# Each case is tested from 24 widely separated initial conditions.
#
# ALL trajectories and summaries are saved to CSV independently of figures.
# =============================================================================

from scipy.integrate import solve_ivp


# =============================================================================

# =============================================================================
# PHASE 4D-3A
# MUNICIPAL BUDGET-PRESSURE EXTENSION
# DIMENSIONAL + THRESHOLD CALIBRATION AUDIT
#
# PURPOSE
# -------
# Rebuild the fiscal-threshold robustness extension on the revised CAD/RVK
# payoff basis before running trajectories.
#
# Gross expected clean-technology subsidy exposure per delivered RVK:
#
#   B(z,w) = z S_H q_H + w S_E q_E
#
# Units: CAD/RVK.
#
# If total annual scheduled service is Q RVK/year, then annual subsidy exposure
# is simply Q * B(z,w), and the annual fiscal threshold is Q * B_bar.
# Therefore the dynamics can be analyzed cleanly in CAD/RVK without choosing
# an arbitrary numerical Q at this stage.
#
# IMPORTANT:
# Diesel environmental charges are NOT subtracted from B(z,w), because this
# extension measures GROSS subsidy-budget exposure. The core model already
# accounts for the fiscal effect of support/charges through lambda_F.
#
# DIMENSIONALLY NORMALIZED SOFT THRESHOLD:
#
#                    max(0, B - B_bar)^2
#   Psi_B = kappa_B -----------------------
#                           B_bar
#
# where:
#   B_bar   : fiscal tolerance threshold, CAD/RVK
#   kappa_B : dimensionless severity parameter
#   Psi_B   : CAD/RVK
#
# Revised PA dynamic:
#
#   y_dot = eta_PA y(1-y) [P(z,w) - Psi_B(z,w)]
#
# where:
#   P(z,w) = z Delta_H + w Delta_E + (1-z-w) Delta_D.
#
# This script DOES NOT yet run the full model. It calculates exact activation
# and policy-persistence thresholds so the final sensitivity domain is chosen
# from the model rather than guessed.
#
# ALL numerical outputs are saved to CSV.
# =============================================================================


# =============================================================================

# =============================================================================
# PHASE 4D-3B
# 24-INITIAL-CONDITION MUNICIPAL BUDGET-PRESSURE REGIME MAP
#
# PURPOSE
# -------
# Map how the nonlinear municipal fiscal threshold changes:
#
#   - policy persistence,
#   - technology selection,
#   - and the possibility of persistent/nonstationary transition dynamics.
#
# Fiscal burden:
#
#   B(z,w) = z S_H q_H + w S_E q_E
#
# Soft fiscal penalty:
#
#                      max(0, B-Bbar)^2
#   Psi_B = kappa_B * -------------------
#                            Bbar
#
# Revised PA update:
#
#   y_dot = eta_PA y(1-y) [P(z,w) - Psi_B(z,w)]
#
# The operator payoffs are unchanged directly; budget pressure acts through
# the endogenous policy weight y.
#
# COMMON sensitivity domain for all three scenarios:
#
#   Bbar    in [0.05, 0.70] CAD/RVK
#   kappa_B in [0.00, 2.00]
#
# At every grid point, the model is tested from the same 24 widely separated
# initial conditions used in the other final robustness analyses.
#
# ALL grid-level and IC-level results are saved to CSV independently of plots.
# =============================================================================

from scipy.integrate import solve_ivp
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================

# =============================================================================
# PHASE 4D-3C
# ANALYTICAL MUNICIPAL-BUDGET REGIME CLASSIFICATION +
# H-E POLICY-CYCLE CERTIFICATION
#
# PURPOSE
# -------
# Explain and certify the large "Persistent/nonstationary" region found in
# Phase 4D-3B.
#
# Under the revised core calibration:
#
#   S1 and S2:
#       Electric dominates hydrogen for every feasible y in [0,1].
#       Budget pressure therefore changes policy persistence (E_A vs E_B)
#       but not the selected technology.
#
#   S3:
#       Electric is favored at low y, hydrogen at high y, with
#
#           y_HE* in (0,1).
#
#       On the attracting H-E edge (D=0),
#
#           z_dot = eta_TO z(1-z) G(y)
#           y_dot = eta_PA y(1-y) H(z)
#
#       where
#
#           G(y) = Pi_H(y)-Pi_E(y)
#
#       and
#
#           H(z) = Delta_E + z(Delta_H-Delta_E) - Psi_B(z).
#
#       Because H(z) is strictly decreasing, three exact regimes exist:
#
#       1. H(1) > 0:
#              H_A is the unique attracting H-E corner.
#
#       2. H(0) < 0:
#              E_B is the unique attracting H-E corner.
#
#       3. H(0) > 0 > H(1):
#              one interior H-E-policy rest point exists.
#              Its two edge eigenvalues are purely imaginary.
#              The reduced two-dimensional system has an exact first integral,
#              so surrounding trajectories are persistent closed orbits rather
#              than asymptotically convergent mixed equilibria.
#
# This script:
#   - builds exact analytical maps on a dense 401x401 grid;
#   - compares them with the Phase 4D-3B 31x31 simulation map if available;
#   - certifies the S3 intermediate fiscal regime with 24 edge starts;
#   - verifies transverse attraction from the full simplex;
#   - saves all numerical results and trajectories to CSV.
# =============================================================================

from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.special import expit
from scipy.signal import find_peaks
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


# =============================================================================
# 12. OUTPUT DIRECTORIES
# =============================================================================

OUT_DIR = Path("Phase4D3C_analytical_budget_cycle_certification")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CSV_DIR = OUT_DIR / "csv_results"
CSV_DIR.mkdir(parents=True, exist_ok=True)

MAP_DIR = CSV_DIR / "analytical_maps"
MAP_DIR.mkdir(parents=True, exist_ok=True)

CYCLE_DIR = CSV_DIR / "cycle_certification"
CYCLE_DIR.mkdir(parents=True, exist_ok=True)

TRAJ_DIR = CYCLE_DIR / "individual_trajectories"
TRAJ_DIR.mkdir(parents=True, exist_ok=True)

FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 13. PUBLICATION STYLE
# =============================================================================

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10.0,
    "axes.labelsize": 10.5,
    "axes.titlesize": 11.0,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.3,
    "axes.linewidth": 0.85,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =============================================================================
# 14. BUDGET FUNCTIONS
# =============================================================================

def budget_components(p):
    d = derived_quantities(p)

    b_H = p.S_H * d["q_H"]
    b_E = p.S_E * d["q_E"]

    return {
        "d": d,
        "b_H": float(b_H),
        "b_E": float(b_E),
        "db": float(b_H - b_E),
    }


def psi_from_B(B, B_bar, kappa_B):
    excess = np.maximum(0.0, np.asarray(B, dtype=float) - B_bar)
    return kappa_B * excess**2 / B_bar


def H_budget(z, p, B_bar, kappa_B):
    """
    PA active-policy incremental payoff on the H-E edge.
    H(z) is strictly decreasing under the revised calibration.
    """
    bc = budget_components(p)
    d = bc["d"]

    z = np.asarray(z, dtype=float)

    B = bc["b_E"] + bc["db"] * z

    P_core = (
        d["Delta_E"]
        + z * (d["Delta_H"] - d["Delta_E"])
    )

    return (
        P_core
        - psi_from_B(B, B_bar, kappa_B)
    )


def G_operator(y, p):
    """
    H-minus-E operator payoff difference.
    """
    d = derived_quantities(p)

    a = d["pi_H_B"] - d["pi_E_B"]
    b = p.S_H * d["q_H"] - p.S_E * d["q_E"]

    return a + b * np.asarray(y, dtype=float)


def y_HE_star(p):
    d = derived_quantities(p)

    a = d["pi_H_B"] - d["pi_E_B"]
    b = p.S_H * d["q_H"] - p.S_E * d["q_E"]

    if abs(b) < 1e-14:
        return np.nan

    return float(-a / b)


# =============================================================================
# 15. EXACT PURE-POLICY PERSISTENCE CURVES
# =============================================================================

def kappa_star(Delta_i, b_i, B_bar):
    if B_bar <= 0.0:
        return np.nan

    if B_bar >= b_i:
        return np.inf

    return Delta_i * B_bar / (b_i - B_bar)**2


# =============================================================================
# 16. EXACT REGIME CLASSIFICATION
# =============================================================================

ANALYTIC_CLASS_ORDER = [
    "H_A",
    "Persistent H-E policy cycling",
    "E_A",
    "E_B",
    "Critical boundary",
]

ANALYTIC_CLASS_TO_CODE = {
    label: i
    for i, label in enumerate(ANALYTIC_CLASS_ORDER)
}

ANALYTIC_COLORS = {
    "H_A": "#566B5C",
    "Persistent H-E policy cycling": "#D4C7B5",
    "E_A": "#6F8FA6",
    "E_B": "#A9A9A9",
    "Critical boundary": "#EFEDE8",
}

BOUNDARY_TOL = 1e-10


def classify_exact_regime(scenario_name, B_bar, kappa_B):
    p = make_scenario(scenario_name)

    ystar = y_HE_star(p)

    H0 = float(H_budget(0.0, p, B_bar, kappa_B))
    H1 = float(H_budget(1.0, p, B_bar, kappa_B))

    # S1/S2: H-E operator threshold lies outside [0,1]; E dominates H
    # for every feasible y. The only long-run change is policy A vs B at E.
    if not (0.0 < ystar < 1.0):

        if abs(H0) <= BOUNDARY_TOL:
            return "Critical boundary"

        return "E_A" if H0 > 0.0 else "E_B"

    # S3: feasible H-E operator reversal.
    if abs(H0) <= BOUNDARY_TOL or abs(H1) <= BOUNDARY_TOL:
        return "Critical boundary"

    if H1 > 0.0:
        return "H_A"

    if H0 < 0.0:
        return "E_B"

    if H0 > 0.0 and H1 < 0.0:
        return "Persistent H-E policy cycling"

    # Monotonic H(z) makes this branch theoretically unreachable.
    return "Critical boundary"


# =============================================================================
# 17. DENSE ANALYTICAL MAPS
# =============================================================================

GRID_N = 401

B_BAR_VALUES = np.linspace(0.05, 0.70, GRID_N)
KAPPA_VALUES = np.linspace(0.00, 2.00, GRID_N)

SCENARIO_TITLES = {
    "S1": "Baseline conditions",
    "S2": "Intermediate conditions",
    "S3": "Advanced conditions",
}

map_summary_rows = []

for scenario_name in ["S1", "S2", "S3"]:

    matrix = np.zeros(
        (len(KAPPA_VALUES), len(B_BAR_VALUES)),
        dtype=int,
    )

    rows = []

    for iy, kappa_B in enumerate(KAPPA_VALUES):
        for ix, B_bar in enumerate(B_BAR_VALUES):

            label = classify_exact_regime(
                scenario_name=scenario_name,
                B_bar=float(B_bar),
                kappa_B=float(kappa_B),
            )

            matrix[iy, ix] = ANALYTIC_CLASS_TO_CODE[label]

            p = make_scenario(scenario_name)

            rows.append({
                "Scenario": scenario_name,
                "B_bar_CAD_per_RVK": float(B_bar),
                "kappa_B": float(kappa_B),
                "H_at_E_corner": float(
                    H_budget(0.0, p, B_bar, kappa_B)
                ),
                "H_at_H_corner": float(
                    H_budget(1.0, p, B_bar, kappa_B)
                ),
                "y_HE_star": y_HE_star(p),
                "Analytical_regime": label,
            })

    map_df = pd.DataFrame(rows)

    map_df.to_csv(
        MAP_DIR / f"{scenario_name}_analytical_budget_regime_map.csv",
        index=False,
    )

    pd.DataFrame(
        matrix,
        index=KAPPA_VALUES,
        columns=B_BAR_VALUES,
    ).to_csv(
        MAP_DIR / f"{scenario_name}_analytical_budget_outcome_matrix.csv"
    )

    counts = map_df["Analytical_regime"].value_counts().to_dict()

    summary_row = {
        "Scenario": scenario_name,
        "Grid_points": len(map_df),
    }

    for label in ANALYTIC_CLASS_ORDER:
        summary_row[label] = int(counts.get(label, 0))

    map_summary_rows.append(summary_row)

    # -------------------------------------------------------------------------
    # Plot
    # -------------------------------------------------------------------------

    present_codes = sorted(int(v) for v in np.unique(matrix))
    present_labels = [
        ANALYTIC_CLASS_ORDER[code]
        for code in present_codes
    ]

    cmap = ListedColormap([
        ANALYTIC_COLORS[label]
        for label in ANALYTIC_CLASS_ORDER
    ])

    bounds = np.arange(
        -0.5,
        len(ANALYTIC_CLASS_ORDER) + 0.5,
        1.0,
    )

    norm = BoundaryNorm(bounds, cmap.N)

    fig, ax = plt.subplots(figsize=(6.9, 5.6))

    ax.pcolormesh(
        B_BAR_VALUES,
        KAPPA_VALUES,
        matrix,
        cmap=cmap,
        norm=norm,
        shading="nearest",
        edgecolors="none",
        antialiased=False,
    )

    p = make_scenario(scenario_name)
    bc = budget_components(p)
    d = bc["d"]

    k_H = np.asarray([
        kappa_star(
            d["Delta_H"],
            bc["b_H"],
            Bbar,
        )
        for Bbar in B_BAR_VALUES
    ])

    k_E = np.asarray([
        kappa_star(
            d["Delta_E"],
            bc["b_E"],
            Bbar,
        )
        for Bbar in B_BAR_VALUES
    ])

    valid_H = (
        np.isfinite(k_H)
        & (k_H >= KAPPA_VALUES.min())
        & (k_H <= KAPPA_VALUES.max())
    )

    valid_E = (
        np.isfinite(k_E)
        & (k_E >= KAPPA_VALUES.min())
        & (k_E <= KAPPA_VALUES.max())
    )

    if np.any(valid_H):
        ax.plot(
            B_BAR_VALUES[valid_H],
            k_H[valid_H],
            linestyle="-",
            linewidth=1.25,
            color="#222222",
        )

    if np.any(valid_E):
        ax.plot(
            B_BAR_VALUES[valid_E],
            k_E[valid_E],
            linestyle="--",
            linewidth=1.25,
            color="#222222",
        )

    ax.set_xlabel(
        r"Fiscal tolerance threshold, $\bar B$ (CAD/RVK)"
    )

    ax.set_ylabel(
        r"Fiscal-severity parameter, $\kappa_B$"
    )

    ax.set_title(
        SCENARIO_TITLES[scenario_name]
        + "\nAnalytical municipal-budget regime structure",
        fontweight="semibold",
        pad=8,
    )

    ax.set_xlim(B_BAR_VALUES.min(), B_BAR_VALUES.max())
    ax.set_ylim(KAPPA_VALUES.min(), KAPPA_VALUES.max())
    ax.grid(False)

    handles = [
        Patch(
            facecolor=ANALYTIC_COLORS[label],
            edgecolor="black",
            linewidth=0.45,
            label=label,
        )
        for label in present_labels
        if label != "Critical boundary"
    ]

    if np.any(valid_H):
        handles.append(
            Line2D(
                [0], [0],
                color="#222222",
                linestyle="-",
                linewidth=1.25,
                label="H policy-persistence boundary",
            )
        )

    if np.any(valid_E):
        handles.append(
            Line2D(
                [0], [0],
                color="#222222",
                linestyle="--",
                linewidth=1.25,
                label="E policy-persistence boundary",
            )
        )

    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.15),
        ncol=2,
        frameon=False,
        fontsize=8.1,
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR / f"{scenario_name}_analytical_budget_regime_map.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )

    fig.savefig(
        FIG_DIR / f"{scenario_name}_analytical_budget_regime_map.pdf",
        bbox_inches="tight",
        pad_inches=0.04,
    )

    plt.show()
    plt.close(fig)


map_summary_df = pd.DataFrame(map_summary_rows)

map_summary_df.to_csv(
    CSV_DIR / "analytical_map_outcome_summary.csv",
    index=False,
)


# =============================================================================
# 18. OPTIONAL COMPARISON WITH PHASE 4D-3B NUMERICAL MAPS
# =============================================================================

comparison_rows = []

previous_dir = Path(
    "Phase4D3B_budget_pressure_24IC_regime_maps"
) / "csv_results" / "grid_consensus_results"

if previous_dir.exists():

    for scenario_name in ["S1", "S2", "S3"]:

        previous_file = (
            previous_dir
            / f"{scenario_name}_budget_pressure_consensus.csv"
        )

        if not previous_file.exists():
            continue

        sim_df = pd.read_csv(previous_file)

        for _, row in sim_df.iterrows():

            B_bar = float(row["B_bar_CAD_per_RVK"])
            kappa_B = float(row["kappa_B"])
            numerical = str(row["Consensus"])

            analytical = classify_exact_regime(
                scenario_name,
                B_bar,
                kappa_B,
            )

            expected_numeric = {
                "H_A": "Robust H_A",
                "E_A": "Robust E_A",
                "E_B": "Robust E_B",
                "Persistent H-E policy cycling": "Persistent/nonstationary",
                "Critical boundary": "Persistent/nonstationary",
            }.get(
                analytical,
                analytical,
            )

            match = (
                numerical == expected_numeric
            )

            comparison_rows.append({
                "Scenario": scenario_name,
                "B_bar_CAD_per_RVK": B_bar,
                "kappa_B": kappa_B,
                "Numerical_class": numerical,
                "Analytical_class": analytical,
                "Expected_numerical_class": expected_numeric,
                "Match": match,
            })


comparison_df = pd.DataFrame(comparison_rows)

if len(comparison_df) > 0:
    comparison_df.to_csv(
        CSV_DIR / "phase4D3B_vs_analytical_classification.csv",
        index=False,
    )


# =============================================================================
# 19. REPRESENTATIVE S3 CYCLING POINT
# =============================================================================

S3_BBAR_CYCLE = 0.30
S3_KAPPA_CYCLE = 0.50

p3 = make_scenario("S3")
bc3 = budget_components(p3)
d3 = bc3["d"]

YSTAR = y_HE_star(p3)

H0_cycle = float(
    H_budget(
        0.0,
        p3,
        S3_BBAR_CYCLE,
        S3_KAPPA_CYCLE,
    )
)

H1_cycle = float(
    H_budget(
        1.0,
        p3,
        S3_BBAR_CYCLE,
        S3_KAPPA_CYCLE,
    )
)

if not (H0_cycle > 0.0 and H1_cycle < 0.0):
    raise RuntimeError(
        "Selected S3 representative point is not inside the analytical "
        "cycling regime."
    )

ZSTAR = float(
    brentq(
        lambda zz: float(
            H_budget(
                zz,
                p3,
                S3_BBAR_CYCLE,
                S3_KAPPA_CYCLE,
            )
        ),
        0.0,
        1.0,
        xtol=1e-14,
        rtol=1e-14,
    )
)


# =============================================================================
# 20. LOCAL LINEARIZATION AT THE INTERIOR S3 REST POINT
# =============================================================================

def numerical_derivative(fun, x, h=1e-7):
    return float(
        (
            fun(x + h)
            - fun(x - h)
        )
        / (2.0 * h)
    )


Gprime = numerical_derivative(
    lambda yy: float(
        G_operator(yy, p3)
    ),
    YSTAR,
)

Hprime = numerical_derivative(
    lambda zz: float(
        H_budget(
            zz,
            p3,
            S3_BBAR_CYCLE,
            S3_KAPPA_CYCLE,
        )
    ),
    ZSTAR,
)

K_CYCLE = (
    p3.eta_TO
    * p3.eta_PA
    * ZSTAR
    * (1.0 - ZSTAR)
    * YSTAR
    * (1.0 - YSTAR)
    * Gprime
    * Hprime
)

if K_CYCLE >= 0.0:
    raise RuntimeError(
        "Representative interior point does not have the expected "
        "imaginary edge eigenvalue pair."
    )

LINEARIZED_PERIOD = (
    2.0
    * np.pi
    / np.sqrt(
        -K_CYCLE
    )
)


# =============================================================================
# 21. EXACT FIRST INTEGRAL ON THE S3 H-E EDGE
#
# I(z,y) = A(z) - J(y)
#
# A'(z) = H(z)/[z(1-z)]
# J'(y) = G(y)/[y(1-y)]
#
# H(z) is piecewise quadratic because of the thresholded quadratic fiscal
# penalty, so A(z) has a closed-form piecewise antiderivative.
# =============================================================================

def _poly_antiderivative_over_logit(z, c0, c1, c2):
    """
    Integral of (c0 + c1 z + c2 z^2) / [z(1-z)] dz.
    """
    z = np.asarray(z, dtype=float)

    return (
        c0 * np.log(z)
        - (c0 + c1 + c2) * np.log(1.0 - z)
        - c2 * z
    )


def A_z_first_integral(z, p, B_bar, kappa_B):
    z = np.asarray(z, dtype=float)

    bc = budget_components(p)
    d = bc["d"]

    bE = bc["b_E"]
    db = bc["db"]

    # Core linear PA increment on the H-E edge.
    c0_inactive = d["Delta_E"]
    c1_inactive = d["Delta_H"] - d["Delta_E"]
    c2_inactive = 0.0

    def F_inactive(x):
        return _poly_antiderivative_over_logit(
            x,
            c0_inactive,
            c1_inactive,
            c2_inactive,
        )

    # Active-penalty coefficients.
    a0 = bE - B_bar

    penalty_c0 = kappa_B / B_bar * a0**2
    penalty_c1 = 2.0 * kappa_B / B_bar * a0 * db
    penalty_c2 = kappa_B / B_bar * db**2

    c0_active = c0_inactive - penalty_c0
    c1_active = c1_inactive - penalty_c1
    c2_active = -penalty_c2

    def F_active(x):
        return _poly_antiderivative_over_logit(
            x,
            c0_active,
            c1_active,
            c2_active,
        )

    z_activation = (
        (B_bar - bE) / db
        if abs(db) > 1e-14
        else np.inf
    )

    out = np.empty_like(z, dtype=float)

    if z_activation <= 0.0:
        out[:] = F_active(z)

    elif z_activation >= 1.0:
        out[:] = F_inactive(z)

    else:
        below = z <= z_activation
        above = ~below

        out[below] = F_inactive(z[below])

        continuity_offset = (
            F_inactive(z_activation)
            - F_active(z_activation)
        )

        out[above] = (
            F_active(z[above])
            + continuity_offset
        )

    return out


def J_y_first_integral(y, p):
    d = derived_quantities(p)

    a = d["pi_H_B"] - d["pi_E_B"]
    b = p.S_H * d["q_H"] - p.S_E * d["q_E"]

    y = np.asarray(y, dtype=float)

    return (
        a * np.log(y)
        - (a + b) * np.log(1.0 - y)
    )


def first_integral(z, y, p, B_bar, kappa_B):
    return (
        A_z_first_integral(
            z,
            p,
            B_bar,
            kappa_B,
        )
        - J_y_first_integral(
            y,
            p,
        )
    )


# =============================================================================
# 22. 24 EDGE STARTS
# =============================================================================

EDGE_Z_LEVELS = [
    0.10,
    0.22,
    0.38,
    0.56,
    0.72,
    0.86,
    0.93,
    0.97,
]

EDGE_Y_LEVELS = [
    0.20,
    0.50,
    0.85,
]

EDGE_ROWS = []
EDGE_STARTS = []

counter = 1

for z0 in EDGE_Z_LEVELS:
    for y0 in EDGE_Y_LEVELS:

        name = f"EIC{counter:02d}"

        EDGE_ROWS.append({
            "EIC": name,
            "z0": z0,
            "w0": 1.0 - z0,
            "y0": y0,
        })

        EDGE_STARTS.append(
            [z0, y0]
        )

        counter += 1

EDGE_DF = pd.DataFrame(EDGE_ROWS)

EDGE_DF.to_csv(
    CYCLE_DIR / "edge_initial_conditions_24.csv",
    index=False,
)


# =============================================================================
# 23. HIGH-PRECISION EDGE SOLVER IN LOGIT COORDINATES
# =============================================================================

TAU_EDGE = 4000.0
T_EDGE = np.linspace(
    0.0,
    TAU_EDGE,
    40001,
)


def logit(x):
    return np.log(x / (1.0 - x))


def edge_rhs_logit(tau, state):
    u, v = state

    z = expit(u)
    y = expit(v)

    du = p3.eta_TO * float(
        G_operator(y, p3)
    )

    dv = p3.eta_PA * float(
        H_budget(
            z,
            p3,
            S3_BBAR_CYCLE,
            S3_KAPPA_CYCLE,
        )
    )

    return [du, dv]


cycle_rows = []
cycle_summary_rows = []

for _, row in EDGE_DF.iterrows():

    eic = row["EIC"]
    z0 = float(row["z0"])
    y0 = float(row["y0"])

    sol = solve_ivp(
        fun=edge_rhs_logit,
        t_span=(0.0, TAU_EDGE),
        y0=[logit(z0), logit(y0)],
        t_eval=T_EDGE,
        method="DOP853",
        rtol=2e-12,
        atol=2e-14,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    z = expit(sol.y[0])
    y = expit(sol.y[1])
    w = 1.0 - z

    I = first_integral(
        z,
        y,
        p3,
        S3_BBAR_CYCLE,
        S3_KAPPA_CYCLE,
    )

    tail_mask = sol.t >= 0.50 * TAU_EDGE

    tail_t = sol.t[tail_mask]
    tail_z = z[tail_mask]
    tail_y = y[tail_mask]
    tail_I = I[tail_mask]

    # Peak-based period estimate.
    peaks, _ = find_peaks(
        tail_z,
        prominence=max(
            1e-4,
            0.02 * (np.max(tail_z) - np.min(tail_z))
        ),
    )

    peak_times = tail_t[peaks]

    if len(peak_times) >= 3:
        periods = np.diff(peak_times)
        mean_period = float(np.mean(periods))
        period_cv = float(
            np.std(periods, ddof=1) / mean_period
        ) if len(periods) >= 2 else 0.0
    else:
        mean_period = np.nan
        period_cv = np.nan

    invariant_range = float(
        np.max(tail_I) - np.min(tail_I)
    )

    z_amp = float(
        np.max(tail_z) - np.min(tail_z)
    )

    y_amp = float(
        np.max(tail_y) - np.min(tail_y)
    )

    certified = bool(
        len(peak_times) >= 3
        and z_amp > 1e-3
        and y_amp > 1e-3
        and invariant_range < 1e-8
        and (
            np.isnan(period_cv)
            or period_cv < 5e-3
        )
    )

    cycle_summary_rows.append({
        "EIC": eic,
        "z0": z0,
        "y0": y0,
        "Tail_z_amplitude": z_amp,
        "Tail_y_amplitude": y_amp,
        "Tail_peak_count": int(len(peak_times)),
        "Mean_observed_period": mean_period,
        "Observed_period_CV": period_cv,
        "First_integral_range": invariant_range,
        "Cycle_certified": certified,
    })

    traj_df = pd.DataFrame({
        "EIC": eic,
        "tau": sol.t,
        "Hydrogen_z": z,
        "Electric_w": w,
        "Policy_y": y,
        "First_integral": I,
    })

    traj_df.to_csv(
        TRAJ_DIR / f"{eic}_trajectory.csv",
        index=False,
    )

    cycle_rows.append(traj_df)


cycle_summary_df = pd.DataFrame(cycle_summary_rows)

cycle_summary_df.to_csv(
    CYCLE_DIR / "edge_cycle_certification_summary_24IC.csv",
    index=False,
)

all_cycle_df = pd.concat(
    cycle_rows,
    ignore_index=True,
)

all_cycle_df.to_csv(
    CYCLE_DIR / "all_24_edge_cycle_trajectories.csv",
    index=False,
)


# =============================================================================
# 24. TRANSVERSE ATTRACTION FROM THE FULL SIMPLEX
# =============================================================================

FULL_TECH_COMPOSITIONS = [
    (0.05, 0.10),
    (0.10, 0.05),
    (0.05, 0.75),
    (0.75, 0.05),
    (0.20, 0.55),
    (0.55, 0.20),
    (0.30, 0.30),
    (0.45, 0.45),
]

FULL_POLICY_LEVELS = [
    0.10,
    0.50,
    0.90,
]

FULL_ROWS = []
FULL_STARTS = []

counter = 1

for z0, w0 in FULL_TECH_COMPOSITIONS:
    for y0 in FULL_POLICY_LEVELS:

        name = f"FIC{counter:02d}"

        FULL_ROWS.append({
            "FIC": name,
            "z0": z0,
            "w0": w0,
            "D0": 1.0 - z0 - w0,
            "y0": y0,
        })

        FULL_STARTS.append(
            [z0, w0, y0]
        )

        counter += 1

FULL_DF = pd.DataFrame(FULL_ROWS)

FULL_DF.to_csv(
    CYCLE_DIR / "full_simplex_initial_conditions_24.csv",
    index=False,
)


def full_rhs(tau, state):
    z, w, y = state
    D = 1.0 - z - w

    Pi_H = d3["pi_H_B"] + y * p3.S_H * d3["q_H"]
    Pi_E = d3["pi_E_B"] + y * p3.S_E * d3["q_E"]
    Pi_D = d3["pi_D_B"] - y * p3.T_D * d3["q_D"]

    Pi_bar = (
        z * Pi_H
        + w * Pi_E
        + D * Pi_D
    )

    B = (
        z * bc3["b_H"]
        + w * bc3["b_E"]
    )

    Psi = float(
        psi_from_B(
            B,
            S3_BBAR_CYCLE,
            S3_KAPPA_CYCLE,
        )
    )

    P_core = (
        z * d3["Delta_H"]
        + w * d3["Delta_E"]
        + D * d3["Delta_D"]
    )

    dz = (
        p3.eta_TO
        * z
        * (Pi_H - Pi_bar)
    )

    dw = (
        p3.eta_TO
        * w
        * (Pi_E - Pi_bar)
    )

    dy = (
        p3.eta_PA
        * y
        * (1.0 - y)
        * (P_core - Psi)
    )

    return [dz, dw, dy]


TRANSVERSE_TAU = 500.0
transverse_rows = []

for row, initial in zip(FULL_ROWS, FULL_STARTS):

    sol = solve_ivp(
        fun=full_rhs,
        t_span=(0.0, TRANSVERSE_TAU),
        y0=initial,
        t_eval=[TRANSVERSE_TAU],
        method="DOP853",
        rtol=1e-11,
        atol=1e-13,
    )

    if not sol.success:
        raise RuntimeError(sol.message)

    zf, wf, yf = sol.y[:, -1]
    Df = max(0.0, 1.0 - zf - wf)

    transverse_rows.append({
        "FIC": row["FIC"],
        "z0": row["z0"],
        "w0": row["w0"],
        "D0": row["D0"],
        "y0": row["y0"],
        "Final_H": zf,
        "Final_E": wf,
        "Final_D": Df,
        "Final_y": yf,
    })


transverse_df = pd.DataFrame(transverse_rows)

transverse_df.to_csv(
    CYCLE_DIR / "full_simplex_transverse_attraction_24IC.csv",
    index=False,
)


# =============================================================================
# 25. REPRESENTATIVE CYCLE FIGURE
# =============================================================================

rep_eic = "EIC11"

rep_df = pd.read_csv(
    TRAJ_DIR / f"{rep_eic}_trajectory.csv"
)

fig, axes = plt.subplots(
    1,
    2,
    figsize=(10.2, 4.2),
)

axes[0].plot(
    rep_df["tau"],
    rep_df["Hydrogen_z"],
    linewidth=1.2,
    label=r"Hydrogen share, $z$",
)

axes[0].plot(
    rep_df["tau"],
    rep_df["Policy_y"],
    linewidth=1.2,
    label=r"Policy weight, $y$",
)

axes[0].set_xlabel(
    r"Normalized evolutionary time, $\tau$"
)

axes[0].set_ylabel(
    "State value"
)

axes[0].set_title(
    "Persistent H-E policy cycle"
)

axes[0].legend(
    frameon=False
)

axes[1].plot(
    rep_df["Hydrogen_z"],
    rep_df["Policy_y"],
    linewidth=1.1,
)

axes[1].scatter(
    [ZSTAR],
    [YSTAR],
    marker="*",
    s=90,
    facecolor="white",
    edgecolor="black",
    linewidth=0.9,
    zorder=5,
)

axes[1].set_xlabel(
    r"Hydrogen service share, $z$"
)

axes[1].set_ylabel(
    r"Active-policy weight, $y$"
)

axes[1].set_title(
    "H-E edge phase portrait"
)

for ax in axes:
    ax.grid(False)

fig.suptitle(
    "Advanced conditions — municipal budget feedback",
    fontweight="semibold",
)

fig.tight_layout()

fig.savefig(
    FIG_DIR / "S3_representative_budget_policy_cycle.png",
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    FIG_DIR / "S3_representative_budget_policy_cycle.pdf",
    bbox_inches="tight",
)

plt.show()
plt.close(fig)


# =============================================================================
# 26. SAVE REPRESENTATIVE EQUILIBRIUM / LOCAL CERTIFICATION
# =============================================================================

local_df = pd.DataFrame([{
    "Scenario": "S3",
    "B_bar_CAD_per_RVK": S3_BBAR_CYCLE,
    "kappa_B": S3_KAPPA_CYCLE,
    "z_star": ZSTAR,
    "w_star": 1.0 - ZSTAR,
    "y_star": YSTAR,
    "H_at_E_corner": H0_cycle,
    "H_at_H_corner": H1_cycle,
    "Gprime_y": Gprime,
    "Hprime_z": Hprime,
    "K_edge": K_CYCLE,
    "Linearized_period": LINEARIZED_PERIOD,
}])

local_df.to_csv(
    CYCLE_DIR / "representative_S3_cycle_rest_point.csv",
    index=False,
)


# =============================================================================
# 27. PRINT
# =============================================================================

print("=" * 112)
print("PHASE 4D-3C — ANALYTICAL BUDGET REGIME + POLICY-CYCLE CERTIFICATION")
print("=" * 112)

print("\nA. ANALYTICAL MAP OUTCOME COUNTS")
print("-" * 112)

for _, row in map_summary_df.iterrows():

    print(f"\n{row['Scenario']}")

    for label in ANALYTIC_CLASS_ORDER:

        count = int(row[label])

        if count > 0:
            print(f"  {label}: {count}")


print("\nB. PHASE 4D-3B NUMERICAL / ANALYTICAL AGREEMENT")
print("-" * 112)

if len(comparison_df) == 0:

    print(
        "  Previous Phase 4D-3B consensus CSV files were not found; "
        "comparison skipped."
    )

else:

    for scenario_name in ["S1", "S2", "S3"]:

        sub = comparison_df[
            comparison_df["Scenario"] == scenario_name
        ]

        if len(sub) == 0:
            continue

        matches = int(sub["Match"].sum())
        total = len(sub)

        print(
            f"  {scenario_name}: "
            f"{matches}/{total} exact class matches "
            f"({100.0*matches/total:.2f}%)"
        )

        mismatch = sub[~sub["Match"]]

        if len(mismatch) > 0:
            print(
                f"    mismatches = {len(mismatch)} "
                "(expected mainly at/near critical boundaries)"
            )


print("\nC. REPRESENTATIVE S3 CYCLING POINT")
print("-" * 112)

print(
    f"  B_bar = {S3_BBAR_CYCLE:.3f} CAD/RVK"
)

print(
    f"  kappa_B = {S3_KAPPA_CYCLE:.3f}"
)

print(
    f"  E9-like interior rest point: "
    f"z*={ZSTAR:.9f}, "
    f"w*={1.0-ZSTAR:.9f}, "
    f"y*={YSTAR:.9f}"
)

print(
    f"  H(0) = {H0_cycle:.9f}"
)

print(
    f"  H(1) = {H1_cycle:.9f}"
)

print(
    f"  K_edge = {K_CYCLE:.10f}"
)

print(
    f"  Linearized period = {LINEARIZED_PERIOD:.6f}"
)


print("\nD. 24-EDGE-START CYCLE CERTIFICATION")
print("-" * 112)

n_certified = int(
    cycle_summary_df["Cycle_certified"].sum()
)

print(
    f"  Certified = {n_certified}/{len(cycle_summary_df)}"
)

print(
    f"  Max first-integral range = "
    f"{cycle_summary_df['First_integral_range'].max():.3e}"
)

finite_periods = cycle_summary_df[
    np.isfinite(
        cycle_summary_df["Mean_observed_period"]
    )
]

if len(finite_periods) > 0:

    print(
        f"  Observed period range across certified starts = "
        f"{finite_periods['Mean_observed_period'].min():.4f} "
        f"to "
        f"{finite_periods['Mean_observed_period'].max():.4f}"
    )


print("\nE. TRANSVERSE ATTRACTION")
print("-" * 112)

print(
    f"  Max |D(tau={TRANSVERSE_TAU:.0f})| across 24 full-simplex starts = "
    f"{transverse_df['Final_D'].abs().max():.3e}"
)


print("\nINTERPRETATION")
print("-" * 112)

print(
    "  S1/S2: electric remains the technology winner; fiscal pressure switches "
    "the PA between active-policy and baseline-policy corners."
)

print(
    "  S3: when electric deployment can sustain active policy but hydrogen "
    "deployment cannot, the endogenous feedback E -> y up -> H -> fiscal "
    "pressure -> y down -> E creates persistent H-E policy cycles."
)

print(
    "  The broad nonstationary region in Phase 4D-3B is therefore a structural "
    "feature of the revised model rather than a slow-convergence artifact."
)


print("\nFiles saved under:")
print(f"  {OUT_DIR.resolve()}")

print("\nCSV RESULTS")
print("  analytical_map_outcome_summary.csv")
print("  analytical_maps/*.csv")
print("  phase4D3B_vs_analytical_classification.csv  [if prior files found]")
print("  cycle_certification/representative_S3_cycle_rest_point.csv")
print("  cycle_certification/edge_cycle_certification_summary_24IC.csv")
print("  cycle_certification/full_simplex_transverse_attraction_24IC.csv")
print("  cycle_certification/all_24_edge_cycle_trajectories.csv")
print("  cycle_certification/individual_trajectories/*.csv")

print("\nPhase 4D-3C completed.")
