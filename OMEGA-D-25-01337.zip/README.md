# Omega R3 — author reproducibility package (working release)

The folder `production` contains the standalone Phase 4C/4D scripts and the certified Phase 4B mathematical core (`core_phase4B.py`; its original module name is also included for the entry-seed script) underlying the revised manuscript. `development_archive` contains earlier scripts, which **should not** be used as the final model because some implement obsolete payoff/accounting structures and naming conventions.

## Fast verification

From `production`, run:

    python OMEGA_R3_reproduce_core_fast.py

This checks S1/S2/S3 passenger utilization, PA policy advantages, H--E indifference thresholds, stable-corner reports, and the exact reparameterization used in manuscript Table B1.

## Reproducing figures and classifications

For baseline multi-start figures run `phase4C_multistart_FULL_STANDALONE(1).py` (DOP853, rtol=1e-10, atol=1e-12; seven plotted initial conditions). For full benchmark and region classification run `phase4C4_region_analysis_24IC_FULL_STANDALONE(1).py` (eight compositions x three PA starting values; adaptive horizon 220/500/1000/2000). Other Phase 4C5 and Phase 4D scripts reproduce their respective stationary/cycling, infrastructure, bounded-utilization and budget-pressure analyses. Some script families require prior outputs from an earlier numbered script. Certain grid analyses are computationally intensive. Review each script's output-directory and imported-file requirements before running it. No full computational rerun has been performed when preparing this archive.

Python dependencies: numpy, scipy, pandas, matplotlib, plus standard library; some development files use pillow and tkinter. Install through the relevant environment or package manager. Expected script inputs are parameter defaults embedded within each standalone production script. The new CSVs in `parameters` provide explicit scenario vectors and the 24 initial conditions used by the 24-start certification.

## Exact value-of-time normalization

The original production scripts use `lambda_time=1.0`, `U_0=2.0666666666666664` and `beta_t=0.5`. In the revised manuscript the identical baseline utilities are written with `lambda_time=10.0`, `U_0=7.166666666666666`, and `beta_t=0.5` because all three propulsion configurations have the same travel time T = 1/(2x3)+10/25 = 0.56666666... hours in the benchmark. The two forms agree to floating point precision for all S1--S3 utilities, utilization, payoffs, and indifference thresholds. Both parameterizations are exported; do not mix the new travel-time coefficient with the old intercept.

## Provenance and caveats

The `production` scripts implement the reviewed RVK service-share model, whereas the older `transit_model(20261107-153723).py` implements an earlier, materially different game and is retained for provenance only. The supplied code is author-provided and prepared for supplementary submission; it is **not** yet hosted at a public repository or assigned a DOI. Figure asset files and the original `.bib` database are not included here. For large-area grid outputs, reproducibility depends on computational resources and settings within each corresponding script. Audit any external relative-path dependencies before archival deposit.
